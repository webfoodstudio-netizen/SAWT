/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ViewType, CaseItem, CampaignItem, Language } from './types';
import { 
  INITIAL_CASES, 
  INITIAL_CAMPAIGNS, 
  INITIAL_COUNTRIES 
} from './data/mockData';

// Components
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeaturedCaseSpotlight } from './components/FeaturedCaseSpotlight';
import { CasesDeserveToBeKnown } from './components/CasesDeserveToBeKnown';
import { ArabWorldSection } from './components/ArabWorldSection';
import { ChangeStrip } from './components/ChangeStrip';
import { CaseDossierView } from './components/CaseDossierView';
import { CasesArchiveView } from './components/CasesArchiveView';
import { CountriesView } from './components/CountriesView';
import { UrgentCasesView } from './components/UrgentCasesView';
import { CampaignsView } from './components/CampaignsView';
import { VerificationMethodologyView } from './components/VerificationMethodologyView';
import { SubmitCaseWizard } from './components/SubmitCaseWizard';
import { LegalNetworkView } from './components/LegalNetworkView';
import { MediaCenterView } from './components/MediaCenterView';
import { CharterView } from './components/CharterView';
import { AboutView } from './components/AboutView';
import { FundView } from './components/FundView';
import { AdminDashboardView } from './components/AdminDashboardView';
import { Footer } from './components/Footer';

// Modals
import { ShareModal } from './components/ShareModal';
import { SubmitInfoModal } from './components/SubmitInfoModal';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [selectedCaseId, setSelectedCaseId] = useState<string>('CASE-EGY-042');
  const [cases, setCases] = useState<CaseItem[]>(INITIAL_CASES);
  const [campaigns, setCampaigns] = useState<CampaignItem[]>(INITIAL_CAMPAIGNS);
  const [countries, setCountries] = useState(INITIAL_COUNTRIES);
  const [language, setLanguage] = useState<Language>('ar');

  // Archive filters state passed from other sections
  const [archiveStatusFilter, setArchiveStatusFilter] = useState<string>('all');
  const [archiveCountryFilter, setArchiveCountryFilter] = useState<string>('all');

  // Modals state
  const [shareModalCase, setShareModalCase] = useState<CaseItem | null>(null);
  const [submitInfoCaseId, setSubmitInfoCaseId] = useState<string | null>(null);

  // Sync with browser hash on load and change
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#/', '');
      if (!hash || hash === '') {
        setCurrentView('home');
      } else if (hash.startsWith('case/')) {
        const id = hash.replace('case/', '');
        setSelectedCaseId(id);
        setCurrentView('case_detail');
      } else if (hash === 'cases') {
        setCurrentView('cases');
      } else if (hash === 'countries') {
        setCurrentView('countries');
      } else if (hash === 'urgent') {
        setCurrentView('urgent');
      } else if (hash === 'campaigns') {
        setCurrentView('campaigns');
      } else if (hash === 'verification' || hash === 'verification_guide') {
        setCurrentView('verification_guide');
      } else if (hash === 'submit' || hash === 'submit_case') {
        setCurrentView('submit_case');
      } else if (hash === 'legal' || hash === 'legal_network') {
        setCurrentView('legal_network');
      } else if (hash === 'media' || hash === 'media_center') {
        setCurrentView('media_center');
      } else if (hash === 'charter') {
        setCurrentView('charter');
      } else if (hash === 'about') {
        setCurrentView('about');
      } else if (hash === 'fund') {
        setCurrentView('fund');
      } else if (hash === 'admin' || hash === 'admin_dashboard') {
        setCurrentView('admin_dashboard');
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (view: ViewType, caseId?: string) => {
    if (caseId) {
      setSelectedCaseId(caseId);
      window.location.hash = `#/case/${caseId}`;
    } else {
      const hashMap: Record<ViewType, string> = {
        home: '',
        cases: 'cases',
        case_detail: `case/${selectedCaseId}`,
        countries: 'countries',
        urgent: 'urgent',
        campaigns: 'campaigns',
        verification_guide: 'verification',
        submit_case: 'submit',
        legal_network: 'legal',
        media_center: 'media',
        charter: 'charter',
        about: 'about',
        fund: 'fund',
        admin_dashboard: 'admin',
      };
      window.location.hash = `#/${hashMap[view] || ''}`;
    }
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenCase = (caseId: string) => {
    setSelectedCaseId(caseId);
    navigateTo('case_detail', caseId);
  };

  const handleSelectCountry = (countryName: string) => {
    setArchiveCountryFilter(countryName);
    setArchiveStatusFilter('all');
    navigateTo('cases');
  };

  const handleHeroSearch = (query: string) => {
    // If exact case ID, open it directly
    const found = cases.find(c => c.id.toLowerCase() === query.toLowerCase());
    if (found) {
      handleOpenCase(found.id);
    } else {
      setArchiveStatusFilter('all');
      setArchiveCountryFilter('all');
      navigateTo('cases');
    }
  };

  const handleNavigateToCasesWithFilter = (filterKey?: string) => {
    if (filterKey === 'urgent') {
      navigateTo('urgent');
    } else if (filterKey === 'verified') {
      setArchiveStatusFilter('verified');
      navigateTo('cases');
    } else if (filterKey === 'investigating') {
      setArchiveStatusFilter('investigating');
      navigateTo('cases');
    } else {
      setArchiveStatusFilter('all');
      setArchiveCountryFilter('all');
      navigateTo('cases');
    }
  };

  const handleUpdateCase = (updated: CaseItem) => {
    setCases(prev => prev.map(c => c.id === updated.id ? updated : c));
  };

  // Find active case for detail view
  const currentActiveCase = cases.find(c => c.id === selectedCaseId) || cases[0];

  // If in dedicated Admin Operations Room
  if (currentView === 'admin_dashboard') {
    return (
      <AdminDashboardView
        cases={cases}
        onOpenCase={handleOpenCase}
        onUpdateCase={handleUpdateCase}
        onExitToPublic={() => navigateTo('home')}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F3EE] text-[#17201D] font-sans antialiased selection:bg-[#0B5145]/20 selection:text-[#0B5145]">
      
      {/* Universal Top Bar */}
      <Header
        currentView={currentView}
        onNavigate={navigateTo}
        language={language}
        onLanguageChange={setLanguage}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        
        {/* VIEW 1: HOME */}
        {currentView === 'home' && (
          <>
            <Hero
              onSearch={handleHeroSearch}
              onTagClick={handleHeroSearch}
              onNavigateToCases={handleNavigateToCasesWithFilter}
            />

            <FeaturedCaseSpotlight
              cases={cases}
              onOpenCase={handleOpenCase}
              onShareCase={(item) => setShareModalCase(item)}
            />

            <CasesDeserveToBeKnown
              cases={cases}
              onOpenCase={handleOpenCase}
              onViewAll={() => navigateTo('cases')}
            />

            <ArabWorldSection
              countries={countries}
              onSelectCountry={handleSelectCountry}
              onViewAllCountries={() => navigateTo('countries')}
            />

            <ChangeStrip
              onNavigate={navigateTo}
              onOpenSubmitTip={() => setSubmitInfoCaseId(selectedCaseId)}
            />
          </>
        )}

        {/* VIEW 2: CASES ARCHIVE */}
        {currentView === 'cases' && (
          <CasesArchiveView
            cases={cases}
            onOpenCase={handleOpenCase}
            initialFilter={archiveStatusFilter}
            initialCountry={archiveCountryFilter}
          />
        )}

        {/* VIEW 3: CASE DOSSIER DETAIL */}
        {currentView === 'case_detail' && currentActiveCase && (
          <CaseDossierView
            caseItem={currentActiveCase}
            onBack={() => navigateTo('cases')}
            onShare={(item) => setShareModalCase(item)}
            onSubmitTip={(caseId) => setSubmitInfoCaseId(caseId)}
            onOpenCampaign={(campId) => navigateTo('campaigns')}
            onOpenAiAssistant={(item) => navigateTo('admin_dashboard')}
            language={language}
          />
        )}

        {/* VIEW 4: COUNTRIES */}
        {currentView === 'countries' && (
          <CountriesView
            countries={countries}
            onSelectCountry={handleSelectCountry}
          />
        )}

        {/* VIEW 5: URGENT CASES */}
        {currentView === 'urgent' && (
          <UrgentCasesView
            cases={cases}
            onOpenCase={handleOpenCase}
            onOpenCampaign={() => navigateTo('campaigns')}
          />
        )}

        {/* VIEW 6: CAMPAIGNS */}
        {currentView === 'campaigns' && (
          <CampaignsView
            campaigns={campaigns}
            onOpenCase={handleOpenCase}
            onShareCampaign={(camp) => {
              const matchedCase = cases.find(c => c.id === camp.caseId);
              if (matchedCase) setShareModalCase(matchedCase);
            }}
          />
        )}

        {/* VIEW 7: VERIFICATION GUIDE (كيف نتحقق؟) */}
        {currentView === 'verification_guide' && (
          <VerificationMethodologyView />
        )}

        {/* VIEW 8: SUBMIT CASE (قدّم قضية) */}
        {currentView === 'submit_case' && (
          <SubmitCaseWizard />
        )}

        {/* VIEW 9: LEGAL AID NETWORK */}
        {currentView === 'legal_network' && (
          <LegalNetworkView />
        )}

        {/* VIEW 10: MEDIA CENTER */}
        {currentView === 'media_center' && (
          <MediaCenterView
            cases={cases}
            onOpenCase={handleOpenCase}
          />
        )}

        {/* VIEW 11: CHARTER (الميثاق) */}
        {currentView === 'charter' && (
          <CharterView />
        )}

        {/* VIEW 12: ABOUT US (من نحن) */}
        {currentView === 'about' && (
          <AboutView />
        )}

        {/* VIEW 13: FUND (صندوق الدعم) */}
        {currentView === 'fund' && (
          <FundView />
        )}

      </main>

      {/* Universal Footer */}
      <Footer onNavigate={navigateTo} />

      {/* Universal Share Modal */}
      <ShareModal
        caseItem={shareModalCase}
        onClose={() => setShareModalCase(null)}
      />

      {/* Universal Submit Information / Tip Modal */}
      <SubmitInfoModal
        caseId={submitInfoCaseId}
        onClose={() => setSubmitInfoCaseId(null)}
      />

    </div>
  );
}
