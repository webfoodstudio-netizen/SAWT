import React, { useState } from 'react';
import { LegalPartner } from '../types';
import { Scale, Search, ShieldCheck, MapPin, Briefcase, Mail, CheckCircle, UserPlus, Filter } from 'lucide-react';
import { INITIAL_LEGAL_PARTNERS } from '../data/mockData';

export const LegalNetworkView: React.FC = () => {
  const [partners, setPartners] = useState<LegalPartner[]>(INITIAL_LEGAL_PARTNERS);
  const [searchTerm, setSearchTerm] = useState('');
  const [countryFilter, setCountryFilter] = useState('all');
  const [roleFilter, setRoleFilter] = useState('all');
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [joinSuccess, setJoinSuccess] = useState(false);

  const countries = Array.from(new Set(partners.map(p => p.country))).sort();
  const roles = Array.from(new Set(partners.map(p => p.role)));

  const filteredPartners = partners.filter(p => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchCity = p.city.toLowerCase().includes(q);
      const matchBio = p.bio.toLowerCase().includes(q);
      const matchSpecs = p.specializations.some(s => s.toLowerCase().includes(q));
      if (!matchName && !matchCity && !matchBio && !matchSpecs) return false;
    }
    if (countryFilter !== 'all' && p.country !== countryFilter) return false;
    if (roleFilter !== 'all' && p.role !== roleFilter) return false;
    return true;
  });

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-10 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-8">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0B5145]/10 text-[#0B5145] text-xs font-bold mb-2">
              <Scale className="w-4 h-4" />
              <span>المساندة القضائية والحقوقية الميدانية</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-2">
              شبكة المساعدة القانونية ⚖️
            </h1>
            <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
              دليل تنسيقي يضم محامين معتمدين، باحثين استقصائيين، مترجمين قانونيين، ومنظمات حقوقية شريكة عبر العالم العربي لمساندة عائلات المحتجزين.
            </p>
          </div>

          <button
            onClick={() => setShowJoinModal(true)}
            className="inline-flex items-center gap-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs sm:text-sm font-semibold px-5 py-3 rounded-xl shadow-sm transition-colors cursor-pointer self-start sm:self-auto"
          >
            <UserPlus className="w-4 h-4" />
            <span>طلب الانضمام كخبير أو محامٍ</span>
          </button>
        </div>

        {/* Ethical Transparency Disclaimer */}
        <div className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-sm text-xs text-stone-600 leading-relaxed mb-8 flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-[#0B5145] shrink-0 mt-0.5" />
          <p>
            <strong>تنويه أخلاقي واعتمادي:</strong> ظهور المحامين والخبراء في هذه الشبكة يخضع لمعايير مهنية وتحقق من القيد النقابي والنشاط الحقوقي المستقل، ولا يعني أن المحامي يمثل المنصة أو أن المنصة تضمن النتيجة القضائية، بل تيسر التنسيق وتقديم العون لمن لا يملك وسيلة دفاع مستقلة.
          </p>
        </div>

        {/* Search & Filters */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث بالاسم، المدينة، أو التخصص..."
                className="w-full pr-10 pl-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
              />
              <Search className="absolute right-3 top-3 w-4 h-4 text-stone-400" />
            </div>

            <div>
              <select
                value={countryFilter}
                onChange={(e) => setCountryFilter(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-semibold text-stone-800 focus:outline-none cursor-pointer"
              >
                <option value="all">كافة الدول العربية ({countries.length})</option>
                {countries.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-semibold text-stone-800 focus:outline-none cursor-pointer"
              >
                <option value="all">كافة الأدوار والصفات ({roles.length})</option>
                {roles.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>

          </div>
        </div>

        {/* Partners Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPartners.map((partner) => (
            <div
              key={partner.id}
              className="bg-white rounded-3xl p-6 border border-stone-200/80 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-3">
                  <span className="text-xs font-semibold px-2.5 py-1 rounded bg-[#0B5145]/10 text-[#0B5145]">
                    {partner.role}
                  </span>
                  <span className="text-xs text-stone-500 flex items-center gap-1 font-mono">
                    <MapPin className="w-3.5 h-3.5" />
                    {partner.country} · {partner.city}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-[#17201D] font-serif-ar mb-2 flex items-center gap-1.5">
                  <span>{partner.name}</span>
                  {partner.verifiedStatus && (
                    <span title="معتمد مهنياً">
                      <CheckCircle className="w-4 h-4 text-[#0B5145]" />
                    </span>
                  )}
                </h3>

                <p className="text-xs text-stone-600 leading-relaxed mb-4">
                  {partner.bio}
                </p>

                {/* Specializations */}
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {partner.specializations.map((spec, i) => (
                    <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-stone-100 text-stone-700">
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              {/* Contact Footer */}
              <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                <span className="text-stone-400 font-mono text-[11px]">
                  {partner.activeCasesCount} قضايا متابعة
                </span>
                <span className="font-mono text-stone-600 text-[11px]">
                  {partner.contactMethod}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Join Network Modal */}
      {showJoinModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full text-right shadow-2xl border border-stone-200">
            <h3 className="text-xl font-bold text-[#17201D] font-serif-ar mb-2">
              طلب الانضمام لشبكة المساعدة القانونية
            </h3>
            <p className="text-xs text-stone-600 mb-6 leading-relaxed">
              نرحب بالمحامين المقيدين، الأساتذة، المترجمين، والباحثين الحقوقيين المستقلين. تخضع الطلبات للمراجعة والتحقق المهني قبل الاعتماد.
            </p>

            {joinSuccess ? (
              <div className="p-8 text-center">
                <CheckCircle className="w-12 h-12 text-[#0B5145] mx-auto mb-3" />
                <h4 className="text-lg font-bold text-stone-900 mb-1">تم إرسال طلبك بنجاح</h4>
                <p className="text-xs text-stone-600">سيتواصل معك منسق الشبكة للتحقق من بيانات القيد وإتاحة بوابة التنسيق الآمنة.</p>
                <button
                  onClick={() => { setShowJoinModal(false); setJoinSuccess(false); }}
                  className="mt-4 px-5 py-2 bg-[#0B5145] text-white text-xs font-semibold rounded-xl"
                >
                  إغلاق
                </button>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setJoinSuccess(true); }} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">الاسم الكامل</label>
                  <input required type="text" placeholder="الاسم كما في بطاقة القيد المهني" className="w-full p-2.5 rounded-xl border border-stone-300" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">الصفة</label>
                    <select className="w-full p-2.5 rounded-xl border border-stone-300">
                      <option>محامٍ معتمد</option>
                      <option>باحث حقوقي</option>
                      <option>مترجم قانوني</option>
                      <option>صحفي استقصائي</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">الدولة</label>
                    <input required type="text" placeholder="مصر، تونس، المغرب..." className="w-full p-2.5 rounded-xl border border-stone-300" />
                  </div>
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">رقم القيد أو رابط الهيئة المهنية</label>
                  <input required type="text" placeholder="رقم القيد في نقابة المحامين أو الهيئة المعتمدة" className="w-full p-2.5 rounded-xl border border-stone-300" />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">وسيلة التواصل الآمنة (Signal / البريد)</label>
                  <input required type="text" placeholder="signal: +xxx... أو email@bar.org" className="w-full p-2.5 rounded-xl border border-stone-300" />
                </div>

                <div className="flex items-center justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowJoinModal(false)}
                    className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-[#0B5145] text-white font-semibold rounded-xl hover:bg-[#083B32]"
                  >
                    إرسال الطلب للاعتماد
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
