import React from 'react';
import { CaseItem } from '../types';
import { ArrowLeft, Check, AlertTriangle, Clock, MapPin, FileText } from 'lucide-react';

interface CasesDeserveToBeKnownProps {
  cases: CaseItem[];
  onOpenCase: (caseId: string) => void;
  onViewAll: () => void;
}

export const CasesDeserveToBeKnown: React.FC<CasesDeserveToBeKnownProps> = ({
  cases,
  onOpenCase,
  onViewAll,
}) => {
  // Select 3 standout documentary cases
  const displayedCases = cases.slice(1, 4);

  return (
    <section className="py-14 sm:py-20 bg-white border-t border-stone-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header with View All Link */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12 pb-6 border-b border-stone-200">
          <div>
            <span className="text-xs font-mono font-bold uppercase text-[#0B5145] tracking-widest block mb-1">
              رحلة التوثيق الإنساني
            </span>
            <h2 className="text-2xl sm:text-4xl font-bold text-[#17201D] font-serif-ar">
              قضايا تستحق أن تُعرف
            </h2>
            <p className="text-stone-600 text-sm mt-1 max-w-xl">
              ملفات حقوقية موثقة تخضع لمتابعة يومية مستمرة، نفصل فيها بدقة بين ما تم إثباته بالوثائق وما لا يزال قيد التحقق.
            </p>
          </div>

          <button
            onClick={onViewAll}
            className="inline-flex items-center gap-2 text-sm font-bold text-[#0B5145] hover:text-[#083B32] transition-colors group cursor-pointer"
          >
            <span>عرض أرشيف جميع القضايا</span>
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          </button>
        </div>

        {/* List of Large Documentary Cards */}
        <div className="space-y-12 sm:space-y-16">
          {displayedCases.map((caseItem, index) => {
            const indexStr = (index + 1).toString().padStart(2, '0');
            const isVerified = caseItem.status === 'verified';
            const isUrgent = caseItem.status === 'urgent';

            return (
              <div
                key={caseItem.id}
                className="bg-[#FBF9F5] rounded-3xl border border-stone-200/80 p-6 sm:p-8 lg:p-10 shadow-sm hover:shadow-md transition-shadow grid grid-cols-1 lg:grid-cols-12 gap-8 items-center"
              >
                {/* Visual Area */}
                <div className="lg:col-span-5 relative rounded-2xl overflow-hidden aspect-[4/3] bg-stone-900 shadow">
                  <img
                    src={caseItem.image}
                    alt={caseItem.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  
                  {/* Chapter number watermark */}
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-lg text-xs font-mono font-bold text-[#0B5145]">
                    {indexStr} · {caseItem.id}
                  </div>

                  {/* Status chip */}
                  <div className="absolute bottom-4 right-4 left-4 flex items-center justify-between text-white text-xs">
                    <span className="flex items-center gap-1 font-medium">
                      <MapPin className="w-3.5 h-3.5 text-stone-300" />
                      {caseItem.country}
                    </span>

                    <span className={`px-2.5 py-0.5 rounded-md font-semibold text-[11px] ${
                      isUrgent ? 'bg-rose-600 text-white' : isVerified ? 'bg-emerald-700 text-white' : 'bg-amber-600 text-white'
                    }`}>
                      {isUrgent ? 'عاجلة' : isVerified ? 'موثقة' : 'قيد التحقق'}
                    </span>
                  </div>
                </div>

                {/* Editorial Content */}
                <div className="lg:col-span-7 flex flex-col justify-between h-full text-right">
                  <div>
                    {/* Header meta */}
                    <div className="flex items-center justify-between text-xs text-stone-500 mb-2 font-mono">
                      <span>{caseItem.stats.sourcesCount} مصادر · {caseItem.stats.documentsCount} وثائق</span>
                      <span>تحديث: {caseItem.lastUpdated}</span>
                    </div>

                    <h3 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar mb-3">
                      {caseItem.name}
                    </h3>

                    <p className="text-stone-700 text-sm leading-relaxed mb-6">
                      {caseItem.summary}
                    </p>

                    {/* What we know vs What is under verification */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-stone-200/80 mb-6">
                      
                      {/* What we know */}
                      <div className="bg-white/80 p-3.5 rounded-xl border border-stone-200/60">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 mb-2">
                          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>ما تم التثبت منه</span>
                        </div>
                        <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                          {caseItem.whatWeKnow[0] || 'تم فحص أصل المستندات ومطابقتها مع السجلات الرسمية.'}
                        </p>
                      </div>

                      {/* What under verification */}
                      <div className="bg-white/80 p-3.5 rounded-xl border border-stone-200/60">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-amber-800 mb-2">
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                          <span>ما لا يزال قيد التحقق</span>
                        </div>
                        <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                          {caseItem.whatUnderVerification[0] || 'بانتظار إفادات تكميلية ومحاضر رسمية إضافية.'}
                        </p>
                      </div>

                    </div>
                  </div>

                  {/* Open Dossier CTA */}
                  <div className="flex items-center justify-between pt-2">
                    <button
                      onClick={() => onOpenCase(caseItem.id)}
                      className="inline-flex items-center gap-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs sm:text-sm font-semibold px-5 py-2.5 rounded-xl shadow-sm transition-all cursor-pointer"
                    >
                      <span>شاهد ملف القضية</span>
                      <ArrowLeft className="w-4 h-4" />
                    </button>

                    {caseItem.detentionDays && (
                      <span className="text-xs font-mono text-stone-500">
                        محتجز منذ {caseItem.detentionDays} يوماً
                      </span>
                    )}
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
