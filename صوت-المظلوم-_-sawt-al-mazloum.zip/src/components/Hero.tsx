import React, { useState } from 'react';
import { Search, ArrowLeft, ShieldAlert, CheckCircle2, Clock, Globe2 } from 'lucide-react';
import { ASSET_IMAGES } from '../data/mockData';

interface HeroProps {
  onSearch: (query: string) => void;
  onTagClick: (tag: string) => void;
  onNavigateToCases: (filter?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onSearch, onTagClick, onNavigateToCases }) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput.trim());
    }
  };

  const sampleTags = [
    { label: 'CASE-EGY-042', query: 'CASE-EGY-042' },
    { label: 'CASE-TUN-014', query: 'CASE-TUN-014' },
    { label: 'CASE-MAR-007', query: 'CASE-MAR-007' },
    { label: 'مصر', query: 'مصر' },
    { label: 'اليمن', query: 'اليمن' },
    { label: 'اختفاء قسري', query: 'اختفاء' },
  ];

  return (
    <div className="relative overflow-hidden bg-[#17201D] text-white">
      {/* Background Image with measured dark scrim for accessibility */}
      <div className="absolute inset-0 z-0">
        <img
          src={ASSET_IMAGES.hero}
          alt="أرشيف التوثيق الحقوقي"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-30 mix-blend-luminosity scale-105 transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#17201D] via-[#17201D]/80 to-[#17201D]/50" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 sm:pt-24 sm:pb-28 text-center">
        
        {/* Main Display Headline */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-stone-100 font-serif-ar leading-[1.3] text-balance mb-5">
          هناك قضية لم يسمع بها أحد بعد.
        </h1>

        {/* Subtitle / Mission */}
        <p className="text-base sm:text-xl text-stone-300 max-w-2xl mx-auto font-normal leading-relaxed text-balance mb-10">
          نوثق القضايا، نتحقق من المعلومات، ونوصل الملفات الموثقة إلى من يستطيع المساعدة.
        </p>

        {/* Massive Search Bar */}
        <div className="max-w-3xl mx-auto mb-6">
          <form onSubmit={handleSubmit} className="relative flex items-center">
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="ابحث عن قضية، شخص، رقم قضية (مثلاً: CASE-EGY-042)، أو دولة..."
              className="w-full pr-13 pl-32 py-4 sm:py-5 rounded-2xl bg-white text-[#17201D] placeholder-stone-400 text-sm sm:text-base shadow-2xl focus:outline-none focus:ring-3 focus:ring-[#0B5145] transition-all"
            />
            <div className="absolute right-4 text-stone-400 pointer-events-none">
              <Search className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <button
              type="submit"
              className="absolute left-2.5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs sm:text-sm font-semibold px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <span>بحث</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Filter Tags */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-4 text-xs">
            <span className="text-stone-400 ml-1">تصفح سريع:</span>
            {sampleTags.map((tag) => (
              <button
                key={tag.label}
                onClick={() => {
                  setSearchInput(tag.query);
                  onTagClick(tag.query);
                }}
                className="px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 text-stone-300 hover:text-white transition-colors cursor-pointer font-mono text-[11px]"
              >
                {tag.label}
              </button>
            ))}
          </div>
        </div>

        {/* Real Live Metrics Bar */}
        <div className="max-w-4xl mx-auto mt-12 pt-8 border-t border-white/10 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          
          <button 
            onClick={() => onNavigateToCases('verified')}
            className="p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group text-right sm:text-center"
          >
            <div className="text-2xl sm:text-3xl font-bold text-stone-100 tabular-nums font-serif-ar group-hover:text-emerald-400 transition-colors">
              128
            </div>
            <div className="flex items-center justify-center gap-1.5 text-xs text-stone-400 mt-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>قضية موثقة</span>
            </div>
          </button>

          <button 
            onClick={() => onNavigateToCases('urgent')}
            className="p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group text-right sm:text-center"
          >
            <div className="text-2xl sm:text-3xl font-bold text-stone-100 tabular-nums font-serif-ar group-hover:text-rose-400 transition-colors">
              17
            </div>
            <div className="flex items-center justify-center gap-1.5 text-xs text-stone-400 mt-1">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
              <span>قضية عاجلة</span>
            </div>
          </button>

          <button 
            onClick={() => onNavigateToCases('investigating')}
            className="p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group text-right sm:text-center"
          >
            <div className="text-2xl sm:text-3xl font-bold text-stone-100 tabular-nums font-serif-ar group-hover:text-amber-400 transition-colors">
              42
            </div>
            <div className="flex items-center justify-center gap-1.5 text-xs text-stone-400 mt-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>قيد التحقق</span>
            </div>
          </button>

          <button 
            onClick={() => onNavigateToCases('all')}
            className="p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group text-right sm:text-center"
          >
            <div className="text-2xl sm:text-3xl font-bold text-stone-100 tabular-nums font-serif-ar group-hover:text-sky-400 transition-colors">
              12
            </div>
            <div className="flex items-center justify-center gap-1.5 text-xs text-stone-400 mt-1">
              <Globe2 className="w-3.5 h-3.5 text-sky-400" />
              <span>دولة مشمولة</span>
            </div>
          </button>

        </div>

      </div>
    </div>
  );
};
