import React, { useState } from 'react';
import { CountryPriority } from '../types';
import { Globe, ArrowLeft, Search, CheckCircle, ShieldAlert, Clock } from 'lucide-react';

interface CountriesViewProps {
  countries: CountryPriority[];
  onSelectCountry: (countryName: string) => void;
}

export const CountriesView: React.FC<CountriesViewProps> = ({
  countries,
  onSelectCountry,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCountries = countries.filter(c => 
    c.nameAr.includes(searchTerm) || c.nameEn.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => b.priorityScore - a.priorityScore);

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-10 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header */}
        <div className="max-w-3xl mb-8">
          <span className="text-xs font-mono font-bold uppercase text-[#0B5145] tracking-widest block mb-1">
            الأرشيف الإقليمي
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-2">
            ملفات الدول العربية وأولوية المتابعة
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            يُحتسب مؤشر أولوية المتابعة دورياً بناءً على كثافة البلاغات الموثقة، وجود مواعيد محاكمات وشيكة، ومدى خطورة الانتهاكات الجارية.
          </p>
        </div>

        {/* Search Input */}
        <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-sm mb-8 max-w-md">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث عن دولة عربية..."
              className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0B5145]"
            />
            <Search className="absolute right-3 top-3 w-4 h-4 text-stone-400" />
          </div>
        </div>

        {/* Country Archive Table / Cards */}
        <div className="bg-white rounded-3xl border border-stone-200/80 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="bg-stone-50 border-b border-stone-200 text-xs font-bold text-stone-600 font-mono">
                  <th className="py-4 px-6">الدولة</th>
                  <th className="py-4 px-6 text-center">إجمالي القضايا</th>
                  <th className="py-4 px-6 text-center">قضايا موثقة</th>
                  <th className="py-4 px-6 text-center">قضايا عاجلة</th>
                  <th className="py-4 px-6 text-center">قيد التحقق</th>
                  <th className="py-4 px-6">آخر تحديث</th>
                  <th className="py-4 px-6 text-left">الملف التوثيقي</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 text-xs sm:text-sm">
                {filteredCountries.map((c) => (
                  <tr key={c.code} className="hover:bg-stone-50/80 transition-colors">
                    <td className="py-4 px-6 font-bold text-stone-900">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#0B5145]" />
                        <span className="text-base font-serif-ar">{c.nameAr}</span>
                        <span className="text-xs font-mono text-stone-400">({c.code})</span>
                      </div>
                    </td>

                    <td className="py-4 px-6 text-center font-bold tabular-nums text-stone-800 text-base">
                      {c.totalCases}
                    </td>

                    <td className="py-4 px-6 text-center">
                      <span className="inline-flex items-center gap-1 font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md tabular-nums">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                        {c.verifiedCases}
                      </span>
                    </td>

                    <td className="py-4 px-6 text-center">
                      <span className="inline-flex items-center gap-1 font-semibold text-rose-800 bg-rose-50 px-2.5 py-1 rounded-md tabular-nums">
                        <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                        {c.urgentCases}
                      </span>
                    </td>

                    <td className="py-4 px-6 text-center">
                      <span className="inline-flex items-center gap-1 font-semibold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-md tabular-nums">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        {c.investigatingCases}
                      </span>
                    </td>

                    <td className="py-4 px-6 text-stone-500 font-mono text-xs">
                      {c.lastUpdate}
                    </td>

                    <td className="py-4 px-6 text-left">
                      <button
                        onClick={() => onSelectCountry(c.nameAr)}
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0B5145] hover:text-[#083B32] hover:underline cursor-pointer"
                      >
                        <span>قضايا {c.nameAr}</span>
                        <ArrowLeft className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};
