import React from 'react';
import { CaseItem, VerificationStage } from '../../types';
import { 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  AlertOctagon, 
  Megaphone, 
  AlertTriangle, 
  ArrowLeft, 
  MapPin, 
  FileText, 
  Layers, 
  History, 
  User, 
  ShieldAlert,
  ArrowRight,
  Filter,
  Plus
} from 'lucide-react';
import { INITIAL_CONTRADICTIONS, INITIAL_ACTIVITY_LOGS } from '../../data/mockData';

interface AdminOverviewViewProps {
  cases: CaseItem[];
  onOpenCaseDetail: (caseId: string) => void;
  onNavigateSection: (section: any) => void;
  onAddNewCase: () => void;
  onUpdateCase?: (updatedCase: CaseItem) => void;
}

export const AdminOverviewView: React.FC<AdminOverviewViewProps> = ({
  cases,
  onOpenCaseDetail,
  onNavigateSection,
  onAddNewCase,
  onUpdateCase,
}) => {
  // Top 5 cases needing immediate attention (urgent or under verification or high risk)
  const attentionCases = cases
    .filter(c => c.status === 'urgent' || c.status === 'investigating' || c.riskAssessment === 'حرج' || c.riskAssessment === 'عالي')
    .slice(0, 5);

  return (
    <div className="space-y-10 text-right pb-12">
      
      {/* 1. Header Greeting & Command Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-stone-200">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#DCEBE4] text-[#0B5145] text-xs font-bold mb-2">
            <span className="w-2 h-2 rounded-full bg-[#0B5145] animate-pulse" />
            <span>غرفة العمليات المركزية النشطة</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#17201D] font-serif-ar">
            صباح الخير، مدير المنصة
          </h1>
          <p className="text-stone-600 text-xs sm:text-sm mt-1">
            هذه نظرة عامة على حالة القضايا والمنصة اليوم، مع 7 حالات تتطلب قراراً تحريرياً أو قانونياً عاجلاً.
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={() => onNavigateSection('logs')}
            className="px-3.5 py-2 rounded-xl bg-white border border-stone-300 text-stone-700 hover:bg-stone-50 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
          >
            <History className="w-3.5 h-3.5 text-stone-500" />
            <span>سجل الأنشطة الميدانية</span>
          </button>

          <button
            onClick={onAddNewCase}
            className="px-4 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>+ إضافة قضية جديدة</span>
          </button>
        </div>
      </div>

      {/* 2. Six Big Statistic Cards */}
      <div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          
          {/* Stat 1: New Cases */}
          <div 
            onClick={() => onNavigateSection('new_cases')}
            className="p-5 rounded-2xl bg-white border border-stone-200/90 shadow-sm hover:shadow-md hover:border-[#0B5145] transition-all cursor-pointer group text-right"
          >
            <div className="flex items-center justify-between text-stone-400 mb-2">
              <span className="text-xs font-bold text-stone-700">القضايا الجديدة</span>
              <Sparkles className="w-4 h-4 text-[#0B5145] group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-bold font-serif-ar text-[#17201D] tabular-nums group-hover:text-[#0B5145] transition-colors">
              24
            </div>
            <span className="text-[10px] text-stone-500 mt-1 block">واردة هذا الأسبوع</span>
          </div>

          {/* Stat 2: Investigating */}
          <div 
            onClick={() => onNavigateSection('investigating')}
            className="p-5 rounded-2xl bg-white border border-stone-200/90 shadow-sm hover:shadow-md hover:border-amber-500 transition-all cursor-pointer group text-right"
          >
            <div className="flex items-center justify-between text-stone-400 mb-2">
              <span className="text-xs font-bold text-stone-700">قيد التحقق</span>
              <Clock className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-bold font-serif-ar text-[#17201D] tabular-nums group-hover:text-amber-700 transition-colors">
              17
            </div>
            <span className="text-[10px] text-amber-700 mt-1 block">بانتظار مطابقة الوثائق</span>
          </div>

          {/* Stat 3: Verified */}
          <div 
            onClick={() => onNavigateSection('verified')}
            className="p-5 rounded-2xl bg-white border border-stone-200/90 shadow-sm hover:shadow-md hover:border-[#0B5145] transition-all cursor-pointer group text-right"
          >
            <div className="flex items-center justify-between text-stone-400 mb-2">
              <span className="text-xs font-bold text-stone-700">القضايا الموثقة</span>
              <CheckCircle2 className="w-4 h-4 text-[#0B5145] group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-bold font-serif-ar text-[#0B5145] tabular-nums">
              86
            </div>
            <span className="text-[10px] text-stone-500 mt-1 block">مكتملة الأدلة ومنشورة</span>
          </div>

          {/* Stat 4: Urgent */}
          <div 
            onClick={() => onNavigateSection('urgent')}
            className="p-5 rounded-2xl bg-white border-2 border-rose-200 shadow-sm hover:shadow-md hover:border-rose-500 transition-all cursor-pointer group text-right bg-rose-50/20"
          >
            <div className="flex items-center justify-between text-stone-400 mb-2">
              <span className="text-xs font-bold text-rose-900">القضايا العاجلة</span>
              <AlertOctagon className="w-4 h-4 text-rose-600 group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-bold font-serif-ar text-rose-700 tabular-nums">
              7
            </div>
            <span className="text-[10px] text-rose-700 font-bold mt-1 block">خطر صحي أو جلسة وشيكة</span>
          </div>

          {/* Stat 5: Campaigns */}
          <div 
            onClick={() => onNavigateSection('campaigns')}
            className="p-5 rounded-2xl bg-white border border-stone-200/90 shadow-sm hover:shadow-md hover:border-[#0B5145] transition-all cursor-pointer group text-right"
          >
            <div className="flex items-center justify-between text-stone-400 mb-2">
              <span className="text-xs font-bold text-stone-700">الحملات النشطة</span>
              <Megaphone className="w-4 h-4 text-[#0B5145] group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-bold font-serif-ar text-[#17201D] tabular-nums group-hover:text-[#0B5145] transition-colors">
              12
            </div>
            <span className="text-[10px] text-stone-500 mt-1 block">مطالب قانونية جارية</span>
          </div>

          {/* Stat 6: Needs Review */}
          <div 
            onClick={() => onNavigateSection('submissions')}
            className="p-5 rounded-2xl bg-white border border-amber-200 shadow-sm hover:shadow-md hover:border-amber-500 transition-all cursor-pointer group text-right bg-amber-50/20"
          >
            <div className="flex items-center justify-between text-stone-400 mb-2">
              <span className="text-xs font-bold text-amber-900">تحتاج إلى مراجعة</span>
              <AlertTriangle className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-3xl font-bold font-serif-ar text-amber-800 tabular-nums">
              9
            </div>
            <span className="text-[10px] text-amber-800 font-semibold mt-1 block">بلاغات بانتظار الفحص</span>
          </div>

        </div>
      </div>

      {/* Contradiction Urgent Warning Bar */}
      {INITIAL_CONTRADICTIONS.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-right">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-200/80 text-amber-900 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 text-amber-800" />
            </div>
            <div>
              <span className="text-xs font-bold text-amber-950 block">
                تنبيه تضارب وتعارض في الأدلة: {INITIAL_CONTRADICTIONS[0].title}
              </span>
              <p className="text-xs text-amber-900 mt-0.5 line-clamp-1">
                {INITIAL_CONTRADICTIONS[0].sourceA} — {INITIAL_CONTRADICTIONS[0].sourceB}
              </p>
            </div>
          </div>
          <button
            onClick={() => onOpenCaseDetail(INITIAL_CONTRADICTIONS[0].caseId)}
            className="px-4 py-2 bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold rounded-xl self-end sm:self-auto cursor-pointer transition-colors whitespace-nowrap"
          >
            فتح التحقيق وحسم التناقض ←
          </button>
        </div>
      )}

      {/* 4. Section: تحتاج انتباهك الآن (5 Large Cases) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
              <AlertOctagon className="w-5 h-5 text-rose-600" />
              <span>تحتاج انتباهك الآن</span>
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              قضايا ذات أولوية قصوى تتطلب تدخلاً قانونياً أو مراجعة بشرية فورية
            </p>
          </div>

          <button
            onClick={() => onNavigateSection('cases')}
            className="text-xs font-bold text-[#0B5145] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>عرض جميع القضايا (128)</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 5 Big Cases Cards */}
        <div className="space-y-4">
          {attentionCases.map((caseItem) => {
            const isUrgent = caseItem.status === 'urgent';
            const isVerified = caseItem.status === 'verified';

            return (
              <div
                key={caseItem.id}
                className="bg-white rounded-3xl border border-stone-200/90 p-5 sm:p-6 shadow-sm hover:shadow-md transition-shadow grid grid-cols-1 lg:grid-cols-12 gap-5 items-center"
              >
                {/* Photo Area */}
                <div className="lg:col-span-3 aspect-[4/3] rounded-2xl overflow-hidden bg-stone-900 relative shadow-sm">
                  <img
                    src={caseItem.image}
                    alt={caseItem.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  
                  <div className="absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-md bg-black/60 backdrop-blur-sm text-white font-mono text-[11px] font-bold">
                    {caseItem.id}
                  </div>

                  <div className="absolute bottom-2.5 right-2.5 left-2.5 text-white text-xs">
                    <span className="flex items-center gap-1 font-semibold text-[11px]">
                      <MapPin className="w-3 h-3 text-stone-300" />
                      {caseItem.country} · {caseItem.city}
                    </span>
                  </div>
                </div>

                {/* Information Core */}
                <div className="lg:col-span-6 flex flex-col justify-between">
                  <div>
                    {/* Status & Severity badges */}
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      {isUrgent && (
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-600 animate-pulse" />
                          عاجلة
                        </span>
                      )}
                      
                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        isVerified ? 'bg-emerald-100 text-[#0B5145]' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {isVerified ? '🟢 موثقة' : '🟡 قيد التحقق'}
                      </span>

                      <span className="text-[11px] px-2 py-0.5 rounded bg-stone-100 text-stone-700 font-medium">
                        الخطورة: <strong className="text-stone-900">{caseItem.riskAssessment || 'عالي'}</strong>
                      </span>

                      <span className="text-stone-300">·</span>
                      <span className="text-[11px] text-stone-500 font-mono">
                        آخر تحديث: {caseItem.lastUpdated}
                      </span>
                    </div>

                    {/* Name */}
                    <h3 className="text-xl font-bold text-[#17201D] font-serif-ar mb-1">
                      {caseItem.name} {caseItem.alias ? <span className="text-xs text-stone-400 font-normal font-sans">({caseItem.alias})</span> : null}
                    </h3>

                    {/* Summary */}
                    <p className="text-xs sm:text-sm text-stone-600 line-clamp-2 leading-relaxed mb-3">
                      {caseItem.summary}
                    </p>

                    {/* Stats & Assignee Row */}
                    <div className="flex flex-wrap items-center gap-3 text-xs font-mono text-stone-500 pt-2 border-t border-stone-100">
                      <span className="font-bold text-stone-800">{caseItem.stats.sourcesCount} مصادر</span>
                      <span>·</span>
                      <span className="font-bold text-stone-800">{caseItem.stats.documentsCount} وثائق</span>
                      <span>·</span>
                      <span>{caseItem.stats.updatesCount} تحديثات</span>
                      <span>·</span>
                      <span className="text-stone-600 flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-[#0B5145]" />
                        {caseItem.leadResearcher || 'سارة الشامي'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action CTA */}
                <div className="lg:col-span-3 flex flex-col justify-between items-end gap-3 pt-3 lg:pt-0 border-t lg:border-t-0 lg:border-r border-stone-100 lg:pr-5 h-full">
                  <div className="text-right w-full">
                    <span className="text-[11px] text-stone-400 block mb-0.5">نوع القضية</span>
                    <span className="text-xs font-bold text-stone-800 bg-stone-100 px-2 py-0.5 rounded">
                      {caseItem.caseType === 'detention' ? 'احتجاز تعسفي' :
                       caseItem.caseType === 'disappearance' ? 'اختفاء قسري ومفقودين' :
                       caseItem.caseType === 'fair_trial' ? 'محاكمة غير عادلة' : 'انتهاك حقوقي'}
                    </span>
                  </div>

                  <button
                    onClick={() => onOpenCaseDetail(caseItem.id)}
                    className="w-full py-3 px-5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                  >
                    <span>فتح ملف القضية</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Live Activity Snippet (matching item 12 in user prompt) */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/80 shadow-sm text-right">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-stone-100">
          <h3 className="text-base font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <History className="w-4 h-4 text-[#0B5145]" />
            <span>سجل النشاط الميداني المباشر (Activity Log)</span>
          </h3>
          <button
            onClick={() => onNavigateSection('logs')}
            className="text-xs text-[#0B5145] font-semibold hover:underline cursor-pointer"
          >
            عرض السجل الكامل
          </button>
        </div>

        <div className="divide-y divide-stone-100 text-xs">
          {INITIAL_ACTIVITY_LOGS.slice(0, 3).map((log) => (
            <div key={log.id} className="py-3 flex items-start justify-between gap-4">
              <div>
                <strong className="text-stone-900 font-bold ml-1">{log.user} — {log.role}:</strong>
                <span className="text-stone-700">{log.action}</span>
              </div>
              <span className="text-stone-400 font-mono text-[11px] shrink-0">{log.timeAgo}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
