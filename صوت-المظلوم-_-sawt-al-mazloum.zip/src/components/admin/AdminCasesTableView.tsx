import React, { useState, useMemo } from 'react';
import { CaseItem, VerificationStatus, CaseType } from '../../types';
import { 
  Search, 
  Filter, 
  Download, 
  Plus, 
  Eye, 
  Edit3, 
  MoreHorizontal, 
  CheckCircle2, 
  AlertOctagon, 
  Clock, 
  AlertCircle,
  X,
  FileSpreadsheet,
  Check
} from 'lucide-react';

interface AdminCasesTableViewProps {
  cases: CaseItem[];
  onOpenCaseDetail: (caseId: string) => void;
  onAddNewCase: () => void;
  initialFilter?: string;
}

export const AdminCasesTableView: React.FC<AdminCasesTableViewProps> = ({
  cases,
  onOpenCaseDetail,
  onAddNewCase,
  initialFilter = 'all',
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(initialFilter);
  const [countryFilter, setCountryFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'created' | 'progress'>('latest');
  const [exportedToast, setExportedToast] = useState(false);

  // Available countries
  const countries = useMemo(() => {
    return Array.from(new Set(cases.map(c => c.country))).sort();
  }, [cases]);

  // Filtered and sorted
  const filteredCases = useMemo(() => {
    return cases.filter(item => {
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchId = item.id.toLowerCase().includes(q);
        const matchName = item.name.toLowerCase().includes(q);
        const matchCountry = item.country.toLowerCase().includes(q);
        const matchCity = item.city.toLowerCase().includes(q);
        const matchLead = (item.leadResearcher || '').toLowerCase().includes(q);
        if (!matchId && !matchName && !matchCountry && !matchCity && !matchLead) {
          return false;
        }
      }

      if (statusFilter !== 'all') {
        if (item.status !== statusFilter) return false;
      }

      if (countryFilter !== 'all' && item.country !== countryFilter) {
        return false;
      }

      if (typeFilter !== 'all' && item.caseType !== typeFilter) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'progress') {
        return (b.verificationProgress || 50) - (a.verificationProgress || 50);
      }
      if (sortBy === 'created') {
        return (b.createdDate || '').localeCompare(a.createdDate || '');
      }
      return (b.lastUpdated || '').localeCompare(a.lastUpdated || '');
    });
  }, [cases, searchTerm, statusFilter, countryFilter, typeFilter, sortBy]);

  const handleExportCsv = () => {
    const headers = ['رقم القضية', 'الاسم', 'الدولة', 'المدينة', 'الحالة', 'نوع القضية', 'المسؤول', 'آخر تحديث'];
    const rows = filteredCases.map(c => [
      c.id,
      `"${c.name}"`,
      c.country,
      c.city,
      c.status,
      c.caseType,
      `"${c.leadResearcher || 'سارة الشامي'}"`,
      c.lastUpdated
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sawt_almazloum_cases_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportedToast(true);
    setTimeout(() => setExportedToast(false), 2500);
  };

  const getStatusBadge = (status: VerificationStatus) => {
    switch (status) {
      case 'verified':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">🟢 موثقة</span>;
      case 'investigating':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">🟡 قيد التحقق</span>;
      case 'needs_evidence':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-orange-100 text-orange-800">🟠 تحتاج أدلة</span>;
      case 'urgent':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 animate-pulse">🔴 عاجلة</span>;
      case 'closed':
        return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-stone-200 text-stone-800">⚫ مغلقة</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-stone-100 text-stone-700">قيد المراجعة</span>;
    }
  };

  return (
    <div className="space-y-6 text-right pb-12">
      
      {/* Table Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar">
            جميع القضايا والملفات
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            إدارة السجلات التوثيقية، مراجعة الأدلة، ومتابعة إحالات المحامين
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 rounded-xl bg-white border border-stone-300 text-stone-700 hover:bg-stone-50 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-[#0B5145]" />
            <span>تصدير البيانات (CSV)</span>
          </button>

          <button
            onClick={onAddNewCase}
            className="px-4 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة قضية جديدة</span>
          </button>
        </div>
      </div>

      {exportedToast && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>تم تصدير ملف الإكسل (CSV) بنجاح إلى جهازك.</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-3xl p-5 border border-stone-200/90 shadow-sm space-y-4">
        
        {/* Search */}
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ابحث برقم القضية (CASE-EGY-0042)، اسم المعتقل، الدولة، أو الباحث..."
            className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0B5145] focus:bg-white transition-all"
          />
          <Search className="absolute right-3.5 top-3 w-4 h-4 text-stone-400 pointer-events-none" />
        </div>

        {/* Filter Controls Row */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">الحالة</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-semibold text-stone-800 cursor-pointer"
            >
              <option value="all">كافة الحالات ({cases.length})</option>
              <option value="verified">🟢 موثقة</option>
              <option value="investigating">🟡 قيد التحقق</option>
              <option value="needs_evidence">🟠 تحتاج أدلة</option>
              <option value="urgent">🔴 عاجلة</option>
              <option value="closed">⚫ مغلقة</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">الدولة</label>
            <select
              value={countryFilter}
              onChange={(e) => setCountryFilter(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-semibold text-stone-800 cursor-pointer"
            >
              <option value="all">كافة الدول ({countries.length})</option>
              {countries.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">نوع القضية</label>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-semibold text-stone-800 cursor-pointer"
            >
              <option value="all">كافة الأنواع</option>
              <option value="detention">احتجاز تعسفي</option>
              <option value="disappearance">اختفاء ومفقودين</option>
              <option value="fair_trial">محاكمة غير عادلة</option>
              <option value="human_rights">انتهاك حقوقي</option>
              <option value="custody_death">إهمال صحي وخطر وفاة</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">الترتيب</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full p-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-semibold text-stone-800 cursor-pointer"
            >
              <option value="latest">آخر التحديثات</option>
              <option value="created">تاريخ الإنشاء</option>
              <option value="progress">أعلى نسبة اكتمال تحقق</option>
            </select>
          </div>

        </div>

        {/* Results Count bar */}
        <div className="flex items-center justify-between pt-2 border-t border-stone-100 text-xs text-stone-500">
          <span>يتم عرض <strong className="text-stone-900 font-bold">{filteredCases.length}</strong> قضية</span>
          {(searchTerm || statusFilter !== 'all' || countryFilter !== 'all' || typeFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('all');
                setCountryFilter('all');
                setTypeFilter('all');
              }}
              className="text-[#0B5145] font-semibold hover:underline cursor-pointer"
            >
              إعادة ضبط الفلاتر
            </button>
          )}
        </div>

      </div>

      {/* Main Table */}
      <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse text-xs">
            <thead>
              <tr className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold font-mono">
                <th className="py-3.5 px-4">رقم القضية</th>
                <th className="py-3.5 px-4">الشخص المعني</th>
                <th className="py-3.5 px-4">الدولة</th>
                <th className="py-3.5 px-4">نوع القضية</th>
                <th className="py-3.5 px-4">الحالة</th>
                <th className="py-3.5 px-4 text-center">مستوى التحقق</th>
                <th className="py-3.5 px-4">الباحث المسؤول</th>
                <th className="py-3.5 px-4">آخر تحديث</th>
                <th className="py-3.5 px-4">تاريخ الإنشاء</th>
                <th className="py-3.5 px-4 text-left">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredCases.map((caseItem) => (
                <tr 
                  key={caseItem.id} 
                  className="hover:bg-stone-50/80 transition-colors group cursor-pointer"
                  onClick={() => onOpenCaseDetail(caseItem.id)}
                >
                  <td className="py-3.5 px-4 font-mono font-bold text-[#0B5145]">
                    {caseItem.id}
                  </td>

                  <td className="py-3.5 px-4 font-bold text-stone-900">
                    <div className="flex items-center gap-2">
                      <img
                        src={caseItem.image}
                        alt=""
                        className="w-7 h-7 rounded-lg object-cover"
                      />
                      <span>{caseItem.name}</span>
                    </div>
                  </td>

                  <td className="py-3.5 px-4 text-stone-700">
                    {caseItem.country}
                  </td>

                  <td className="py-3.5 px-4 text-stone-600">
                    {caseItem.caseType === 'detention' ? 'احتجاز تعسفي' :
                     caseItem.caseType === 'disappearance' ? 'اختفاء قسري' :
                     caseItem.caseType === 'fair_trial' ? 'محاكمة' : 'انتهاك حقوقي'}
                  </td>

                  <td className="py-3.5 px-4">
                    {getStatusBadge(caseItem.status)}
                  </td>

                  <td className="py-3.5 px-4 text-center">
                    <div className="inline-flex items-center gap-1.5 font-mono text-[11px] font-bold text-stone-700">
                      <div className="w-12 h-2 rounded-full bg-stone-100 overflow-hidden">
                        <div
                          className="h-full bg-[#0B5145] rounded-full"
                          style={{ width: `${caseItem.verificationProgress || 70}%` }}
                        />
                      </div>
                      <span>{caseItem.verificationProgress || 70}%</span>
                    </div>
                  </td>

                  <td className="py-3.5 px-4 text-stone-600 font-mono text-[11px]">
                    {caseItem.leadResearcher || 'سارة الشامي'}
                  </td>

                  <td className="py-3.5 px-4 text-stone-500 font-mono text-[11px]">
                    {caseItem.lastUpdated}
                  </td>

                  <td className="py-3.5 px-4 text-stone-400 font-mono text-[11px]">
                    {caseItem.createdDate || caseItem.incidentDate}
                  </td>

                  <td className="py-3.5 px-4 text-left" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => onOpenCaseDetail(caseItem.id)}
                      className="px-3 py-1.5 rounded-lg bg-[#0B5145]/10 hover:bg-[#0B5145] text-[#0B5145] hover:text-white font-semibold text-xs transition-colors cursor-pointer"
                    >
                      فتح الملف
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
