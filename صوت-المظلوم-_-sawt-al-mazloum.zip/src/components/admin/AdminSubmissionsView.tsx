import React, { useState } from 'react';
import { SubmissionReport } from '../../types';
import { 
  Inbox, 
  Check, 
  X, 
  HelpCircle, 
  UserCheck, 
  FileText, 
  ShieldAlert, 
  Search, 
  Filter,
  CheckCircle2
} from 'lucide-react';
import { INBOUND_SUBMISSIONS } from '../../data/mockData';

export const AdminSubmissionsView: React.FC = () => {
  const [submissions, setSubmissions] = useState<SubmissionReport[]>(INBOUND_SUBMISSIONS);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleAction = (id: string, action: 'accept' | 'request_info' | 'reject' | 'assign') => {
    setSubmissions(prev => prev.map(s => {
      if (s.trackingId === id || s.id === id) {
        if (action === 'accept') {
          return { ...s, status: 'verified_in_pipeline', statusTextAr: 'تم القبول والإحالة لمسار التوثيق' };
        } else if (action === 'request_info') {
          return { ...s, status: 'evidence_requested', statusTextAr: 'تم طلب إفادات ومستندات إضافية' };
        } else if (action === 'reject') {
          return { ...s, status: 'rejected', statusTextAr: 'تم الرفض لعدم الاختصاص أو نقص الإثبات' };
        } else if (action === 'assign') {
          return { ...s, status: 'under_review', statusTextAr: 'تم تعيين باحث مختص لفحص الملف' };
        }
      }
      return s;
    }));

    const textMap = {
      accept: 'تم قبول البلاغ وإدراجه في مسار التوثيق الأولي.',
      request_info: 'تم إرسال إشعار للمرسل عبر القناة الآمنة لطلب مستندات إضافية.',
      reject: 'تم رفض البلاغ وحفظ السجل مع توضيح سبب الرفض.',
      assign: 'تم تحويل البلاغ إلى وحدة الباحثين المختصة بالمتابعة الميدانية.'
    };

    setToastMessage(textMap[action]);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 text-right pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <Inbox className="w-6 h-6 text-[#0B5145]" />
            <span>البلاغات والشكاوى الواردة الجديدة</span>
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            فرز وتحقيق البلاغات الواردة من المواطنين وعائلات المحتجزين عبر القنوات المشفرة
          </p>
        </div>

        <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-amber-100 text-amber-900 self-start sm:self-auto">
          {submissions.filter(s => s.status === 'under_review').length} بلاغات قيد الفرز الفوري
        </span>
      </div>

      {toastMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-900 font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Submissions List */}
      <div className="space-y-4">
        {submissions.map((sub) => {
          const isRejected = sub.status === 'rejected';
          const isAccepted = sub.status === 'verified_in_pipeline';

          return (
            <div
              key={sub.trackingId}
              className={`bg-white rounded-3xl border p-6 shadow-sm hover:shadow-md transition-shadow text-right space-y-4 ${
                sub.riskLevel === 'حرج' ? 'border-rose-300 bg-rose-50/10' : 'border-stone-200/90'
              }`}
            >
              {/* Top row */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-stone-100 text-xs">
                <div className="flex items-center gap-2 font-mono">
                  <span className="font-bold text-[#0B5145] bg-[#0B5145]/10 px-2.5 py-1 rounded-lg">
                    {sub.trackingId}
                  </span>
                  <span className="text-stone-400">·</span>
                  <span className="text-stone-700">{sub.country} ({sub.city})</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                    sub.riskLevel === 'حرج' ? 'bg-rose-100 text-rose-800' :
                    sub.riskLevel === 'عالي' ? 'bg-amber-100 text-amber-800' : 'bg-stone-100 text-stone-700'
                  }`}>
                    خطورة: {sub.riskLevel || 'متوسط'}
                  </span>

                  <span className="text-stone-400 font-mono text-[11px]">
                    تاريخ الإرسال: {sub.submissionDate}
                  </span>
                </div>
              </div>

              {/* Main Content */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
                <div className="md:col-span-8 space-y-2">
                  <h3 className="text-base font-bold text-stone-900 font-serif-ar">
                    الشخص المعني: {sub.affectedPerson}
                  </h3>
                  <p className="text-xs text-stone-700 leading-relaxed">
                    {sub.summary}
                  </p>
                  <div className="text-[11px] text-stone-500 font-mono">
                    <strong>الأدلة المذكورة:</strong> {sub.evidenceDetails}
                  </div>
                </div>

                <div className="md:col-span-4 p-3 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-1 font-mono">
                  <div><strong>المرسل:</strong> {sub.senderName || 'مواطن (مشفر)'}</div>
                  <div><strong>القناة:</strong> {sub.contactSecure}</div>
                  <div><strong>الوثائق المرفقة:</strong> {sub.documentsCount} ملفات ({sub.hasDocuments ? 'موجودة' : 'لا توجد'})</div>
                  <div><strong>الحالة:</strong> <span className="font-bold text-[#0B5145]">{sub.statusTextAr}</span></div>
                  {sub.assignedResearcher && (
                    <div className="text-stone-600"><strong>المسؤول:</strong> {sub.assignedResearcher}</div>
                  )}
                </div>
              </div>

              {/* Action Buttons: 4 prominent actions from prompt */}
              <div className="flex flex-wrap items-center justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  onClick={() => handleAction(sub.trackingId, 'accept')}
                  className="px-3.5 py-1.5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>قبول للمراجعة</span>
                </button>

                <button
                  onClick={() => handleAction(sub.trackingId, 'request_info')}
                  className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>طلب معلومات إضافية</span>
                </button>

                <button
                  onClick={() => handleAction(sub.trackingId, 'assign')}
                  className="px-3.5 py-1.5 bg-white border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <UserCheck className="w-3.5 h-3.5 text-[#0B5145]" />
                  <span>تحويل إلى باحث</span>
                </button>

                <button
                  onClick={() => handleAction(sub.trackingId, 'reject')}
                  className="px-3.5 py-1.5 bg-stone-100 hover:bg-rose-50 text-stone-700 hover:text-rose-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>رفض البلاغ</span>
                </button>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
