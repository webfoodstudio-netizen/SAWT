import React, { useState } from 'react';
import { CaseItem } from '../../types';
import { Layers, ShieldCheck, Search, Filter, Lock, Eye, ArrowLeft, CheckCircle2, UserCheck, AlertTriangle } from 'lucide-react';

interface AdminSourcesViewProps {
  cases: CaseItem[];
  onOpenCaseDetail: (caseId: string) => void;
}

export const AdminSourcesView: React.FC<AdminSourcesViewProps> = ({ cases, onOpenCaseDetail }) => {
  const [search, setSearch] = useState('');
  const [tierFilter, setTierFilter] = useState('all');

  // Extract all sources from cases evidence & timelines
  const allSources = cases.flatMap(c => {
    return c.evidence.map(e => ({
      id: e.id,
      title: e.title,
      type: e.type,
      sourceName: e.source || e.uploader || 'مصدر ميداني معتمد',
      caseId: c.id,
      caseName: c.name,
      credibility: e.credibility,
      confidentiality: e.confidentiality,
      date: e.date,
      provesWhat: e.provesWhat,
      verificationStatus: e.verificationStatus || 'verified',
    }));
  });

  const filteredSources = allSources.filter(s => {
    if (search) {
      const q = search.toLowerCase();
      const matchTitle = s.title.toLowerCase().includes(q);
      const matchSource = s.sourceName.toLowerCase().includes(q);
      const matchCase = s.caseName.toLowerCase().includes(q) || s.caseId.toLowerCase().includes(q);
      if (!matchTitle && !matchSource && !matchCase) return false;
    }
    if (tierFilter !== 'all' && s.type !== tierFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 text-right pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <Layers className="w-6 h-6 text-[#0B5145]" />
            <span>شبكة المصادر والشهود والتوثيق الميداني</span>
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            إدارة وتدقيق المصادر المستقلة مع تفعيل بروتوكول حماية الشهود والتشفير الصارم.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 bg-emerald-100 text-[#0B5145] text-xs font-bold font-mono rounded-full">
            {allSources.length} مصادر مسجلة
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالمصدر، اسم القضية، أو رقمها..."
            className="w-full pr-9 pl-3 py-2 text-xs rounded-xl bg-stone-50 border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#0B5145]"
          />
          <Search className="w-4 h-4 text-stone-400 absolute right-3 top-2.5" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={tierFilter}
            onChange={(e) => setTierFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl bg-stone-50 border border-stone-200 text-stone-700 font-semibold cursor-pointer w-full sm:w-auto"
          >
            <option value="all">كافة أنواع المصادر ({allSources.length})</option>
            <option value="official">مصادر رسمية وقضائية</option>
            <option value="testimony">شهادات أسر وشهود عيان</option>
            <option value="journalistic">تحقيقات صحفية مستقلة</option>
            <option value="legal">منظمات وهيئات قانونية</option>
          </select>
        </div>
      </div>

      {/* Sources Table */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead>
              <tr className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold font-mono">
                <th className="py-3.5 px-4">رقم القضية والمُعتقل</th>
                <th className="py-3.5 px-4">المصدر / الشاهد</th>
                <th className="py-3.5 px-4">نوع المصدر</th>
                <th className="py-3.5 px-4">درجة الموثوقية</th>
                <th className="py-3.5 px-4">مستوى السرية</th>
                <th className="py-3.5 px-4">التاريخ</th>
                <th className="py-3.5 px-4 text-left">الإجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredSources.map((source, idx) => (
                <tr key={idx} className="hover:bg-stone-50 transition-colors">
                  <td className="py-3.5 px-4">
                    <span className="font-mono font-bold text-[#0B5145] block">{source.caseId}</span>
                    <span className="text-stone-700 font-semibold text-xs font-serif-ar">{source.caseName}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-bold text-stone-900 block">{source.sourceName}</span>
                    <span className="text-stone-500 text-[11px] line-clamp-1">{source.provesWhat}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-stone-100 text-stone-700 text-[10px] font-medium font-mono">
                      {source.type === 'official' ? 'رسمي' : source.type === 'testimony' ? 'شهادة' : source.type === 'legal' ? 'قانوني' : 'صحفي'}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="inline-flex items-center gap-1 text-emerald-800 font-bold bg-emerald-50 px-2 py-0.5 rounded-full text-[10px]">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>{source.credibility === 'high' ? 'عالية ومطابقة' : 'مفحوص ومقبول'}</span>
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      source.confidentiality === 'sensitive' 
                        ? 'bg-rose-100 text-rose-800' 
                        : source.confidentiality === 'internal' 
                        ? 'bg-amber-100 text-amber-800' 
                        : 'bg-emerald-100 text-[#0B5145]'
                    }`}>
                      {source.confidentiality === 'sensitive' ? 'سري محمي' : source.confidentiality === 'internal' ? 'داخلي' : 'عام للنشر'}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-stone-500 text-[11px]">
                    {source.date}
                  </td>
                  <td className="py-3.5 px-4 text-left">
                    <button
                      onClick={() => onOpenCaseDetail(source.caseId)}
                      className="px-3 py-1 bg-stone-100 hover:bg-[#0B5145] hover:text-white text-stone-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                    >
                      فتح الملف ←
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
