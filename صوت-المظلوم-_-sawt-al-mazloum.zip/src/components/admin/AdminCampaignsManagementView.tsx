import React, { useState } from 'react';
import { CampaignItem, CaseItem } from '../../types';
import { Megaphone, Users, Share2, Plus, ArrowLeft, CheckCircle2, AlertCircle } from 'lucide-react';
import { INITIAL_CAMPAIGNS } from '../../data/mockData';

interface AdminCampaignsManagementViewProps {
  cases: CaseItem[];
  onOpenCaseDetail: (caseId: string) => void;
}

export const AdminCampaignsManagementView: React.FC<AdminCampaignsManagementViewProps> = ({
  cases,
  onOpenCaseDetail,
}) => {
  const [campaignsList, setCampaignsList] = useState<CampaignItem[]>(INITIAL_CAMPAIGNS);
  const [showNewModal, setShowNewModal] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const toggleCampaignActive = (id: string) => {
    setCampaignsList(prev => prev.map(c => {
      if (c.id === id) {
        const nextState = !c.active;
        setToastMsg(`تم تحديث حالة الحملة [${c.title}] إلى: ${nextState ? 'نشطة' : 'متوقفة مؤقتاً'}`);
        setTimeout(() => setToastMsg(null), 3000);
        return { ...c, active: nextState };
      }
      return c;
    }));
  };

  return (
    <div className="space-y-6 text-right pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <Megaphone className="w-6 h-6 text-[#0B5145]" />
            <span>إدارة حملات المناصرة والتضامن السلمي</span>
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            إدارة الحملات المربوطة بملفات القضايا الموثقة ومتابعة معدلات التوقيع والانتشار.
          </p>
        </div>

        <button
          onClick={() => setShowNewModal(true)}
          className="px-4 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ إطلاق حملة جديدة</span>
        </button>
      </div>

      {toastMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-[#0B5145] text-xs font-semibold rounded-xl flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-[#0B5145] shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Campaigns Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {campaignsList.map((camp) => {
          const progressPercent = Math.min(100, Math.round((camp.participantsCount / camp.targetCount) * 100));

          return (
            <div
              key={camp.id}
              className="bg-white rounded-3xl border border-stone-200/90 p-6 shadow-sm flex flex-col justify-between space-y-4 text-right"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs font-bold text-[#0B5145] px-2.5 py-0.5 rounded bg-[#0B5145]/10">
                    {camp.caseCode}
                  </span>

                  <button
                    onClick={() => toggleCampaignActive(camp.id)}
                    className={`px-3 py-1 rounded-full text-xs font-bold cursor-pointer transition-colors ${
                      camp.active ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-100 text-stone-600'
                    }`}
                  >
                    {camp.active ? '🟢 نشطة ومتاحة' : '⚪ متوقفة مؤقتاً'}
                  </button>
                </div>

                <h3 className="text-lg font-bold text-stone-900 font-serif-ar mb-1">
                  {camp.title}
                </h3>

                <p className="text-xs text-stone-600 leading-relaxed mb-4">
                  <strong>المطلب الحقوقي:</strong> {camp.demand}
                </p>

                {/* Progress bar */}
                <div className="space-y-1.5 mb-4">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-stone-500 font-sans">
                      {camp.participantsCount.toLocaleString('ar-EG')} من {camp.targetCount.toLocaleString('ar-EG')} داعم
                    </span>
                    <span className="font-bold text-[#0B5145]">{progressPercent}%</span>
                  </div>
                  <div className="h-2 w-full bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#0B5145] rounded-full transition-all"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-stone-100">
                <span className="text-xs text-stone-400 font-mono">
                  {camp.sharesCount.toLocaleString('ar-EG')} مشاركة عبر المنصات
                </span>

                <button
                  onClick={() => onOpenCaseDetail(camp.caseId)}
                  className="px-3.5 py-1.5 rounded-xl bg-stone-100 hover:bg-[#0B5145] hover:text-white text-xs font-semibold text-stone-700 transition-colors cursor-pointer"
                >
                  فتح ملف القضية ←
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
