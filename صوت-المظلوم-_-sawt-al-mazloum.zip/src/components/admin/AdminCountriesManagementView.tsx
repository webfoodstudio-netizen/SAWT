import React, { useState } from 'react';
import { CountryPriority } from '../../types';
import { Globe2, Search, CheckCircle2, AlertOctagon, Clock, ShieldAlert, ArrowLeft } from 'lucide-react';

interface AdminCountriesManagementViewProps {
  countries: CountryPriority[];
  onSelectCountryFilter: (countryName: string) => void;
}

export const AdminCountriesManagementView: React.FC<AdminCountriesManagementViewProps> = ({
  countries,
  onSelectCountryFilter,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<CountryPriority>(countries[1] || countries[0]); // Syria or Egypt

  const sortedCountries = [...countries].sort((a, b) => b.priorityScore - a.priorityScore);
  const filtered = sortedCountries.filter(c => 
    c.nameAr.includes(searchTerm) || c.nameEn.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 text-right pb-12">
      
      {/* Header */}
      <div className="pb-4 border-b border-stone-200">
        <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar">
          إدارة أرشيف الدول وأولوية المتابعة
        </h1>
        <p className="text-xs text-stone-500 mt-1">
          مؤشر "أولوية المتابعة" يحتسب ديناميكياً استناداً إلى كثافة القضايا الموثقة، وجود حالات صحية حرجة، وملفات العدالة الانتقالية.
        </p>
      </div>

      {/* Modern Notice on Syria & Independent Archives */}
      <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-xs text-emerald-950 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-[#0B5145] shrink-0 mt-0.5" />
        <div>
          <strong className="block font-bold text-sm mb-0.5 text-[#0B5145]">
            تحديث استراتيجي — سوريا (العدالة الانتقالية والسجلات المحررة):
          </strong>
          عقب تحرير البلاد وسقوط النظام السوري الاستبدادي البائد، تتعامل المنصة حصراً مع السجلات المادية المضبوطة، إفادات أسر الضحايا، ومسح المقابر الجماعية بالتعاون مع المنظمات المدنية والطب الشرعي المستقل، مع استبعاد تام لكافة السجلات المزيفة التي لفقها النظام البائد.
        </div>
      </div>

      {/* Search Input */}
      <div className="max-w-md bg-white p-2 rounded-2xl border border-stone-200 shadow-sm">
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ابحث عن دولة..."
            className="w-full pr-9 pl-3 py-2 text-xs rounded-xl bg-stone-50 border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#0B5145]"
          />
          <Search className="absolute right-3 top-2.5 w-4 h-4 text-stone-400" />
        </div>
      </div>

      {/* Main Grid: Interactive Map + Country Dossier Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Table of Countries */}
        <div className="lg:col-span-8 bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold font-mono">
                <th className="py-3 px-3">الدولة</th>
                <th className="py-3 px-3 text-center">إجمالي القضايا</th>
                <th className="py-3 px-3 text-center">موثقة</th>
                <th className="py-3 px-3 text-center">عاجلة</th>
                <th className="py-3 px-3 text-center">قيد التحقق</th>
                <th className="py-3 px-3 text-center">أولوية المتابعة</th>
                <th className="py-3 px-3 text-left">الإجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filtered.map((c) => {
                const isSelected = selectedCountry.code === c.code;
                return (
                  <tr
                    key={c.code}
                    onClick={() => setSelectedCountry(c)}
                    className={`hover:bg-stone-50/80 cursor-pointer transition-colors ${
                      isSelected ? 'bg-[#0B5145]/10 font-bold' : ''
                    }`}
                  >
                    <td className="py-3.5 px-3 font-bold text-stone-900">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#0B5145]" />
                        <span className="font-serif-ar text-sm">{c.nameAr}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-3 text-center font-mono font-bold text-stone-800 text-sm">
                      {c.totalCases}
                    </td>

                    <td className="py-3.5 px-3 text-center">
                      <span className="text-emerald-700 font-bold font-mono">{c.verifiedCases}</span>
                    </td>

                    <td className="py-3.5 px-3 text-center">
                      <span className="text-rose-700 font-bold font-mono bg-rose-50 px-2 py-0.5 rounded">
                        {c.urgentCases}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-center font-mono text-amber-700">
                      {c.investigatingCases}
                    </td>

                    <td className="py-3.5 px-3 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#0B5145]/10 text-[#0B5145] font-mono">
                        {c.priorityScore}/100
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-left">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectCountryFilter(c.nameAr);
                        }}
                        className="text-xs text-[#0B5145] font-bold hover:underline"
                      >
                        عرض القضايا ←
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Selected Country Focus Card */}
        <div className="lg:col-span-4 bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm space-y-4">
          <div className="pb-3 border-b border-stone-100 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-stone-400 font-mono block">الملف الجغرافي النشط</span>
              <h3 className="text-xl font-bold text-[#17201D] font-serif-ar">
                {selectedCountry.nameAr}
              </h3>
            </div>
            <span className="text-xs font-mono font-bold text-[#0B5145] bg-[#0B5145]/10 px-2.5 py-1 rounded-lg">
              درجة الأولوية: {selectedCountry.priorityScore}
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="p-3 bg-stone-50 rounded-xl flex items-center justify-between">
              <span className="text-stone-600">إجمالي القضايا المسجلة:</span>
              <strong className="text-stone-900 font-mono text-sm">{selectedCountry.totalCases}</strong>
            </div>
            <div className="p-3 bg-emerald-50 rounded-xl flex items-center justify-between text-emerald-900">
              <span>قضايا موثقة بالكامل:</span>
              <strong className="font-mono text-sm">{selectedCountry.verifiedCases}</strong>
            </div>
            <div className="p-3 bg-rose-50 rounded-xl flex items-center justify-between text-rose-900">
              <span>حالات عاجلة وحرجة:</span>
              <strong className="font-mono text-sm">{selectedCountry.urgentCases}</strong>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl flex items-center justify-between text-amber-900">
              <span>قيد التحقق وفحص الأدلة:</span>
              <strong className="font-mono text-sm">{selectedCountry.investigatingCases}</strong>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#FBF9F5] border border-stone-200 text-xs text-stone-600 leading-relaxed">
            <strong className="block text-stone-800 mb-1">الملاحظة التوثيقية الميدانية:</strong>
            {selectedCountry.statusNote || 'متابعة دورية مستمرة بالتنسيق مع هيئات الدفاع المستقلة.'}
          </div>

          <button
            onClick={() => onSelectCountryFilter(selectedCountry.nameAr)}
            className="w-full py-2.5 px-4 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            تصفية جدول القضايا لـ {selectedCountry.nameAr}
          </button>
        </div>

      </div>

    </div>
  );
};
