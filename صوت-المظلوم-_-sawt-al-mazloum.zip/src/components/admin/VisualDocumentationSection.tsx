import React, { useState, useMemo } from 'react';
import { CaseItem, VerificationStage } from '../../types';
import { 
  ShieldCheck, 
  Clock, 
  FileCheck2, 
  Layers, 
  Search, 
  UserCheck, 
  Send, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowLeft, 
  ArrowRight, 
  ChevronRight, 
  ChevronLeft,
  FileText, 
  Filter, 
  User, 
  MapPin, 
  Activity, 
  Check, 
  BarChart2, 
  Eye, 
  Lock, 
  RefreshCw,
  FolderOpen,
  ArrowUpRight,
  ShieldAlert,
  AlertCircle
} from 'lucide-react';

export interface StageDefinition {
  id: number;
  key: VerificationStage | 'received' | 'initial_review' | 'evidence_collection' | 'cross_referencing' | 'verification' | 'human_review' | 'published';
  name: string;
  subtitle: string;
  shortDesc: string;
  defaultAvgDays: number;
  protocolChecklist: string[];
  color: string;
  badgeBg: string;
  badgeText: string;
  accentBorder: string;
  gradient: string;
}

interface VisualDocumentationSectionProps {
  cases: CaseItem[];
  onOpenCaseDetail: (caseId: string) => void;
  onNavigateSection?: (section: any) => void;
  onUpdateCase?: (updatedCase: CaseItem) => void;
  isStandalonePage?: boolean;
}

// Canonical sequence of the 7 stages requested
const STAGE_DEFINITIONS: StageDefinition[] = [
  {
    id: 1,
    key: 'received',
    name: 'استلام',
    subtitle: 'الاستقبال والتشفير اللحظي',
    shortDesc: 'استقبال البلاغات عبر القنوات الآمنة، تشفير الهويات، وإصدار المعرف الرقمي السري.',
    defaultAvgDays: 1,
    protocolChecklist: [
      'تشفير بيانات المبلّغ والمحتجز بتقنية سرية تامة',
      'توليد المعرف الرقمي الموحد وتثبيت وقت الاستلام',
      'فحص السجلات لتفادي ازدواجية البلاغات السابقة'
    ],
    color: 'emerald',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-800',
    accentBorder: 'border-emerald-500',
    gradient: 'from-emerald-500 to-teal-600',
  },
  {
    id: 2,
    key: 'initial_review',
    name: 'مراجعة أولية',
    subtitle: 'فحص الاختصاص والولاية الحقوقية',
    shortDesc: 'التأكد من وقوع الانتهاك ضمن النطاق العربي وتوافقه مع معايير المنصة وخلوه من دعوات العنف.',
    defaultAvgDays: 2,
    protocolChecklist: [
      'التحقق من الاختصاص الجغرافي والقانوني بالمنطقة العربية',
      'استبعاد خطابات الكراهية أو الدعوات الانتقامية العنيفة',
      'تعيين باحث رصاصي للملف والبدء بالتواصل الأولي'
    ],
    color: 'teal',
    badgeBg: 'bg-teal-50',
    badgeText: 'text-teal-800',
    accentBorder: 'border-teal-500',
    gradient: 'from-teal-500 to-cyan-600',
  },
  {
    id: 3,
    key: 'evidence_collection',
    name: 'أدلة',
    subtitle: 'استيفاء الوثائق والأسانيد الثبوتية',
    shortDesc: 'جمع المستندات القانونية الرسمية، محاضر النيابة، أوامر الحبس، والتقارير الطبية وشهادات الشهود.',
    defaultAvgDays: 4,
    protocolChecklist: [
      'تأكيد وجود أصل رسمي أو نسخة مصدقة من أمر التوقيف أو الاحتجاز',
      'أرشفة التقارير الطبية وشهادات الأسرة في خزانة الأدلة المشفرة',
      'تصنيف مستوى سرية كل وثيقة (عام / داخلي / حساس)'
    ],
    color: 'amber',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-800',
    accentBorder: 'border-amber-500',
    gradient: 'from-amber-500 to-yellow-600',
  },
  {
    id: 4,
    key: 'cross_referencing',
    name: 'مقارنة',
    subtitle: 'مقاطعة المصادر وتفكيك التناقضات',
    shortDesc: 'مطابقة التواريخ الجنائية وروايات الشهود المستقلين وكشف أي ثغرات أو تعارضات بين المصادر.',
    defaultAvgDays: 3,
    protocolChecklist: [
      'مقاطعة رواية الأسرة مع مصدرين مستقلين على الأقل',
      'التحقق من البيانات الجغرافية وسجلات الحضور والمحاضر',
      'رصد أي تناقضات تاريخية وحسمها في مذكرة الفحص'
    ],
    color: 'orange',
    badgeBg: 'bg-orange-50',
    badgeText: 'text-orange-800',
    accentBorder: 'border-orange-500',
    gradient: 'from-orange-500 to-amber-600',
  },
  {
    id: 5,
    key: 'verification',
    name: 'تحقق',
    subtitle: 'التثبت الجنائي والرقمي المتقدم',
    shortDesc: 'الفحص المجهري للأختام والتواقيع، مطابقة البصمة الرقمية للوسائط وأرقام القضايا الرسمية.',
    defaultAvgDays: 2,
    protocolChecklist: [
      'الفحص الجنائي الرقمي للصور والوثائق وبياناتها الوصفية (Metadata)',
      'مطابقة رقم القضية في الجداول واللوائح القضائية المعتمدة',
      'توثيق البصمة المشفرة (SHA-256) للأدلة الثبوتية'
    ],
    color: 'blue',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-800',
    accentBorder: 'border-blue-500',
    gradient: 'from-blue-600 to-indigo-600',
  },
  {
    id: 6,
    key: 'human_review',
    name: 'مراجعة بشرية',
    subtitle: 'إجازة الهيئة الاستشارية والقانونية',
    shortDesc: 'مراجعة تحريرية وأخلاقية صارمة لتقييم سلامة المعتقل وأسرته وتوقيع المستشار القانوني.',
    defaultAvgDays: 1,
    protocolChecklist: [
      'تقييم أمني شامل لضمان عدم تعريض المعتقل أو أسرته للخطر',
      'إجازة الصياغة التحريرية والتزام الحياد والنزاهة الحقوقية',
      'توقيع المشرف القانوني ورئيس التحرير على إذن النشر'
    ],
    color: 'purple',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-purple-800',
    accentBorder: 'border-purple-500',
    gradient: 'from-purple-600 to-violet-700',
  },
  {
    id: 7,
    key: 'published',
    name: 'نشر',
    subtitle: 'إطلاق الملف وتفعيل الرصد الميداني',
    shortDesc: 'إتاحة الملف العام الموثق، توليد رمز QR، توزيع البيان الصحفي وربط الحالة بشبكة العون.',
    defaultAvgDays: 0,
    protocolChecklist: [
      'توليد الملف الحقوقي العام الموثق بصيغة الويب والطباعة',
      'تضمين باركود QR المشفر للتحقق الفوري من مصداقية الملف',
      'إدراج القضية في الأرشيف المفتوح وإخطار شبكة المحامين والشركاء'
    ],
    color: 'emerald',
    badgeBg: 'bg-[#DCEBE4]',
    badgeText: 'text-[#0B5145]',
    accentBorder: 'border-[#0B5145]',
    gradient: 'from-[#0B5145] to-[#083B32]',
  },
];

// Helper to check which stage a case belongs to in the 7-stage pipeline
export function getCaseStageId(caseItem: CaseItem): number {
  const stage = caseItem.verificationStage;
  if (stage === 'received') return 1;
  if (stage === 'initial_review') return 2;
  if (stage === 'evidence_collection') return 3;
  if (stage === 'cross_referencing') return 4;
  if (stage === 'verification') return 5;
  if (stage === 'human_review') return 6;
  if (stage === 'published') return 7;

  // Fallbacks if verificationStage is missing or differs:
  if (caseItem.status === 'verified') return 7;
  if (caseItem.status === 'needs_evidence') return 3;
  if (caseItem.contradictions && caseItem.contradictions.length > 0) return 4;
  
  const prog = caseItem.verificationProgress ?? 50;
  if (prog <= 20) return 1;
  if (prog <= 35) return 2;
  if (prog <= 50) return 3;
  if (prog <= 65) return 4;
  if (prog <= 80) return 5;
  if (prog < 100) return 6;
  return 7;
}

export const VisualDocumentationSection: React.FC<VisualDocumentationSectionProps> = ({
  cases,
  onOpenCaseDetail,
  onNavigateSection,
  onUpdateCase,
  isStandalonePage = false,
}) => {
  // Current active selected stage (1 through 7)
  const [activeStageId, setActiveStageId] = useState<number>(4);
  const [lastRefreshed, setLastRefreshed] = useState<string>('لحظي — متزامن مع قاعدة البيانات');
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Protocol checkboxes state per stage
  const [checkedProtocols, setCheckedProtocols] = useState<Record<string, boolean>>({
    '1-0': true, '1-1': true, '1-2': true,
    '2-0': true, '2-1': true, '2-2': false,
    '3-0': true, '3-1': true, '3-2': true,
    '4-0': true, '4-1': true, '4-2': false,
    '5-0': true, '5-1': true, '5-2': true,
    '6-0': true, '6-1': false, '6-2': true,
    '7-0': true, '7-1': true, '7-2': true,
  });

  // 1. DYNAMICALLY MAP & GROUP THE PASSED CASES TO THE 7 STAGES
  const stagesWithDynamicData = useMemo(() => {
    const totalCasesCount = cases.length;

    return STAGE_DEFINITIONS.map((def) => {
      // Find all cases currently mapped to this stage
      const stageCases = cases.filter(c => getCaseStageId(c) === def.id);
      const stageCount = stageCases.length;

      // Calculate total documents processed in this stage
      const docsCount = stageCases.reduce((sum, c) => {
        const fromStats = c.stats?.documentsCount || 0;
        const fromEvidence = c.evidence?.length || 0;
        return sum + Math.max(fromStats, fromEvidence);
      }, 0);

      // Calculate urgent cases in this stage
      const urgentCount = stageCases.filter(c => c.status === 'urgent').length;

      // Calculate high risk cases in this stage
      const highRiskCount = stageCases.filter(c => c.riskAssessment === 'حرج' || c.riskAssessment === 'عالي').length;

      // Extract unique lead researchers actively assigned to these cases
      const activeInspectors = Array.from(
        new Set(stageCases.map(c => c.leadResearcher).filter(Boolean))
      ) as string[];

      // Default inspector fallback if none assigned
      if (activeInspectors.length === 0) {
        if (def.id === 1) activeInspectors.push('فريق التشفير والاستقبال');
        else if (def.id === 2) activeInspectors.push('أحمد بوزيد — باحث قانوني');
        else if (def.id === 3) activeInspectors.push('سارة الشامي — باحث أول');
        else if (def.id === 4) activeInspectors.push('عمر التميمي — محقق أدلة');
        else if (def.id === 5) activeInspectors.push('د. كريم المنصوري — خبير رقمي');
        else if (def.id === 6) activeInspectors.push('أ. منصف الزواوي — مستشار قانوني');
        else activeInspectors.push('فريق النشر والأرشيف الحقوقي');
      }

      // Dynamic accuracy rate: deduct if stage has active contradictions
      const contradictionCasesCount = stageCases.filter(c => (c.contradictions?.length ?? 0) > 0).length;
      let accuracyRate = 100;
      if (def.id === 7) {
        accuracyRate = 100;
      } else if (contradictionCasesCount > 0) {
        accuracyRate = Math.max(92, Math.round(100 - (contradictionCasesCount * 2.5)));
      } else {
        accuracyRate = 99.4;
      }

      // Dynamic percentage of total cases in this stage
      const percentageOfTotal = totalCasesCount > 0 
        ? Math.round((stageCount / totalCasesCount) * 100) 
        : 0;

      // Estimated average processing time
      let avgTime = `${def.defaultAvgDays} أيام`;
      if (def.id === 1) avgTime = '4.5 ساعات';
      else if (def.id === 2) avgTime = '18 ساعة';
      else if (def.id === 6) avgTime = '14 ساعة';
      else if (def.id === 7) avgTime = 'فوري عند الاعتماد';

      return {
        ...def,
        cases: stageCases,
        count: stageCount,
        docsCount,
        urgentCount,
        highRiskCount,
        activeInspectors,
        accuracyRate: `${accuracyRate}%`,
        percentageOfTotal,
        avgTime,
      };
    });
  }, [cases]);

  // Currently selected stage with dynamic metrics
  const currentStage = useMemo(() => {
    return stagesWithDynamicData.find(s => s.id === activeStageId) || stagesWithDynamicData[0];
  }, [stagesWithDynamicData, activeStageId]);

  // Overall pipeline metrics computed directly from cases array
  const totalCasesInArray = cases.length;
  const verifiedCount = cases.filter(c => c.status === 'verified' || c.verificationStage === 'published').length;
  const totalDocsCount = cases.reduce((acc, c) => acc + (c.stats?.documentsCount || c.evidence?.length || 0), 0);
  const urgentCountTotal = cases.filter(c => c.status === 'urgent').length;
  const overallCompletionRate = totalCasesInArray > 0 ? Math.round((verifiedCount / totalCasesInArray) * 100) : 0;

  // Toggle protocol item checkbox
  const handleToggleProtocol = (stageId: number, index: number) => {
    const key = `${stageId}-${index}`;
    setCheckedProtocols(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleRefreshStats = () => {
    setLastRefreshed(`الآن (${new Date().toLocaleTimeString('ar-EG')})`);
    setActionSuccessMsg(`تمت مزامنة حالة ${totalCasesInArray} قضية مع شريط التقدم التفاعلي.`);
    setTimeout(() => setActionSuccessMsg(null), 3500);
  };

  const handleAdvanceStage = () => {
    if (activeStageId < 7) {
      setActiveStageId(prev => prev + 1);
    }
  };

  const handlePreviousStage = () => {
    if (activeStageId > 1) {
      setActiveStageId(prev => prev - 1);
    }
  };

  // INTERACTIVE CASE PROGRESSION: Advance a specific case to the next stage in the pipeline
  const handlePromoteCaseToNextStage = (caseItem: CaseItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!onUpdateCase) return;

    const currentStageNum = getCaseStageId(caseItem);
    if (currentStageNum >= 7) {
      setActionSuccessMsg(`القضية [${caseItem.id}] وصلت بالفعل للمرحلة النهائية (منشورة ومعتمدة).`);
      setTimeout(() => setActionSuccessMsg(null), 3000);
      return;
    }

    const nextStageNum = currentStageNum + 1;
    const nextDef = STAGE_DEFINITIONS[nextStageNum - 1];

    const updatedCase: CaseItem = {
      ...caseItem,
      verificationStage: nextDef.key as VerificationStage,
      status: nextStageNum === 7 ? 'verified' : caseItem.status,
      verificationProgress: Math.min(100, (nextStageNum / 7) * 100),
      lastUpdated: 'الآن (محدّث تلقائياً)',
    };

    onUpdateCase(updatedCase);
    setActionSuccessMsg(`تمت ترقية القضية [${caseItem.id}: ${caseItem.name}] بنجاح إلى مرحلة «${nextDef.name}».`);
    setTimeout(() => setActionSuccessMsg(null), 3500);
  };

  return (
    <section className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden text-right transition-all mb-8">
      
      {/* 1. Header Bar with Dynamic Indicator & Synchronized Status */}
      <div className="p-6 sm:p-7 border-b border-stone-100 bg-gradient-to-r from-stone-50 via-white to-stone-50/50">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#DCEBE4] text-[#0B5145] text-xs font-bold font-mono">
                <span className="w-2 h-2 rounded-full bg-[#0B5145] animate-ping" />
                <span className="w-2 h-2 rounded-full bg-[#0B5145] -mr-3.5" />
                <span>قسم «التوثيق البصري»</span>
              </span>

              <span className="px-2.5 py-0.5 rounded-md bg-stone-100 text-stone-700 text-xs font-mono font-medium">
                مربوط مباشرة بمصفوفة القضايا ({totalCasesInArray} قضية)
              </span>

              <span className="text-[11px] text-stone-400 font-mono">
                مزامنة: {lastRefreshed}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar pt-1 flex items-center gap-2">
              <Eye className="w-6 h-6 text-[#0B5145]" />
              <span>مسار التوثيق البصري ومراحل التحقق السبعة</span>
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-3xl">
              شريط تقدم تفاعلي حي يعكس حركة الملفات اللحظية من وصول البلاغ حتى التثبت والنشر، مدعوماً ببروتوكولات التحقق وإحصاءات دقيقة لكل مرحلة من المراحل السبعة.
            </p>
          </div>

          {/* Quick Operations Controls */}
          <div className="flex items-center gap-2 self-start lg:self-center shrink-0">
            <button
              onClick={handleRefreshStats}
              title="تحديث ومزامنة الإحصاءات لحظياً"
              className="p-2 rounded-xl border border-stone-200 text-stone-600 hover:text-[#0B5145] hover:border-[#0B5145] hover:bg-stone-50 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              onClick={handlePreviousStage}
              disabled={activeStageId === 1}
              className="px-3 py-1.5 rounded-xl border border-stone-200 text-stone-700 hover:bg-stone-50 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
              <span>المرحلة السابقة</span>
            </button>

            <button
              onClick={handleAdvanceStage}
              disabled={activeStageId === 7}
              className="px-3 py-1.5 bg-[#0B5145] hover:bg-[#083B32] text-white disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold rounded-xl flex items-center gap-1 cursor-pointer transition-colors shadow-sm"
            >
              <span>المرحلة التالية</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

        </div>

        {/* Dynamic Global Summary Strip tied to Cases Array */}
        <div className="mt-5 pt-4 border-t border-stone-100 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-white/80 border border-stone-200/70 p-3 rounded-xl">
            <span className="text-[11px] text-stone-500 block font-sans">إجمالي القضايا النشطة</span>
            <span className="text-lg font-bold font-serif-ar text-[#17201D] tabular-nums">
              {totalCasesInArray} قضية
            </span>
          </div>

          <div className="bg-white/80 border border-stone-200/70 p-3 rounded-xl">
            <span className="text-[11px] text-stone-500 block font-sans">الوثائق والأدلة المسجلة</span>
            <span className="text-lg font-bold font-serif-ar text-[#0B5145] tabular-nums">
              {totalDocsCount} وثيقة رسمية
            </span>
          </div>

          <div className="bg-white/80 border border-stone-200/70 p-3 rounded-xl">
            <span className="text-[11px] text-stone-500 block font-sans">القضايا العاجلة والحرجة</span>
            <span className="text-lg font-bold font-serif-ar text-rose-700 tabular-nums">
              {urgentCountTotal} حالات عاجلة
            </span>
          </div>

          <div className="bg-white/80 border border-stone-200/70 p-3 rounded-xl">
            <span className="text-[11px] text-stone-500 block font-sans">نسبة الإنجاز والنشر</span>
            <span className="text-lg font-bold font-serif-ar text-[#0B5145] tabular-nums">
              {overallCompletionRate}% معتمدة
            </span>
          </div>
        </div>
      </div>

      {/* Action Notification Message if triggered */}
      {actionSuccessMsg && (
        <div className="mx-6 mt-4 p-3 bg-emerald-50 border border-emerald-200 text-[#0B5145] text-xs font-semibold rounded-xl flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-[#0B5145] shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* 2. THE INTERACTIVE PROGRESS BAR (شريط تقدم تفاعلي) */}
      <div className="p-6 sm:p-8 bg-[#FBF9F5]/70 border-b border-stone-200/70">
        
        {/* Section Lead */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#0B5145]" />
            <span className="text-xs font-bold text-stone-700 uppercase tracking-wider">
              المسار التفاعلي المباشر — انقر على أي مرحلة من المراحل السبعة لمعاينة القضايا والإحصائيات:
            </span>
          </div>
          <span className="text-xs font-mono font-bold text-[#0B5145]">
            المرحلة المحددة: 0{activeStageId} من 07 ({currentStage.name})
          </span>
        </div>

        {/* Global Continuous Progress Rail */}
        <div className="relative mb-8 pt-2">
          {/* Background Rail Track */}
          <div className="h-3 w-full bg-stone-200/80 rounded-full overflow-hidden relative">
            {/* Active Colored Fill Segment up to selected stage */}
            <div 
              className="h-full bg-gradient-to-r from-emerald-500 via-teal-500 to-[#0B5145] transition-all duration-500 ease-out rounded-full"
              style={{ width: `${(activeStageId / 7) * 100}%` }}
            />
          </div>

          {/* Glowing Milestone Marker at current percentage */}
          <div 
            className="absolute top-1/2 -translate-y-1/2 transition-all duration-500 pointer-events-none"
            style={{ right: `calc(${((activeStageId - 1) / 6) * 100}% - 12px)` }}
          >
            <div className="w-6 h-6 rounded-full bg-[#0B5145] border-2 border-white shadow-md flex items-center justify-center animate-pulse">
              <span className="w-2 h-2 rounded-full bg-white" />
            </div>
          </div>
        </div>

        {/* The 7 Interactive Stage Nodes / Cards tied directly to cases */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 sm:gap-3">
          {stagesWithDynamicData.map((stage) => {
            const isSelected = stage.id === activeStageId;
            const isCompleted = stage.id < activeStageId;

            return (
              <button
                key={stage.id}
                onClick={() => setActiveStageId(stage.id)}
                className={`relative p-3.5 sm:p-4 rounded-2xl border text-right transition-all cursor-pointer group flex flex-col justify-between ${
                  isSelected 
                    ? 'bg-[#0B5145] text-white border-[#0B5145] shadow-lg ring-2 ring-[#0B5145]/30 -translate-y-1'
                    : isCompleted
                    ? 'bg-white border-emerald-200 text-stone-800 hover:border-emerald-400 hover:shadow-sm'
                    : 'bg-white/90 border-stone-200 text-stone-700 hover:border-stone-300 hover:bg-white'
                }`}
              >
                {/* Stage Header & Number */}
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                    isSelected 
                      ? 'bg-emerald-950/40 text-emerald-200' 
                      : isCompleted
                      ? 'bg-emerald-100 text-[#0B5145]'
                      : 'bg-stone-100 text-stone-500'
                  }`}>
                    0{stage.id}
                  </span>

                  {isCompleted && !isSelected && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  )}
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
                  )}
                </div>

                {/* Stage Name */}
                <div className="mb-2">
                  <div className={`text-sm font-bold font-serif-ar leading-tight ${isSelected ? 'text-white' : 'text-stone-900'}`}>
                    {stage.name}
                  </div>
                  <div className={`text-[10px] leading-tight line-clamp-1 mt-0.5 ${isSelected ? 'text-emerald-100' : 'text-stone-500'}`}>
                    {stage.subtitle}
                  </div>
                </div>

                {/* Live Count & Metric from cases array */}
                <div className="pt-2 border-t border-stone-100/30 flex items-baseline justify-between mt-auto">
                  <div className={`text-xl font-bold font-serif-ar tabular-nums ${isSelected ? 'text-white' : 'text-[#0B5145]'}`}>
                    {stage.count}
                  </div>
                  <span className={`text-[10px] font-mono ${isSelected ? 'text-emerald-200' : 'text-stone-400'}`}>
                    {stage.count === 1 ? 'قضية واحدة' : stage.count === 2 ? 'قضيتان' : 'قضايا'}
                  </span>
                </div>

                {/* Step Connector Arrow on Desktop (except last) */}
                {stage.id < 7 && (
                  <div className="hidden lg:block absolute -left-2 top-1/2 -translate-y-1/2 z-10 text-stone-300 pointer-events-none group-hover:text-stone-500">
                    ←
                  </div>
                )}
              </button>
            );
          })}
        </div>

      </div>

      {/* 3. ACTIVE STAGE DEEP-DIVE INSPECTION CANVAS */}
      <div className="p-6 sm:p-8">
        
        {/* Stage Title and Summary */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 mb-6 border-b border-stone-200">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-lg text-xs font-bold font-mono bg-[#DCEBE4] text-[#0B5145]">
                المرحلة 0{currentStage.id} من 07
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar">
                مرحلة «{currentStage.name}»: {currentStage.subtitle}
              </h3>
            </div>
            <p className="text-xs sm:text-sm text-stone-600 max-w-2xl leading-relaxed">
              {currentStage.shortDesc}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
            {onNavigateSection && (
              <button
                onClick={() => onNavigateSection('cases')}
                className="px-3.5 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Filter className="w-3.5 h-3.5" />
                <span>أرشيف قضايا {currentStage.name} ({currentStage.count})</span>
              </button>
            )}

            <button
              onClick={handleAdvanceStage}
              disabled={activeStageId === 7}
              className="px-4 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm disabled:opacity-50"
            >
              <span>المرحلة اللاحقة</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 4 Cards: Real-Time Statistics dynamically linked to cases array */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 mb-8">
          
          <div className="p-4 rounded-2xl bg-[#FBF9F5] border border-stone-200/90 text-right">
            <div className="flex items-center justify-between text-stone-400 mb-1.5">
              <span className="text-xs font-bold text-stone-700">القضايا في هذه المرحلة</span>
              <BarChart2 className="w-4 h-4 text-[#0B5145]" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold font-serif-ar text-[#17201D] tabular-nums">
              {currentStage.count}
            </div>
            <span className="text-[10px] text-stone-500 mt-1 block">
              تمثل {currentStage.percentageOfTotal}% من إجمالي القضايا النشطة
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#FBF9F5] border border-stone-200/90 text-right">
            <div className="flex items-center justify-between text-stone-400 mb-1.5">
              <span className="text-xs font-bold text-stone-700">متوسط وقت المعالجة</span>
              <Clock className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold font-serif-ar text-[#17201D] tabular-nums">
              {currentStage.avgTime}
            </div>
            <span className="text-[10px] text-stone-500 mt-1 block">
              حسب متوسط حركة الملفات السابقة
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#FBF9F5] border border-stone-200/90 text-right">
            <div className="flex items-center justify-between text-stone-400 mb-1.5">
              <span className="text-xs font-bold text-stone-700">مؤشر الدقة والمطابقة</span>
              <ShieldCheck className="w-4 h-4 text-[#0B5145]" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold font-serif-ar text-[#0B5145] tabular-nums">
              {currentStage.accuracyRate}
            </div>
            <span className="text-[10px] text-[#0B5145] font-semibold mt-1 block">
              مطابقة للمعايير الثبوتية الصارمة
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#FBF9F5] border border-stone-200/90 text-right">
            <div className="flex items-center justify-between text-stone-400 mb-1.5">
              <span className="text-xs font-bold text-stone-700">الوثائق المرتبطة بالمرحلة</span>
              <FileCheck2 className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold font-serif-ar text-[#17201D] tabular-nums">
              {currentStage.docsCount}
            </div>
            <span className="text-[10px] text-stone-500 mt-1 block">
              أصل رسمي أو شهادة مصدقة
            </span>
          </div>

        </div>

        {/* 2 Columns: Protocols & Active Investigators vs. Live Cases in this Stage */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Right Column (6 cols): Stage Verification Protocol & Assigned Team */}
          <div className="lg:col-span-6 space-y-5">
            
            {/* Protocol Checklist */}
            <div className="p-5 rounded-2xl bg-stone-50/70 border border-stone-200 text-right">
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-stone-200/70">
                <span className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#0B5145]" />
                  <span>بروتوكول التحقق الإلزامي لمرحلة «{currentStage.name}»</span>
                </span>
                <span className="text-[10px] font-mono text-stone-400">3 متطلبات أساسية</span>
              </div>

              <div className="space-y-2.5">
                {currentStage.protocolChecklist.map((item, idx) => {
                  const checkKey = `${currentStage.id}-${idx}`;
                  const isChecked = !!checkedProtocols[checkKey];

                  return (
                    <div 
                      key={idx}
                      onClick={() => handleToggleProtocol(currentStage.id, idx)}
                      className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 cursor-pointer transition-colors ${
                        isChecked 
                          ? 'bg-white border-emerald-200 text-stone-800' 
                          : 'bg-white/60 border-stone-200 text-stone-500'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center shrink-0 transition-colors ${
                        isChecked ? 'bg-[#0B5145] text-white' : 'border border-stone-300 bg-white'
                      }`}>
                        {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                      <span className={`leading-relaxed ${isChecked ? 'font-medium text-stone-900' : 'text-stone-600'}`}>
                        {item}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Active Investigators dynamically bound */}
            <div className="p-4 rounded-2xl bg-white border border-stone-200 text-right">
              <span className="text-xs font-bold text-stone-700 block mb-2">
                الباحثون والمحققون المكلّفون بمتابعة قضايا هذه المرحلة:
              </span>
              <div className="flex flex-wrap items-center gap-2">
                {currentStage.activeInspectors.map((person, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 border border-stone-200 text-xs font-medium text-stone-800">
                    <User className="w-3.5 h-3.5 text-[#0B5145]" />
                    <span>{person}</span>
                  </div>
                ))}
                <span className="text-[11px] text-stone-400 font-mono">
                  + الإشراف القانوني المركزي
                </span>
              </div>
            </div>

          </div>

          {/* Left Column (6 cols): Live Cases from the actual cases array */}
          <div className="lg:col-span-6 space-y-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                <FolderOpen className="w-4 h-4 text-[#0B5145]" />
                <span>القضايا الفعلية الموجودة في مرحلة «{currentStage.name}»:</span>
              </span>
              <span className="text-xs font-mono text-stone-500">
                {currentStage.cases.length} قضايا من المصفوفة
              </span>
            </div>

            {currentStage.cases.length > 0 ? (
              currentStage.cases.map((caseItem) => (
                <div
                  key={caseItem.id}
                  onClick={() => onOpenCaseDetail(caseItem.id)}
                  className="p-4 rounded-2xl bg-[#FBF9F5] border border-stone-200/90 hover:border-[#0B5145] hover:bg-white hover:shadow-sm transition-all cursor-pointer group text-right flex items-center justify-between gap-4"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-[#0B5145] group-hover:underline">
                        {caseItem.id}
                      </span>
                      <span className="text-stone-300">·</span>
                      <span className="text-[11px] text-stone-500 font-medium">
                        {caseItem.country} ({caseItem.city})
                      </span>
                      {caseItem.status === 'urgent' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">
                          عاجلة
                        </span>
                      )}
                    </div>

                    <h4 className="text-sm font-bold text-stone-900 font-serif-ar truncate">
                      {caseItem.name}
                    </h4>

                    <p className="text-xs text-stone-500 line-clamp-1">
                      {caseItem.summary}
                    </p>

                    <div className="flex items-center gap-2 text-[10px] text-stone-400 font-mono pt-1">
                      <span>الوثائق: {caseItem.stats?.documentsCount || caseItem.evidence?.length || 0}</span>
                      <span>·</span>
                      <span>الباحث: {caseItem.leadResearcher || 'سارة الشامي'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {/* Advance case button if onUpdateCase provided */}
                    {onUpdateCase && currentStage.id < 7 && (
                      <button
                        onClick={(e) => handlePromoteCaseToNextStage(caseItem, e)}
                        title={`ترقية القضية إلى مرحلة «${STAGE_DEFINITIONS[currentStage.id].name}»`}
                        className="px-2.5 py-1.5 rounded-xl bg-[#DCEBE4] text-[#0B5145] hover:bg-[#0B5145] hover:text-white transition-colors text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <span>ترقية</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenCaseDetail(caseItem.id);
                      }}
                      className="p-2 rounded-xl bg-white border border-stone-200 text-stone-700 group-hover:bg-[#0B5145] group-hover:text-white group-hover:border-[#0B5145] transition-colors"
                      title="فتح ملف القضية الكامل"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 rounded-2xl bg-stone-50 border border-stone-200 text-center text-xs text-stone-500 space-y-2">
                <AlertCircle className="w-6 h-6 text-stone-400 mx-auto" />
                <p className="font-semibold text-stone-700">لا توجد قضايا حالياً في مرحلة «{currentStage.name}» داخل المصفوفة الممررة.</p>
                <p className="text-stone-400 text-[11px]">يمكنك ترقية أي قضية من المراحل السابقة لتصل إلى هذه المرحلة فورياً.</p>
              </div>
            )}

            {/* Link to view all in archive */}
            {onNavigateSection && (
              <button
                onClick={() => onNavigateSection('cases')}
                className="w-full py-2.5 rounded-xl border border-dashed border-stone-300 hover:border-[#0B5145] text-xs font-semibold text-[#0B5145] hover:bg-emerald-50/50 transition-colors cursor-pointer text-center block mt-2"
              >
                استعراض كافة القضايا في الأرشيف المركزي ({totalCasesInArray}) ←
              </button>
            )}

          </div>

        </div>

      </div>

    </section>
  );
};
