import React, { useState } from 'react';
import { TeamMember } from '../../types';
import { Users2, ShieldCheck, Plus, CheckCircle, Mail, Key, UserCheck } from 'lucide-react';
import { INITIAL_TEAM_MEMBERS } from '../../data/mockData';

export const AdminTeamView: React.FC = () => {
  const [members, setMembers] = useState<TeamMember[]>(INITIAL_TEAM_MEMBERS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'مدير المنصة' | 'باحث أول' | 'محقق أدلة' | 'محرر حقوقي' | 'مسؤول قانوني' | 'مسؤول إعلامي'>('باحث أول');
  const [newEmail, setNewEmail] = useState('');

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newEmail) return;

    const newMember: TeamMember = {
      id: `user-${Date.now()}`,
      name: newName,
      role: newRole,
      email: newEmail,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&h=120&q=80',
      permissions: ['متابعة القضايا المسندة', 'رفع الأدلة وتوثيقها', 'فحص المحاضر'],
      activeCasesCount: 0,
      lastActive: 'الآن',
      twoFactorEnabled: true,
    };

    setMembers([newMember, ...members]);
    setNewName('');
    setNewEmail('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 text-right pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <Users2 className="w-6 h-6 text-[#0B5145]" />
            <span>فريق التحقيق وإدارة الصلاحيات (RBAC)</span>
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            صلاحيات مهنية محددة وفق مبدأ الفصل بين التدقيق الميداني والاعتماد التحريري النهائي
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ إضافة عضو للفريق</span>
        </button>
      </div>

      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {members.map((member) => (
          <div
            key={member.id}
            className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
          >
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-4">
                <span className="text-xs font-semibold px-2.5 py-1 rounded bg-[#0B5145]/10 text-[#0B5145]">
                  {member.role}
                </span>
                <span className="text-[11px] font-mono text-stone-400">
                  {member.lastActive}
                </span>
              </div>

              {/* User Bio */}
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-[#0B5145] text-white flex items-center justify-center font-bold font-serif-ar text-lg shadow-sm">
                  {member.name.slice(0, 2)}
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-900 font-serif-ar">
                    {member.name}
                  </h3>
                  <span className="text-xs text-stone-500 font-mono block">
                    {member.email}
                  </span>
                </div>
              </div>

              {/* Permissions list */}
              <div className="space-y-1 mb-4">
                <span className="text-[11px] font-bold text-stone-600 block mb-1">الصلاحيات المعتمدة:</span>
                <div className="flex flex-wrap gap-1">
                  {member.permissions.map((perm, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-stone-100 text-stone-700">
                      ✓ {perm}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer Status */}
            <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs font-mono">
              <span className="text-stone-600">
                {member.activeCasesCount} قضايا تحت الإشراف
              </span>
              <span className="text-emerald-700 font-bold flex items-center gap-1">
                <Key className="w-3 h-3" />
                <span>2FA مفعل</span>
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Add Member Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full text-right shadow-2xl border border-stone-200">
            <h3 className="text-lg font-bold text-[#17201D] font-serif-ar mb-1">
              إضافة باحث أو مسؤول جديد
            </h3>
            <p className="text-xs text-stone-500 mb-5">
              سيتم إنشاء حساب مشفر وتفعيل المصادقة الثنائية (2FA) تلقائياً.
            </p>

            <form onSubmit={handleAddMember} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">الاسم الكامل</label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="مثلاً: ياسمين حداد"
                  className="w-full p-2.5 rounded-xl border border-stone-300"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">الدور الوظيفي</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                >
                  <option value="مدير المنصة">مدير المنصة (صلاحية كاملة)</option>
                  <option value="باحث أول">باحث أول (إدارة وتدقيق ملفات)</option>
                  <option value="محقق أدلة">محقق أدلة (فحص أختام وOSINT)</option>
                  <option value="محرر حقوقي">محرر حقوقي (سرد وتصحيحات)</option>
                  <option value="مسؤول قانوني">مسؤول قانوني (تنسيق نقابي ومحاكم)</option>
                  <option value="مسؤول إعلامي">مسؤول إعلامي (بيانات وPress Kits)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">البريد الإلكتروني المعتمد</label>
                <input
                  type="email"
                  required
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="name@mazloum.org"
                  className="w-full p-2.5 rounded-xl border border-stone-300"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#0B5145] text-white font-semibold rounded-xl hover:bg-[#083B32] cursor-pointer"
                >
                  حفظ وإصدار الصلاحيات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
