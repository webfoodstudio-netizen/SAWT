import React, { useState } from 'react';
import { CaseItem } from '../../types';
import { Newspaper, FileText, Download, Share2, Plus, CheckCircle2, ArrowLeft } from 'lucide-react';

interface AdminMediaManagementViewProps {
  cases: CaseItem[];
  onOpenCaseDetail: (caseId: string) => void;
}

export const AdminMediaManagementView: React.FC<AdminMediaManagementViewProps> = ({
  cases,
  onOpenCaseDetail,
}) => {
  const [selectedCaseId, setSelectedCaseId] = useState(cases[0]?.id || 'CASE-EGY-042');
  const [copiedMsg, setCopiedMsg] = useState(false);

  const selectedCase = cases.find(c => c.id === selectedCaseId) || cases[0];

  const handleCopyPressRelease = () => {
    if (!selectedCase) return;
    const text = `[بيان صحفي حقوقي موثق - منصة صوت المظلوم]
الملف المرجعي: ${selectedCase.id}
المعتقل: ${selectedCase.name} (${selectedCase.country})
الوضع الإجرائي: ${selectedCase.summary}
المصادر المدققة: ${selectedCase.stats.sourcesCount} مصادر مستقلة
الرابط الرسمي للاطلاع والتحقق: ${window.location.origin}/#/case/${selectedCase.id}`;
    
    navigator.clipboard.writeText(text);
    setCopiedMsg(true);
    setTimeout(() => setCopiedMsg(false), 2500);
  };

  return (
    <div className="space-y-6 text-right pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <Newspaper className="w-6 h-6 text-[#0B5145]" />
            <span>إدارة المركز الإعلامي والبيانات الصحفية</span>
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            إعداد ونشر البيانات المعتمدة وتوليد حقائب الصحافة المخصصة للمراسلين ووكالات الأنباء.
          </p>
        </div>

        <button
          onClick={handleCopyPressRelease}
          className="px-4 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
        >
          <span>{copiedMsg ? '✓ تم نسخ البيان' : 'نسخ البيان الصحفي للملف المحدد'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Case selector column */}
        <div className="lg:col-span-4 bg-white rounded-3xl p-5 border border-stone-200 shadow-sm space-y-3">
          <h3 className="text-sm font-bold text-stone-800 pb-2 border-b border-stone-100">
            اختر القضية لتوليد البيان والحقيبة:
          </h3>
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {cases.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedCaseId(c.id)}
                className={`p-3 rounded-2xl border text-xs cursor-pointer transition-all ${
                  selectedCaseId === c.id
                    ? 'bg-[#0B5145] text-white border-[#0B5145] shadow-sm'
                    : 'bg-stone-50 hover:bg-stone-100 border-stone-200 text-stone-800'
                }`}
              >
                <div className="flex items-center justify-between font-mono text-[11px] mb-1">
                  <span className={selectedCaseId === c.id ? 'text-emerald-200' : 'text-[#0B5145]'}>
                    {c.id}
                  </span>
                  <span>{c.country}</span>
                </div>
                <div className="font-bold font-serif-ar truncate">
                  {c.name}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Generated Release Preview */}
        <div className="lg:col-span-8 bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <div>
              <span className="text-xs font-mono font-bold text-[#0B5145]">مسودة البيان الصحفي المعتمد للنشر</span>
              <h3 className="text-lg font-bold text-stone-900 font-serif-ar">
                {selectedCase.name} — {selectedCase.country}
              </h3>
            </div>
            <button
              onClick={() => onOpenCaseDetail(selectedCase.id)}
              className="text-xs text-[#0B5145] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>فتح الملف</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-5 rounded-2xl bg-[#FBF9F5] border border-stone-200 font-mono text-xs leading-relaxed text-stone-800 space-y-3">
            <p className="font-bold font-sans text-sm text-stone-900">
              للنشر الفوري · التاريخ: 05 أكتوبر 2026
            </p>
            <p>
              <strong>بيان صادر عن منصة صوت المظلوم:</strong> نلفت انتباه الهيئات الصحفية والحقوقية إلى التطورات الجارية في ملف المحتجز <strong>{selectedCase.name}</strong> ({selectedCase.id}) في {selectedCase.country} ({selectedCase.city}).
            </p>
            <p>
              <strong>المعطيات الموثقة:</strong> {selectedCase.summary}
            </p>
            <p>
              <strong>الأسانيد والمصادر:</strong> تمت مراجعة وتدقيق {selectedCase.stats.sourcesCount} مصادر مستقلة، وفحص {selectedCase.stats.documentsCount} وثائق رسمية من قِبل الباحث: {selectedCase.leadResearcher || 'سارة الشامي'}.
            </p>
            <div className="pt-2 border-t border-stone-200 text-[11px] text-stone-500 font-sans">
              للتواصل الإعلامي والحصول على النسخ عالية الدقة من الوثائق: media@sawt-almazloum.org
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={() => window.print()}
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl cursor-pointer"
            >
              طباعة البيان
            </button>
            <button
              onClick={handleCopyPressRelease}
              className="px-5 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl cursor-pointer shadow-sm"
            >
              {copiedMsg ? '✓ تم النسخ' : 'نسخ نص البيان الصحفي'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
