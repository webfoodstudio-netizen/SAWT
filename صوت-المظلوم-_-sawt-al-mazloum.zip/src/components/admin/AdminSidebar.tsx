import React from 'react';
import { AdminSection } from '../../types';
import { 
  LayoutDashboard, 
  FolderLock, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  AlertOctagon, 
  Globe2, 
  FileText, 
  Layers, 
  History, 
  Megaphone, 
  Inbox, 
  Users2, 
  BarChart3, 
  Newspaper, 
  ListRestart, 
  Settings, 
  ExternalLink, 
  LogOut,
  ShieldCheck,
  ChevronLeft,
  Eye
} from 'lucide-react';

interface AdminSidebarProps {
  currentSection: AdminSection;
  onSelectSection: (section: AdminSection) => void;
  onExitToPublic: () => void;
  counts: {
    newCases: number;
    investigating: number;
    verified: number;
    urgent: number;
    submissions: number;
  };
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({
  currentSection,
  onSelectSection,
  onExitToPublic,
  counts,
}) => {
  const mainNav = [
    { key: 'dashboard' as AdminSection, label: 'لوحة التحكم', icon: LayoutDashboard },
    { key: 'visual_documentation' as AdminSection, label: 'التوثيق البصري', icon: Eye, badge: 7, badgeColor: 'bg-[#DCEBE4] text-[#0B5145] font-bold' },
    { key: 'cases' as AdminSection, label: 'جميع القضايا', icon: FolderLock },
    { key: 'new_cases' as AdminSection, label: 'القضايا الجديدة', icon: Sparkles, badge: counts.newCases, badgeColor: 'bg-emerald-100 text-[#0B5145]' },
    { key: 'investigating' as AdminSection, label: 'قيد التحقق', icon: Clock, badge: counts.investigating, badgeColor: 'bg-amber-100 text-amber-800' },
    { key: 'verified' as AdminSection, label: 'القضايا الموثقة', icon: CheckCircle2, badge: counts.verified, badgeColor: 'bg-[#0B5145]/10 text-[#0B5145]' },
    { key: 'urgent' as AdminSection, label: 'القضايا العاجلة', icon: AlertOctagon, badge: counts.urgent, badgeColor: 'bg-rose-100 text-rose-700 font-bold' },
    { key: 'countries' as AdminSection, label: 'الدول وأولوية المتابعة', icon: Globe2 },
  ];

  const investigationsNav = [
    { key: 'evidence' as AdminSection, label: 'الأدلة والوثائق', icon: FileText },
    { key: 'sources' as AdminSection, label: 'المصادر والشهود', icon: Layers },
    { key: 'timeline' as AdminSection, label: 'الخط الزمني الموحد', icon: History },
    { key: 'campaigns' as AdminSection, label: 'إدارة الحملات', icon: Megaphone },
    { key: 'submissions' as AdminSection, label: 'البلاغات الجديدة', icon: Inbox, badge: counts.submissions, badgeColor: 'bg-amber-100 text-amber-800' },
  ];

  const systemNav = [
    { key: 'team' as AdminSection, label: 'المستخدمون والفريق', icon: Users2 },
    { key: 'reports' as AdminSection, label: 'التقارير والمؤشرات', icon: BarChart3 },
    { key: 'media' as AdminSection, label: 'المركز الإعلامي', icon: Newspaper },
    { key: 'logs' as AdminSection, label: 'سجل التعديلات', icon: ListRestart },
    { key: 'settings' as AdminSection, label: 'الإعدادات والأمان', icon: Settings },
  ];

  return (
    <aside className="w-72 bg-white border-l border-stone-200/80 flex flex-col justify-between h-screen sticky top-0 shrink-0 z-30 select-none overflow-y-auto">
      
      {/* Brand Header */}
      <div>
        <div className="p-5 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0B5145] text-white flex items-center justify-center font-bold font-serif-ar text-xl shadow-sm">
              ص
            </div>
            <div className="text-right">
              <h1 className="text-base font-bold text-[#17201D] font-serif-ar leading-none">
                صوت المظلوم
              </h1>
              <span className="text-[11px] text-[#0B5145] font-medium block mt-1">
                غرفة العمليات الحقوقية
              </span>
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0B5145]/10 text-[#0B5145] font-bold">
            v2.6
          </span>
        </div>

        {/* Section 1: Core Navigation */}
        <div className="px-3 py-4">
          <span className="px-3 text-[11px] font-bold text-stone-400 font-mono uppercase tracking-wider block mb-2 text-right">
            المتابعة المباشرة
          </span>
          <nav className="space-y-1">
            {mainNav.map((item) => {
              const Icon = item.icon;
              const isActive = currentSection === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => onSelectSection(item.key)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-right ${
                    isActive 
                      ? 'bg-[#0B5145] text-white shadow-sm font-bold' 
                      : 'text-stone-700 hover:bg-[#F5F3EE] hover:text-[#0B5145]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-[#0B5145]'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono ${
                      isActive ? 'bg-white/20 text-white' : item.badgeColor
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Section 2: Investigations */}
        <div className="px-3 py-2 border-t border-stone-100">
          <span className="px-3 text-[11px] font-bold text-stone-400 font-mono uppercase tracking-wider block mb-2 text-right">
            غرفة التحقيق والأدلة
          </span>
          <nav className="space-y-1">
            {investigationsNav.map((item) => {
              const Icon = item.icon;
              const isActive = currentSection === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => onSelectSection(item.key)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-right ${
                    isActive 
                      ? 'bg-[#0B5145] text-white shadow-sm font-bold' 
                      : 'text-stone-700 hover:bg-[#F5F3EE] hover:text-[#0B5145]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-[#0B5145]'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono ${
                      isActive ? 'bg-white/20 text-white' : item.badgeColor
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Section 3: System & Logs */}
        <div className="px-3 py-2 border-t border-stone-100">
          <span className="px-3 text-[11px] font-bold text-stone-400 font-mono uppercase tracking-wider block mb-2 text-right">
            الإدارة والحوكمة
          </span>
          <nav className="space-y-1">
            {systemNav.map((item) => {
              const Icon = item.icon;
              const isActive = currentSection === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => onSelectSection(item.key)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer text-right ${
                    isActive 
                      ? 'bg-[#0B5145] text-white shadow-sm font-bold' 
                      : 'text-stone-700 hover:bg-[#F5F3EE] hover:text-[#0B5145]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-stone-500'}`} />
                    <span>{item.label}</span>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* User Profile Footer */}
      <div className="p-4 border-t border-stone-200/80 bg-[#FBF9F5]">
        <div className="flex items-center justify-between mb-3 text-right">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-full bg-[#0B5145] text-white flex items-center justify-center font-bold text-sm ring-2 ring-[#0B5145]/20">
              أم
            </div>
            <div className="text-right">
              <span className="text-xs font-bold text-[#17201D] block">
                أحمد المنصوري
              </span>
              <span className="text-[11px] text-[#0B5145] font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                مدير المنصة
              </span>
            </div>
          </div>
        </div>

        {/* Action button to switch to public site */}
        <div className="flex items-center gap-2 pt-2 border-t border-stone-200">
          <button
            onClick={onExitToPublic}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-white border border-stone-300 text-stone-700 hover:bg-stone-50 hover:text-[#0B5145] text-[11px] font-semibold transition-colors cursor-pointer"
            title="الانتقال للموقع العام للجمهور"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>عرض الموقع العام</span>
          </button>

          <button
            onClick={onExitToPublic}
            className="p-2 rounded-lg bg-stone-100 text-stone-600 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
            title="تسجيل الخروج"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

    </aside>
  );
};
