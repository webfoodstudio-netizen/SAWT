import React from 'react';
import { CaseItem } from '../../types';
import { BarChart3, Download, Printer, PieChart, FileText, CheckCircle2, AlertOctagon, Globe2, Activity } from 'lucide-react';

interface AdminReportsViewProps {
  cases: CaseItem[];
}

export const AdminReportsView: React.FC<AdminReportsViewProps> = ({ cases }) => {
  const total = cases.length;
  const verified = cases.filter(c => c.status === 'verified').length;
  const urgent = cases.filter(c => c.status === 'urgent').length;
  const investigating = cases.filter(c => c.status === 'investigating').length;

  // Breakdown by country
  const countryCounts: Record<string, number> = {};
  cases.forEach(c => {
    countryCounts[c.country] = (countryCounts[c.country] || 0) + 1;
  });

  // Breakdown by case type
  const typeCounts: Record<string, number> = {};
  cases.forEach(c => {
    typeCounts[c.caseType] = (typeCounts[c.caseType] || 0) + 1;
  });

  return (
    <div className="space-y-8 text-right pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-[#0B5145]" />
            <span>التقارير والمؤشرات الحقوقية الإحصائية</span>
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            تحليلات موثقة لأنماط الانتهاكات، مؤشرات الإنجاز، وسرعة الاستجابة الميدانية.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة التقرير الفصلي</span>
          </button>
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-sm text-right">
          <span className="text-xs text-stone-500 block mb-1 font-sans">إجمالي القضايا النشطة</span>
          <span className="text-3xl font-bold font-serif-ar text-[#17201D] tabular-nums">{total}</span>
          <span className="text-[11px] text-stone-400 block mt-1">100% موثقة أو قيد التحقق</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-sm text-right">
          <span className="text-xs text-stone-500 block mb-1 font-sans">القضايا الموثقة نهائياً</span>
          <span className="text-3xl font-bold font-serif-ar text-[#0B5145] tabular-nums">{verified}</span>
          <span className="text-[11px] text-emerald-700 font-bold block mt-1">
            {total > 0 ? Math.round((verified / total) * 100) : 0}% معدل الاعتماد
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-sm text-right">
          <span className="text-xs text-stone-500 block mb-1 font-sans">حالات عاجلة تحت الرصد</span>
          <span className="text-3xl font-bold font-serif-ar text-rose-700 tabular-nums">{urgent}</span>
          <span className="text-[11px] text-rose-700 font-bold block mt-1">خطر طبي أو جلسات وشيكة</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-sm text-right">
          <span className="text-xs text-stone-500 block mb-1 font-sans">قيد مطابقة الأدلة</span>
          <span className="text-3xl font-bold font-serif-ar text-amber-700 tabular-nums">{investigating}</span>
          <span className="text-[11px] text-amber-700 font-semibold block mt-1">فحص مصادر مستقلة</span>
        </div>
      </div>

      {/* Analytics Breakdown: 2 Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Geographic Distribution */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <h3 className="text-base font-bold text-stone-900 font-serif-ar flex items-center gap-2">
              <Globe2 className="w-5 h-5 text-[#0B5145]" />
              <span>التوزيع الجغرافي للقضايا الموثقة</span>
            </h3>
            <span className="text-xs font-mono text-stone-400">{Object.keys(countryCounts).length} دول</span>
          </div>

          <div className="space-y-3">
            {Object.entries(countryCounts).map(([country, count]) => {
              const percent = Math.round((count / total) * 100);
              return (
                <div key={country} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-stone-800">{country}</span>
                    <span className="font-mono text-stone-500">{count} قضايا ({percent}%)</span>
                  </div>
                  <div className="h-2 w-full bg-stone-100 rounded-full overflow-hidden">
                    <div className="h-full bg-[#0B5145] rounded-full" style={{ width: `${percent}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Violations Classification */}
        <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <h3 className="text-base font-bold text-stone-900 font-serif-ar flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#0B5145]" />
              <span>تصنيف أنماط الانتهاكات المسجلة</span>
            </h3>
            <span className="text-xs font-mono text-stone-400">تصنيف حقوقي دولي</span>
          </div>

          <div className="space-y-3">
            {Object.entries(typeCounts).map(([typeKey, count]) => {
              const label = typeKey === 'detention' ? 'احتجاز تعسفي وحبس احتياطي' :
                            typeKey === 'disappearance' ? 'اختفاء قسري ومفقودين' :
                            typeKey === 'fair_trial' ? 'محاكمة غير عادلة وتلفيق تهم' :
                            typeKey === 'custody_death' ? 'إهمال صحي ووفيات قيد الاحتجاز' : 'انتهاكات عامة';
              const percent = Math.round((count / total) * 100);

              return (
                <div key={typeKey} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-stone-800">{label}</span>
                    <span className="font-mono text-stone-500">{count} ({percent}%)</span>
                  </div>
                  <div className="h-2 w-full bg-stone-100 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-600 rounded-full" style={{ width: `${percent}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};
