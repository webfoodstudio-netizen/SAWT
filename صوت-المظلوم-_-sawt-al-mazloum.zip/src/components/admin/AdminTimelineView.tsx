import React, { useState } from 'react';
import { CaseItem } from '../../types';
import { History, Search, Calendar, ShieldCheck, ArrowLeft, Filter, MapPin } from 'lucide-react';

interface AdminTimelineViewProps {
  cases: CaseItem[];
  onOpenCaseDetail: (caseId: string) => void;
}

export const AdminTimelineView: React.FC<AdminTimelineViewProps> = ({ cases, onOpenCaseDetail }) => {
  const [search, setSearch] = useState('');

  // Extract all timeline events with case metadata
  const allEvents = cases.flatMap(c => {
    return c.timeline.map(t => ({
      ...t,
      caseId: c.id,
      caseName: c.name,
      country: c.country,
      city: c.city,
    }));
  });

  const filteredEvents = allEvents.filter(e => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      e.title.toLowerCase().includes(q) ||
      e.description.toLowerCase().includes(q) ||
      e.caseName.toLowerCase().includes(q) ||
      e.caseId.toLowerCase().includes(q) ||
      e.date.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 text-right pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <History className="w-6 h-6 text-[#0B5145]" />
            <span>الخط الزمني الشامل والموحد للقضايا</span>
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            تسلسل زمني كرونولوجي يجمع كافة التطورات والوقائع الموثقة عبر العالم العربي.
          </p>
        </div>

        <span className="px-3 py-1 bg-[#DCEBE4] text-[#0B5145] text-xs font-bold font-mono rounded-full self-start sm:self-auto">
          {allEvents.length} حدث موثق
        </span>
      </div>

      {/* Search Input */}
      <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-sm flex items-center justify-between">
        <div className="relative w-full max-w-md">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالحدث، التاريخ، اسم المعتقل، أو رقم القضية..."
            className="w-full pr-9 pl-3 py-2 text-xs rounded-xl bg-stone-50 border border-stone-200 focus:outline-none focus:ring-2 focus:ring-[#0B5145]"
          />
          <Search className="w-4 h-4 text-stone-400 absolute right-3 top-2.5" />
        </div>
      </div>

      {/* Timeline Stream */}
      <div className="space-y-4">
        {filteredEvents.map((event, idx) => (
          <div
            key={idx}
            className="p-5 rounded-2xl bg-white border border-stone-200/90 shadow-sm hover:shadow-md transition-shadow flex flex-col sm:flex-row items-start justify-between gap-4 text-right"
          >
            <div className="space-y-2 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-[#0B5145]/10 text-[#0B5145] text-xs font-bold font-mono">
                  {event.caseId}
                </span>
                <span className="font-bold text-stone-800 text-xs font-serif-ar">
                  {event.caseName}
                </span>
                <span className="text-stone-300">·</span>
                <span className="text-stone-500 text-[11px] flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {event.country} ({event.city})
                </span>
                <span className="text-stone-300">·</span>
                <span className="text-[11px] text-stone-400 font-mono flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {event.date}
                </span>
              </div>

              <h3 className="text-base font-bold text-stone-900 font-serif-ar">
                {event.title}
              </h3>

              <p className="text-xs text-stone-600 leading-relaxed">
                {event.description}
              </p>

              {event.source && (
                <div className="pt-2 text-[11px] text-stone-400 font-mono">
                  المصدر: {event.source} · {event.verificationLevel || 'موثق'}
                </div>
              )}
            </div>

            <button
              onClick={() => onOpenCaseDetail(event.caseId)}
              className="px-3.5 py-1.5 bg-stone-100 hover:bg-[#0B5145] hover:text-white text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer shrink-0 self-end sm:self-center"
            >
              عرض القضية ←
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
