import React, { useState } from 'react';
import { CaseItem, CaseType, VerificationStatus } from '../../types';
import { X, Plus, ShieldCheck } from 'lucide-react';

interface AdminNewCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveCase: (newCase: CaseItem) => void;
}

export const AdminNewCaseModal: React.FC<AdminNewCaseModalProps> = ({
  isOpen,
  onClose,
  onSaveCase,
}) => {
  const [name, setName] = useState('');
  const [alias, setAlias] = useState('');
  const [country, setCountry] = useState('مصر');
  const [city, setCity] = useState('');
  const [caseType, setCaseType] = useState<CaseType>('detention');
  const [status, setStatus] = useState<VerificationStatus>('investigating');
  const [incidentDate, setIncidentDate] = useState('2026-10-01');
  const [summary, setSummary] = useState('');
  const [factKnown, setFactKnown] = useState('');
  const [pendingCheck, setPendingCheck] = useState('');
  const [riskAssessment, setRiskAssessment] = useState<'منخفض' | 'متوسط' | 'عالي' | 'حرج'>('متوسط');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !country) return;

    const countryCodeMap: Record<string, string> = {
      'مصر': 'EGY',
      'سوريا': 'SYR',
      'تونس': 'TUN',
      'المغرب': 'MAR',
      'اليمن': 'YEM',
      'السعودية': 'SAU',
      'الجزائر': 'DZA',
      'ليبيا': 'LBY',
      'السودان': 'SDN',
      'الأردن': 'JOR',
      'البحرين': 'BHR',
      'الإمارات': 'ARE'
    };

    const code = countryCodeMap[country] || 'ARB';
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const id = `CASE-${code}-${randomNum}`;

    const newCase: CaseItem = {
      id,
      name,
      alias,
      country,
      countryCode: code,
      city: city || 'المركز',
      status,
      caseType,
      incidentDate,
      createdDate: '2026-10-05',
      lastUpdated: 'الآن',
      image: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=600&q=80',
      summary: summary || 'قضية جديدة تم فتح ملفها وجاري جمع المستندات ومقارنة المصادر.',
      whatWeKnow: factKnown ? [factKnown] : ['تم فتح ملف التحقيق واستلام البلاغ الأولي من الأسرة.'],
      whatUnderVerification: pendingCheck ? [pendingCheck] : ['بانتظار وصول نسخة رسمية من محضر النيابة.'],
      verificationStage: 'received',
      verificationProgress: 25,
      riskAssessment,
      leadResearcher: 'أحمد المنصوري (مدير المنصة)',
      stats: {
        sourcesCount: 1,
        documentsCount: 0,
        updatesCount: 1,
        daysCount: 5,
        affectedCount: 1,
        testimoniesCount: 1,
        legalSourcesCount: 0,
      },
      timeline: [
        {
          id: `tl-init-${Date.now()}`,
          date: incidentDate,
          title: 'استلام البلاغ المبدئي وتدشين الملف',
          description: summary || 'تم إنشاء السجل في غرفة العمليات المركزية.',
          verified: true,
          addedBy: 'أحمد المنصوري',
          source: 'إفادة الأسرة',
          verificationLevel: 'قيد التحقق'
        }
      ],
      evidence: []
    };

    onSaveCase(newCase);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full text-right shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#0B5145] text-white flex items-center justify-center font-bold">
              +
            </div>
            <h2 className="text-xl font-bold text-[#17201D] font-serif-ar">
              فتح وتوثيق ملف قضية جديدة
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-stone-400 hover:text-stone-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-stone-700 mb-1">الاسم الكامل للمحتجز / الضحية</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثلاً: خالد عبد الرحمن"
                className="w-full p-2.5 rounded-xl border border-stone-300"
              />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">الاسم المستعار (إن وُجد لحماية الهوية)</label>
              <input
                type="text"
                value={alias}
                onChange={(e) => setAlias(e.target.value)}
                placeholder="أبو أحمد"
                className="w-full p-2.5 rounded-xl border border-stone-300"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-stone-700 mb-1">الدولة</label>
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-stone-300"
              >
                <option value="مصر">مصر</option>
                <option value="سوريا">سوريا</option>
                <option value="تونس">تونس</option>
                <option value="المغرب">المغرب</option>
                <option value="اليمن">اليمن</option>
                <option value="السعودية">السعودية</option>
                <option value="الجزائر">الجزائر</option>
                <option value="ليبيا">ليبيا</option>
                <option value="السودان">السودان</option>
                <option value="الأردن">الأردن</option>
                <option value="البحرين">البحرين</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">المدينة / المنطقة</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="مثلاً: القاهرة"
                className="w-full p-2.5 rounded-xl border border-stone-300"
              />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">نوع القضية</label>
              <select
                value={caseType}
                onChange={(e) => setCaseType(e.target.value as any)}
                className="w-full p-2.5 rounded-xl border border-stone-300"
              >
                <option value="detention">احتجاز تعسفي</option>
                <option value="disappearance">اختفاء قسري ومفقودين</option>
                <option value="fair_trial">محاكمة غير عادلة</option>
                <option value="human_rights">انتهاك حقوقي ونقابي</option>
                <option value="custody_death">إهمال صحي وخطر وفاة</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-stone-700 mb-1">حالة التوثيق الأولية</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full p-2.5 rounded-xl border border-stone-300"
              >
                <option value="investigating">🟡 قيد التحقق</option>
                <option value="urgent">🔴 عاجلة</option>
                <option value="verified">🟢 موثقة</option>
                <option value="needs_evidence">🟠 تحتاج أدلة</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">مستوى الخطورة</label>
              <select
                value={riskAssessment}
                onChange={(e) => setRiskAssessment(e.target.value as any)}
                className="w-full p-2.5 rounded-xl border border-stone-300"
              >
                <option value="منخفض">منخفض</option>
                <option value="متوسط">متوسط</option>
                <option value="عالي">عالي</option>
                <option value="حرج">حرج</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">تاريخ الواقعة</label>
              <input
                type="date"
                value={incidentDate}
                onChange={(e) => setIncidentDate(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-stone-300"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">ملخص الوقائع المادية</label>
            <textarea
              rows={3}
              required
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="اكتب شرحاً واقعياً دقيقاً وموضوعياً..."
              className="w-full p-2.5 rounded-xl border border-stone-300"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-emerald-800 mb-1">ما تم التثبت منه مبدئياً</label>
              <input
                type="text"
                value={factKnown}
                onChange={(e) => setFactKnown(e.target.value)}
                placeholder="مثلاً: استلام إفادة رسمية من الأسرة وتوكيل محامٍ"
                className="w-full p-2.5 rounded-xl border border-emerald-300 bg-emerald-50/50"
              />
            </div>
            <div>
              <label className="block font-bold text-amber-800 mb-1">ما لا يزال قيد التحقق</label>
              <input
                type="text"
                value={pendingCheck}
                onChange={(e) => setPendingCheck(e.target.value)}
                placeholder="مثلاً: مكان الاحتجاز الفعلي غير معلن رسمياً"
                className="w-full p-2.5 rounded-xl border border-amber-300 bg-amber-50/50"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-[#0B5145] text-white font-semibold rounded-xl hover:bg-[#083B32] transition-colors cursor-pointer"
            >
              إنشاء الملف وإسناد المعرف الرقمي
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
