import React, { useState } from 'react';
import { 
  Settings, 
  ShieldCheck, 
  Lock, 
  Globe2, 
  Download, 
  Upload, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  Megaphone, 
  FileCode, 
  Key, 
  Database, 
  Save, 
  Sliders, 
  SlidersHorizontal,
  BellRing,
  Clock,
  ExternalLink,
  Trash2,
  Cpu
} from 'lucide-react';
import { CaseItem } from '../../types';

interface AdminSettingsViewProps {
  cases?: CaseItem[];
}

export const AdminSettingsView: React.FC<AdminSettingsViewProps> = ({ cases = [] }) => {
  // General Site Configuration
  const [siteName, setSiteName] = useState('صوت المظلوم — المنصة العربية الموحدة لتوثيق قضايا الاحتجاز');
  const [siteShortName, setSiteShortName] = useState('صوت المظلوم');
  const [siteDescription, setSiteDescription] = useState('منصة حقوقية وثائقية مستقلة لرصد وتوثيق حالات الاعتقال التعسفي والاختفاء القسري في العالم العربي.');
  const [contactEmail, setContactEmail] = useState('secure@sawt-almazloum.org');
  const [signalHotline, setSignalHotline] = useState('+41 22 555 0192');
  const [pgpKeyId, setPgpKeyId] = useState('4A9F 82C1 03B4 D92E 88B1 E5FA 3379 F021');

  // Emergency Banner
  const [emergencyBannerActive, setEmergencyBannerActive] = useState(false);
  const [emergencyBannerText, setEmergencyBannerText] = useState('تنبيه عاجل: رصد تدهور صحي حرج لمعتقلي الرأي المضربين عن الطعام — تفعيل غرفة الطوارئ');
  const [emergencyBannerLevel, setEmergencyBannerLevel] = useState<'urgent' | 'warning' | 'info'>('urgent');

  // Security & Publishing Controls
  const [requireDualApproval, setRequireDualApproval] = useState(true);
  const [autoSha256, setAutoSha256] = useState(true);
  const [autoMaskFamilyNames, setAutoMaskFamilyNames] = useState(true);
  const [zeroIpLogs, setZeroIpLogs] = useState(true);
  const [twoFactorAuthMandatory, setTwoFactorAuthMandatory] = useState(true);

  // Status feedback
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [backupRunning, setBackupRunning] = useState(false);

  const handleSaveAllSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSaveSuccessMsg('تم حفظ وتحديث كافة إعدادات وسياسات الموقع وغرفة العمليات بنجاح.');
    setTimeout(() => setSaveSuccessMsg(null), 4000);
  };

  const handleRunManualBackup = () => {
    setBackupRunning(true);
    setTimeout(() => {
      setBackupRunning(false);
      setSaveSuccessMsg('اكتمل أخذ لقطة احتياطية مشفرة (Snapshot v2.6.4) وتخزينها في السيرفر الآمن.');
      setTimeout(() => setSaveSuccessMsg(null), 4000);
    }, 1200);
  };

  const handleExportFullArchive = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(cases, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `sawt_almazloum_full_archive_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setSaveSuccessMsg('تم تصدير أرشيف القضايا كاملاً بصيغة JSON المفتوحة.');
    setTimeout(() => setSaveSuccessMsg(null), 3000);
  };

  return (
    <div className="space-y-8 text-right pb-16">
      
      {/* 1. Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#DCEBE4] text-[#0B5145] text-xs font-bold font-mono mb-2">
            <span className="w-2 h-2 rounded-full bg-[#0B5145]" />
            <span>لوحة الضبط وإدارة النظام المركزي</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
            <Settings className="w-7 h-7 text-[#0B5145]" />
            <span>إعدادات وإدارة الموقع وغرفة العمليات</span>
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 mt-1 max-w-2xl leading-relaxed">
            التحكم الشامل في هوية المنصة، شريط الطوارئ، سياسات التدقيق الميداني، والتشفير، والنسخ الاحتياطي التلقائي للأرشيف الحقوقي.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSaveAllSettings}
          className="px-4 py-2.5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-bold rounded-xl shadow-sm transition-colors flex items-center gap-2 cursor-pointer self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>حفظ التعديلات</span>
        </button>
      </div>

      {/* Toast Feedback Message */}
      {saveSuccessMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-[#0B5145] font-bold flex items-center gap-2.5 animate-fadeIn shadow-xs">
          <CheckCircle2 className="w-5 h-5 text-[#0B5145] shrink-0" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSaveAllSettings} className="space-y-8">
        
        {/* SECTION 1: General Platform Identity */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-stone-100">
            <div>
              <h2 className="text-base font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
                <Globe2 className="w-5 h-5 text-[#0B5145]" />
                <span>الهوية والبيانات العامة للمنصة</span>
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                العناوين والوصف العام المعتمد لبيانات الموقع والرسائل الرسمية
              </p>
            </div>
            <span className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-stone-100 text-stone-600">
              عام ومعتمد
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-1.5">الاسم الكامل للمنصة</label>
              <input
                type="text"
                value={siteName}
                onChange={(e) => setSiteName(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:border-[#0B5145] focus:ring-1 focus:ring-[#0B5145]"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1.5">الاسم المختصر والعلامة</label>
              <input
                type="text"
                value={siteShortName}
                onChange={(e) => setSiteShortName(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:border-[#0B5145] focus:ring-1 focus:ring-[#0B5145]"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block font-bold text-stone-700 mb-1.5">الوصف التعريفي المعتمد للمنصة</label>
              <textarea
                rows={2}
                value={siteDescription}
                onChange={(e) => setSiteDescription(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:border-[#0B5145] focus:ring-1 focus:ring-[#0B5145]"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1.5">البريد الإلكتروني الآمن للمراسلات</label>
              <input
                type="email"
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-stone-300 text-stone-900 font-mono focus:outline-none focus:border-[#0B5145] focus:ring-1 focus:ring-[#0B5145]"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1.5">الخط الساخن المشفر (Signal / WhatsApp)</label>
              <input
                type="text"
                value={signalHotline}
                onChange={(e) => setSignalHotline(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-stone-300 text-stone-900 font-mono focus:outline-none focus:border-[#0B5145] focus:ring-1 focus:ring-[#0B5145]"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block font-bold text-stone-700 mb-1.5">بصمة مفتاح PGP العام للتواصل السري</label>
              <input
                type="text"
                value={pgpKeyId}
                onChange={(e) => setPgpKeyId(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-stone-300 text-stone-900 font-mono text-[11px] focus:outline-none focus:border-[#0B5145] focus:ring-1 focus:ring-[#0B5145]"
              />
            </div>
          </div>
        </section>

        {/* SECTION 2: Emergency Broadcast Banner */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-stone-100">
            <div>
              <h2 className="text-base font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
                <BellRing className="w-5 h-5 text-rose-600" />
                <span>إدارة شريط الإعلانات وبث الطوارئ (Emergency Banner)</span>
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                تفعيل شريط تنبيهي علوي في واجهة الموقع العامة في حالات الطوارئ القصوى
              </p>
            </div>

            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={emergencyBannerActive}
                onChange={(e) => setEmergencyBannerActive(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-stone-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
              <span className="me-3 text-xs font-bold text-stone-700">
                {emergencyBannerActive ? 'مفعّل حالياً' : 'معطّل'}
              </span>
            </label>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-1.5">نص التنبيه الطارئ</label>
              <input
                type="text"
                value={emergencyBannerText}
                onChange={(e) => setEmergencyBannerText(e.target.value)}
                disabled={!emergencyBannerActive}
                className="w-full p-2.5 rounded-xl border border-stone-300 text-stone-900 disabled:bg-stone-50 disabled:text-stone-400 focus:outline-none focus:border-[#0B5145]"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <span className="font-bold text-stone-700">مستوى الخطورة:</span>
              <button
                type="button"
                onClick={() => setEmergencyBannerLevel('urgent')}
                className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  emergencyBannerLevel === 'urgent'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                حرج / طارئ (أحمر)
              </button>
              <button
                type="button"
                onClick={() => setEmergencyBannerLevel('warning')}
                className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  emergencyBannerLevel === 'warning'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                تحذير متوسط (برتقالي)
              </button>
              <button
                type="button"
                onClick={() => setEmergencyBannerLevel('info')}
                className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  emergencyBannerLevel === 'info'
                    ? 'bg-[#0B5145] text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                إعلان حقوقي عام (زيتي)
              </button>
            </div>
          </div>
        </section>

        {/* SECTION 3: Investigative Protocols & Publishing Policies */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6">
          <div className="pb-4 border-b border-stone-100">
            <h2 className="text-base font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#0B5145]" />
              <span>سياسات التحقيق والنشر والأمان الميداني</span>
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              قواعد صارمة ملزمة لفريق التوثيق لضمان الدقة وحماية سلامة المعتقلين وذويهم
            </p>
          </div>

          <div className="space-y-4 text-xs divide-y divide-stone-100">
            
            {/* Rule 1 */}
            <div className="pt-2 flex items-center justify-between gap-4">
              <div>
                <div className="font-bold text-stone-900">إلزامية الموافقة الثنائية قبل نشر أي ملف (Dual Approval)</div>
                <div className="text-stone-500 text-[11px] mt-0.5">يتطلب نشر أي قضية توقيع الباحث الميداني وتصديق المستشار القانوني بشكل منفصل.</div>
              </div>
              <input
                type="checkbox"
                checked={requireDualApproval}
                onChange={(e) => setRequireDualApproval(e.target.checked)}
                className="w-4 h-4 text-[#0B5145] rounded cursor-pointer accent-[#0B5145]"
              />
            </div>

            {/* Rule 2 */}
            <div className="pt-4 flex items-center justify-between gap-4">
              <div>
                <div className="font-bold text-stone-900">التوليد التلقائي للبصمة الرقمية (SHA-256) لكافة الأدلة</div>
                <div className="text-stone-500 text-[11px] mt-0.5">حساب بصمة تشفير غير قابلة للتغيير فور رفع أي وثيقة رسمية أو شهادة طبية.</div>
              </div>
              <input
                type="checkbox"
                checked={autoSha256}
                onChange={(e) => setAutoSha256(e.target.checked)}
                className="w-4 h-4 text-[#0B5145] rounded cursor-pointer accent-[#0B5145]"
              />
            </div>

            {/* Rule 3 */}
            <div className="pt-4 flex items-center justify-between gap-4">
              <div>
                <div className="font-bold text-stone-900">إخفاء البيانات العائلية والمواقع الجغرافية الحساسة تلقائياً</div>
                <div className="text-stone-500 text-[11px] mt-0.5">حجب ألقاب العائلات والإحداثيات الدقيقة افتراضياً في الواجهة العامة لمنع الملاحقات الانتقامية.</div>
              </div>
              <input
                type="checkbox"
                checked={autoMaskFamilyNames}
                onChange={(e) => setAutoMaskFamilyNames(e.target.checked)}
                className="w-4 h-4 text-[#0B5145] rounded cursor-pointer accent-[#0B5145]"
              />
            </div>

            {/* Rule 4 */}
            <div className="pt-4 flex items-center justify-between gap-4">
              <div>
                <div className="font-bold text-stone-900">سياسة حجب عناوين الـ IP ومنع التتبع الميداني (Zero-Logs Policy)</div>
                <div className="text-stone-500 text-[11px] mt-0.5">مسح وحذف سجلات عناوين الإنترنت لمقدمي البلاغات فور استلام الملف في السيرفر.</div>
              </div>
              <input
                type="checkbox"
                checked={zeroIpLogs}
                onChange={(e) => setZeroIpLogs(e.target.checked)}
                className="w-4 h-4 text-[#0B5145] rounded cursor-pointer accent-[#0B5145]"
              />
            </div>

            {/* Rule 5 */}
            <div className="pt-4 flex items-center justify-between gap-4">
              <div>
                <div className="font-bold text-stone-900">المصادقة الثنائية الإلزامية لمحققي غرفة العمليات (2FA)</div>
                <div className="text-stone-500 text-[11px] mt-0.5">منع الدخول بأي حساب إداري دون استخدام مفتاح أمان مادي أو تطبيق مصادقة.</div>
              </div>
              <input
                type="checkbox"
                checked={twoFactorAuthMandatory}
                onChange={(e) => setTwoFactorAuthMandatory(e.target.checked)}
                className="w-4 h-4 text-[#0B5145] rounded cursor-pointer accent-[#0B5145]"
              />
            </div>

          </div>
        </section>

        {/* SECTION 4: Data Vault, Export & Encrypted Backups */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-stone-100">
            <div>
              <h2 className="text-base font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
                <Database className="w-5 h-5 text-[#0B5145]" />
                <span>إدارة البيانات، النسخ الاحتياطي، وتصدير الأرشيف</span>
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                تأمين وحفظ الأرشيف الحقوقي وضمان بقائه متاحاً وفق المعايير المفتوحة
              </p>
            </div>

            <span className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
              خوادم سويسرية محايدة (Zurich-DC)
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            
            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-800 flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-[#0B5145]" />
                  <span>تصدير الأرشيف المفتوح (JSON)</span>
                </span>
                <span className="font-mono text-stone-400">{cases.length} قضية</span>
              </div>
              <p className="text-stone-500 text-[11px] leading-relaxed">
                تحميل نسخة كاملة موحدة من كافة القضايا والوثائق والخطوط الزمنية بصيغة JSON المفتوحة المتوافقة مع أرشيفات الأمم المتحدة.
              </p>
              <button
                type="button"
                onClick={handleExportFullArchive}
                className="w-full mt-2 py-2 bg-white hover:bg-stone-100 border border-stone-300 text-stone-800 font-semibold rounded-xl transition-colors cursor-pointer"
              >
                تنزيل ملف الأرشيف الكامل (.json)
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-800 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-[#0B5145]" />
                  <span>النسخ الاحتياطي التلقائي المشفر</span>
                </span>
                <span className="font-mono text-[#0B5145] font-bold">كل 6 ساعات</span>
              </div>
              <p className="text-stone-500 text-[11px] leading-relaxed">
                تشفير متزامن لقواعد البيانات وتخزين نسختين موزعتين جغرافياً في مراكز بيانات أوروبية معزولة عن أي ولايات قضائية خاضعة للضغوط.
              </p>
              <button
                type="button"
                onClick={handleRunManualBackup}
                disabled={backupRunning}
                className="w-full mt-2 py-2 bg-[#0B5145] hover:bg-[#083B32] disabled:opacity-50 text-white font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${backupRunning ? 'animate-spin' : ''}`} />
                <span>{backupRunning ? 'جارٍ تشفير وحفظ اللقطة...' : 'أخذ نسخة احتياطية فورية الآن'}</span>
              </button>
            </div>

          </div>
        </section>

      </form>

    </div>
  );
};
