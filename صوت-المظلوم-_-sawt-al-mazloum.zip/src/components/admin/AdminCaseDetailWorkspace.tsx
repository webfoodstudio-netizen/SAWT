import React, { useState } from 'react';
import { CaseItem, VerificationStatus, EvidenceItem, TimelineEvent } from '../../types';
import { 
  ArrowRight, 
  Edit3, 
  Plus, 
  FileText, 
  Layers, 
  History, 
  ShieldCheck, 
  AlertTriangle, 
  AlertCircle,
  Clock, 
  User, 
  MapPin, 
  Calendar, 
  Bot, 
  Check, 
  X, 
  Sparkles, 
  Upload, 
  Lock, 
  Save, 
  CheckCircle2, 
  AlertOctagon, 
  FileCheck 
} from 'lucide-react';
import { INITIAL_ACTIVITY_LOGS, INITIAL_CONTRADICTIONS } from '../../data/mockData';

interface AdminCaseDetailWorkspaceProps {
  caseItem: CaseItem;
  onBack: () => void;
  onUpdateCase: (updated: CaseItem) => void;
  onOpenPublicDossier: (caseId: string) => void;
}

export const AdminCaseDetailWorkspace: React.FC<AdminCaseDetailWorkspaceProps> = ({
  caseItem,
  onBack,
  onUpdateCase,
  onOpenPublicDossier,
}) => {
  // Editing state
  const [isEditingSummary, setIsEditingSummary] = useState(false);
  const [summaryText, setSummaryText] = useState(caseItem.summary);
  const [saveToast, setSaveToast] = useState(false);

  // Modals
  const [showAddEvidenceModal, setShowAddEvidenceModal] = useState(false);
  const [showAddTimelineModal, setShowAddTimelineModal] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);
  const [aiResult, setAiResult] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  // Form states for new evidence
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocType, setNewDocType] = useState<'official' | 'legal' | 'testimony' | 'journalistic'>('official');
  const [newDocDate, setNewDocDate] = useState('2026-10-05');
  const [newDocConfidentiality, setNewDocConfidentiality] = useState<'public' | 'internal' | 'sensitive'>('public');
  const [newDocProves, setNewDocProves] = useState('');

  // Form states for new timeline
  const [newTlDate, setNewTlDate] = useState('');
  const [newTlTitle, setNewTlTitle] = useState('');
  const [newTlDesc, setNewTlDesc] = useState('');
  const [newTlSource, setNewTlSource] = useState('إفادة مسجلة');

  // Verification Checklist State
  const [checklist, setChecklist] = useState([
    { id: 1, label: 'المعلومات الأولية وتحديد الهوية', done: true },
    { id: 2, label: 'التحقق من الهوية والأوراق الثبوتية', done: true },
    { id: 3, label: 'التحقق من التاريخ والبيانات الوصفية', done: true },
    { id: 4, label: 'مقارنة المصادر المتعددة المستقلة', done: true },
    { id: 5, label: 'مراجعة أختام الوثائق الرسمية والمحاضر', done: true },
    { id: 6, label: 'البحث عن التناقضات والفجوات الإجرائية', done: true },
    { id: 7, label: 'المراجعة البشرية لهيئة التحرير', done: true },
    { id: 8, label: 'الموافقة النهائية على النشر والتحديث', done: false },
  ]);

  const completedSteps = checklist.filter(c => c.done).length;
  const progressPercent = Math.round((completedSteps / checklist.length) * 100);

  const handleSaveSummary = () => {
    onUpdateCase({
      ...caseItem,
      summary: summaryText,
      lastUpdated: 'منذ لحظات',
    });
    setIsEditingSummary(false);
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2000);
  };

  const handleStatusChange = (newStatus: VerificationStatus) => {
    onUpdateCase({
      ...caseItem,
      status: newStatus,
      lastUpdated: 'الآن',
    });
    setShowStatusModal(false);
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2000);
  };

  const handleAddEvidence = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle) return;

    const newEvidence: EvidenceItem = {
      id: `ev-${Date.now()}`,
      title: newDocTitle,
      type: newDocType,
      date: newDocDate,
      credibility: 'high',
      provesWhat: newDocProves || 'إثبات معتمد لفحص الواقعة.',
      confidentiality: newDocConfidentiality,
      fileName: `${newDocTitle.replace(/\s+/g, '_')}.pdf`,
      uploader: 'أحمد المنصوري (مدير المنصة)',
      uploadDate: '2026-10-05',
      verificationStatus: 'verified'
    };

    onUpdateCase({
      ...caseItem,
      evidence: [newEvidence, ...caseItem.evidence],
      stats: {
        ...caseItem.stats,
        documentsCount: caseItem.stats.documentsCount + 1,
      },
      lastUpdated: 'الآن',
    });

    setNewDocTitle('');
    setNewDocProves('');
    setShowAddEvidenceModal(false);
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2000);
  };

  const handleAddTimeline = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTlTitle || !newTlDate) return;

    const newEvent: TimelineEvent = {
      id: `tl-${Date.now()}`,
      date: newTlDate,
      title: newTlTitle,
      description: newTlDesc || 'تم التوثيق والتحقق من قبل الفريق.',
      source: newTlSource,
      addedBy: 'أحمد المنصوري (مدير)',
      verificationLevel: 'موثق',
      verified: true,
    };

    onUpdateCase({
      ...caseItem,
      timeline: [newEvent, ...caseItem.timeline],
      stats: {
        ...caseItem.stats,
        updatesCount: caseItem.stats.updatesCount + 1,
      },
      lastUpdated: 'الآن',
    });

    setNewTlDate('');
    setNewTlTitle('');
    setNewTlDesc('');
    setShowAddTimelineModal(false);
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2000);
  };

  const handleRunAiAssistant = (tool: 'summarize' | 'contradictions' | 'draft_en') => {
    setAiLoading(true);
    setAiResult(null);
    setTimeout(() => {
      setAiLoading(false);
      if (tool === 'summarize') {
        setAiResult(`[ملخص تدقيق الوثائق التوليدي - مساعد التحقيق]
القضية: ${caseItem.name} (${caseItem.id})
• التقييم القانوني: المحاضر الرسمية تفتقر لإذن نيابة معتمد قبل المداهمة.
• تطابق المصادر: شهادة الأسرة تتطابق مع سجلات نقابة المحامين بنسبة 100%.
• الحالة الصحية: يتطلب إدخال أدوية القلب فوراً لتفادي تدهور الشريان التاجي.`);
      } else if (tool === 'contradictions') {
        setAiResult(`[تقرير فحص التناقضات بين المصادر]
1. توقيت الاحتجاز: تم رصد فارق 48 ساعة بين تاريخ المداهمة الواقعية في 14 مارس، وبين تاريخ تحرير محضر الشرطة في 16 مارس.
2. التوصية: إدراج هذا الفارق في مذكرة الدفاع الرسمية لإثبات الاحتجاز غير القانوني.`);
      } else {
        setAiResult(`[English Press Release Draft]
CASE: ${caseItem.id} - ${caseItem.name}
Country: ${caseItem.country} (${caseItem.city})
Status: Officially Verified & Documented.
Summary: Held in pretrial detention for ${caseItem.detentionDays || 214} days with urgent medical concerns regarding access to cardiovascular medication.`);
      }
    }, 1100);
  };

  return (
    <div className="space-y-8 text-right pb-14">
      
      {/* 1. Top Bar Navigation & Actions */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
        
        <div>
          <button
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-500 hover:text-[#0B5145] mb-2 cursor-pointer transition-colors"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>العودة إلى جدول القضايا</span>
          </button>

          <div className="flex flex-wrap items-center gap-3">
            <span className="font-mono text-base font-bold text-[#0B5145] bg-[#0B5145]/10 px-3 py-1 rounded-xl">
              {caseItem.id}
            </span>
            <h1 className="text-2xl sm:text-3xl font-bold text-[#17201D] font-serif-ar">
              {caseItem.name} {caseItem.alias && <span className="text-sm font-normal text-stone-500 font-sans">({caseItem.alias})</span>}
            </h1>
            <span className="text-xs font-semibold text-stone-500">
              {caseItem.country} · {caseItem.city}
            </span>
            
            {caseItem.status === 'urgent' ? (
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 animate-pulse">
                🔴 عاجلة
              </span>
            ) : (
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                🟢 موثقة
              </span>
            )}
          </div>
        </div>

        {/* 5 Prominent Action Buttons from Prompt */}
        <div className="flex flex-wrap items-center gap-2">
          
          <button
            onClick={() => setIsEditingSummary(!isEditingSummary)}
            className="px-3.5 py-2 rounded-xl bg-white border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5 text-[#0B5145]" />
            <span>تعديل القضية</span>
          </button>

          <button
            onClick={() => setShowAddTimelineModal(true)}
            className="px-3.5 py-2 rounded-xl bg-white border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Clock className="w-3.5 h-3.5 text-[#0B5145]" />
            <span>+ إضافة تحديث</span>
          </button>

          <button
            onClick={() => setShowAddEvidenceModal(true)}
            className="px-3.5 py-2 rounded-xl bg-white border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-[#0B5145]" />
            <span>+ إضافة وثيقة / دليل</span>
          </button>

          <button
            onClick={() => setShowStatusModal(true)}
            className="px-3.5 py-2 rounded-xl bg-white border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5 text-[#0B5145]" />
            <span>تغيير الحالة</span>
          </button>

          <button
            onClick={() => setShowAiModal(true)}
            className="px-4 py-2 rounded-xl bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
          >
            <Bot className="w-4 h-4 text-emerald-300" />
            <span>مساعد التحقيق الذكي</span>
          </button>

        </div>
      </div>

      {saveToast && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>تم حفظ التعديلات وتحديث ملف القضية بنجاح.</span>
        </div>
      )}

      {/* 2. Section: معلومات القضية (Basic Information & Summaries) */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6">
        <div>
          <h2 className="text-lg font-bold text-[#17201D] font-serif-ar mb-4 pb-2 border-b border-stone-100 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#0B5145]" />
            <span>المعلومات الأساسية للملف</span>
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div className="p-3 rounded-xl bg-[#FBF9F5] border border-stone-200/60">
              <span className="text-stone-400 block mb-0.5 font-mono">الاسم الكامل:</span>
              <strong className="text-stone-900 text-sm font-serif-ar">{caseItem.name}</strong>
            </div>

            <div className="p-3 rounded-xl bg-[#FBF9F5] border border-stone-200/60">
              <span className="text-stone-400 block mb-0.5 font-mono">الاسم المستعار / اللقب:</span>
              <strong className="text-stone-900 text-sm">{caseItem.alias || 'لا يوجد'}</strong>
            </div>

            <div className="p-3 rounded-xl bg-[#FBF9F5] border border-stone-200/60">
              <span className="text-stone-400 block mb-0.5 font-mono">الدولة والمدينة:</span>
              <strong className="text-stone-900 text-sm">{caseItem.country} — {caseItem.city}</strong>
            </div>

            <div className="p-3 rounded-xl bg-[#FBF9F5] border border-stone-200/60">
              <span className="text-stone-400 block mb-0.5 font-mono">نوع القضية:</span>
              <strong className="text-stone-900 text-sm">
                {caseItem.caseType === 'detention' ? 'احتجاز تعسفي' :
                 caseItem.caseType === 'disappearance' ? 'اختفاء قسري' :
                 caseItem.caseType === 'fair_trial' ? 'محاكمة غير عادلة' : 'انتهاك حقوقي'}
              </strong>
            </div>

            <div className="p-3 rounded-xl bg-[#FBF9F5] border border-stone-200/60">
              <span className="text-stone-400 block mb-0.5 font-mono">تاريخ البداية / التوقيف:</span>
              <strong className="text-stone-900 font-mono text-xs">{caseItem.incidentDate}</strong>
            </div>

            <div className="p-3 rounded-xl bg-[#FBF9F5] border border-stone-200/60">
              <span className="text-stone-400 block mb-0.5 font-mono">تاريخ آخر تحديث:</span>
              <strong className="text-[#0B5145] font-mono text-xs">{caseItem.lastUpdated}</strong>
            </div>

            <div className="p-3 rounded-xl bg-[#FBF9F5] border border-stone-200/60">
              <span className="text-stone-400 block mb-0.5 font-mono">مستوى الخطورة:</span>
              <strong className={`text-xs px-2 py-0.5 rounded ${
                caseItem.riskAssessment === 'حرج' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
              }`}>
                {caseItem.riskAssessment || 'عالي'}
              </strong>
            </div>

            <div className="p-3 rounded-xl bg-[#FBF9F5] border border-stone-200/60">
              <span className="text-stone-400 block mb-0.5 font-mono">الحالة الحالية:</span>
              <strong className="text-stone-900 text-xs font-bold">
                {caseItem.status === 'urgent' ? '🔴 عاجلة' :
                 caseItem.status === 'verified' ? '🟢 موثقة' : '🟡 قيد التحقق'}
              </strong>
            </div>
          </div>
        </div>

        {/* Editable Summary (ملخص القضية) */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-stone-900 font-serif-ar">
              ملخص القضية
            </h3>
            {!isEditingSummary && (
              <button
                onClick={() => setIsEditingSummary(true)}
                className="text-xs text-[#0B5145] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Edit3 className="w-3 h-3" />
                <span>تحرير النص</span>
              </button>
            )}
          </div>

          {isEditingSummary ? (
            <div className="space-y-3">
              <textarea
                rows={4}
                value={summaryText}
                onChange={(e) => setSummaryText(e.target.value)}
                className="w-full p-3.5 rounded-2xl bg-stone-50 border border-stone-300 text-xs sm:text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  onClick={() => setIsEditingSummary(false)}
                  className="px-3 py-1.5 text-xs text-stone-600 hover:bg-stone-100 rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleSaveSummary}
                  className="px-5 py-1.5 bg-[#0B5145] text-white text-xs font-semibold rounded-lg hover:bg-[#083B32] transition-colors cursor-pointer"
                >
                  حفظ التعديل
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs sm:text-sm text-stone-700 bg-stone-50 p-4 rounded-2xl border border-stone-200/60 leading-relaxed font-normal">
              {caseItem.summary}
            </p>
          )}
        </div>

        {/* The Split: ما نعرفه vs ما لم نتمكن من التحقق منه */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* What We Know (المعلومات المثبتة) */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80">
            <h4 className="text-xs font-bold text-emerald-950 mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              <span>ما نعرفه (المعلومات المثبتة والمطابقة بالأدلة):</span>
            </h4>
            <ul className="space-y-1.5 pr-2">
              {caseItem.whatWeKnow.map((item, i) => (
                <li key={i} className="text-xs text-emerald-950 flex items-start gap-2 leading-relaxed">
                  <span className="text-emerald-700 font-bold shrink-0">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Under verification (المعلومات غير المؤكدة) */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80">
            <h4 className="text-xs font-bold text-amber-950 mb-2 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-700" />
              <span>ما لم نتمكن من التحقق منه (معلومات تحت المراجعة):</span>
            </h4>
            <ul className="space-y-1.5 pr-2">
              {caseItem.whatUnderVerification.map((item, i) => (
                <li key={i} className="text-xs text-amber-950 flex items-start gap-2 leading-relaxed">
                  <span className="text-amber-700 font-bold shrink-0">⚠️</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>

      </div>

      {/* 3. Section: الأدلة والوثائق (Evidence & Documents Vault) */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-100">
          <div>
            <h2 className="text-lg font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#0B5145]" />
              <span>الأدلة والوثائق المفحوصة</span>
            </h2>
            <div className="flex items-center gap-3 text-xs text-stone-500 font-mono mt-1">
              <span className="font-bold text-stone-900">{caseItem.stats.documentsCount || 4} وثائق</span>
              <span>·</span>
              <span className="font-bold text-stone-900">{caseItem.stats.sourcesCount || 8} مصادر</span>
              <span>·</span>
              <span>{caseItem.stats.testimoniesCount || 2} إفادات</span>
              <span>·</span>
              <span>{caseItem.stats.legalSourcesCount || 1} مصدر قانوني</span>
            </div>
          </div>

          <button
            onClick={() => setShowAddEvidenceModal(true)}
            className="px-4 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ إضافة دليل جديد</span>
          </button>
        </div>

        {/* Evidence Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold font-mono">
                <th className="py-3 px-3">اسم الملف</th>
                <th className="py-3 px-3">نوع الوثيقة</th>
                <th className="py-3 px-3">التاريخ</th>
                <th className="py-3 px-3">مستوى الحساسية</th>
                <th className="py-3 px-3">من قام بالرفع</th>
                <th className="py-3 px-3">تاريخ الرفع</th>
                <th className="py-3 px-3">حالة التحقق</th>
                <th className="py-3 px-3">ما يثبته</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {caseItem.evidence.map((ev) => (
                <tr key={ev.id} className="hover:bg-stone-50/80 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-[#0B5145]">
                    {ev.fileName || `${ev.title}.pdf`}
                  </td>

                  <td className="py-3 px-3 text-stone-700">
                    <span className="px-2 py-0.5 rounded bg-stone-100 font-medium">
                      {ev.type === 'official' ? 'رسمية' :
                       ev.type === 'legal' ? 'قانونية' :
                       ev.type === 'testimony' ? 'شهادة عيان' : 'صحفية'}
                    </span>
                  </td>

                  <td className="py-3 px-3 font-mono text-stone-500">
                    {ev.date}
                  </td>

                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      ev.confidentiality === 'public' ? 'bg-emerald-100 text-emerald-800' :
                      ev.confidentiality === 'internal' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {ev.confidentiality === 'public' ? '🟢 عام' :
                       ev.confidentiality === 'internal' ? '🟡 داخلي' : '🔴 حساس مشفر'}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-stone-600 font-mono text-[11px]">
                    {ev.uploader || 'أحمد المنصوري'}
                  </td>

                  <td className="py-3 px-3 text-stone-400 font-mono text-[11px]">
                    {ev.uploadDate || '2026-03-26'}
                  </td>

                  <td className="py-3 px-3">
                    <span className="text-emerald-700 font-bold flex items-center gap-1 text-[11px]">
                      <Check className="w-3 h-3" />
                      <span>مطابق وموثق</span>
                    </span>
                  </td>

                  <td className="py-3 px-3 text-stone-600 line-clamp-1 max-w-xs">
                    {ev.provesWhat}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4 & 5. Timeline & Verification System Side-by-Side */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Timeline Column (الخط الزمني) */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <div>
              <h2 className="text-base font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
                <History className="w-4 h-4 text-[#0B5145]" />
                <span>الخط الزمني للقضية (Timeline)</span>
              </h2>
              <span className="text-xs text-stone-500 font-mono">سرد وقائع متسلسل مؤرخ ومسنود بمصادر</span>
            </div>

            <button
              onClick={() => setShowAddTimelineModal(true)}
              className="px-3.5 py-1.5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ إضافة حدث</span>
            </button>
          </div>

          {/* Vertical Timeline */}
          <div className="relative border-r-2 border-[#0B5145]/20 pr-6 mr-3 space-y-6">
            {caseItem.timeline.map((item, idx) => (
              <div key={item.id || idx} className="relative group">
                <div className="absolute -right-[31px] top-1.5 w-4 h-4 rounded-full bg-white border-4 border-[#0B5145] shadow-sm" />

                <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200/70 hover:border-stone-300 transition-colors">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-mono font-bold text-[#0B5145]">{item.date}</span>
                    <span className="text-[10px] text-stone-400 font-mono">أضافه: {item.addedBy || 'أحمد — باحث'}</span>
                  </div>

                  <h4 className="text-sm font-bold text-stone-900 font-serif-ar mb-1">
                    {item.title}
                  </h4>

                  <p className="text-xs text-stone-600 leading-relaxed mb-2">
                    {item.description}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-stone-500 pt-2 border-t border-stone-200/60 font-mono">
                    <span>المصدر: <strong>{item.source || item.sourceTier || 'وثيقة رسمية'}</strong></span>
                    <span className="text-emerald-700 font-bold">✓ {item.verificationLevel || 'موثق'}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Verification Checklist & Contradictions Column */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Verification Progress Panel (نظام التحقق) */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="text-sm font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#0B5145]" />
                <span>حالة ونظام التحقق</span>
              </h3>
              <span className="text-xs font-mono font-bold text-[#0B5145]">
                {progressPercent}% مكتمل
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2.5 rounded-full bg-stone-100 overflow-hidden">
              <div
                className="h-full bg-[#0B5145] rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Checklist */}
            <div className="space-y-2 pt-1 text-xs">
              {checklist.map((c) => (
                <div 
                  key={c.id}
                  onClick={() => {
                    setChecklist(prev => prev.map(item => item.id === c.id ? { ...item, done: !item.done } : item));
                  }}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-stone-50 hover:bg-stone-100 cursor-pointer transition-colors"
                >
                  <span className="text-stone-800 font-medium">{c.label}</span>
                  <span className={`w-5 h-5 rounded-md flex items-center justify-center font-bold text-xs ${
                    c.done ? 'bg-[#0B5145] text-white' : 'border border-stone-300 text-transparent'
                  }`}>
                    ✓
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Contradictions Box (التناقضات والمعلومات المتعارضة) */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>معلومات متعارضة (تحت الفحص)</span>
            </h3>

            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs space-y-2">
              <div className="font-bold text-amber-950 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-amber-700" />
                <span>اختلاف في تاريخ الاعتقال والتوقيف</span>
              </div>
              <div className="text-stone-700 space-y-1 font-mono text-[11px]">
                <div><strong>المصدر A:</strong> 14 مارس 2026 (إفادة الأسرة وكاميرات المراقبة)</div>
                <div><strong>المصدر B:</strong> 16 مارس 2026 (محضر قسم الشرطة)</div>
              </div>
              <div className="pt-2 border-t border-amber-200 flex items-center justify-between">
                <span className="text-amber-800 font-bold text-[11px]">يحتاج إلى مراجعة بشرية</span>
                <button
                  onClick={() => alert('تم فتح محضر التحقيق في التضارب وإسناده لمروان البوعزيزي.')}
                  className="px-3 py-1 bg-amber-700 hover:bg-amber-800 text-white text-[11px] font-semibold rounded-lg cursor-pointer"
                >
                  فتح التحقيق
                </button>
              </div>
            </div>
          </div>

          {/* Activity Log Snippet for this Case (سجل التعديلات) */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
              <History className="w-4 h-4 text-[#0B5145]" />
              <span>سجل التعديلات الميداني (Activity Log)</span>
            </h3>

            <div className="divide-y divide-stone-100 text-xs">
              <div className="py-2.5">
                <div className="font-bold text-stone-900">أحمد — الباحث</div>
                <div className="text-stone-600 text-[11px]">أضاف وثيقة جديدة (محضر نيابة مصدق).</div>
                <div className="text-stone-400 text-[10px] font-mono mt-0.5">منذ 15 دقيقة</div>
              </div>

              <div className="py-2.5">
                <div className="font-bold text-stone-900">سارة — فريق التحقق</div>
                <div className="text-stone-600 text-[11px]">غيرت الحالة من "قيد التحقق" إلى "موثقة".</div>
                <div className="text-stone-400 text-[10px] font-mono mt-0.5">منذ ساعتين</div>
              </div>

              <div className="py-2.5">
                <div className="font-bold text-stone-900">محمد — المدير</div>
                <div className="text-stone-600 text-[11px]">عدل ملخص القضية الأساسي.</div>
                <div className="text-stone-400 text-[10px] font-mono mt-0.5">منذ 4 ساعات</div>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* MODAL 1: Add Evidence */}
      {showAddEvidenceModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full text-right shadow-2xl border border-stone-200">
            <h3 className="text-lg font-bold text-[#17201D] font-serif-ar mb-1">
              إضافة وثيقة أو دليل رسمي للملف
            </h3>
            <p className="text-xs text-stone-500 mb-5 font-mono">
              الملف: {caseItem.id} — {caseItem.name}
            </p>

            <form onSubmit={handleAddEvidence} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">عنوان الوثيقة أو المحضر</label>
                <input
                  type="text"
                  required
                  value={newDocTitle}
                  onChange={(e) => setNewDocTitle(e.target.value)}
                  placeholder="مثلاً: محضر جلسة التجديد رقم 1408 أو إفادة محامي"
                  className="w-full p-2.5 rounded-xl border border-stone-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">نوع المصدر</label>
                  <select
                    value={newDocType}
                    onChange={(e) => setNewDocType(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  >
                    <option value="official">وثيقة رسمية / محكمة</option>
                    <option value="legal">مستند قانوني / محامٍ</option>
                    <option value="testimony">إفادة شاهد / أسرة</option>
                    <option value="journalistic">تحقيق صحفي استقصائي</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">مستوى السرية والوصول</label>
                  <select
                    value={newDocConfidentiality}
                    onChange={(e) => setNewDocConfidentiality(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-stone-300 font-semibold"
                  >
                    <option value="public">🟢 عام (متاح للجمهور والصحافة)</option>
                    <option value="internal">🟡 داخلي (لفريق التحقق فقط)</option>
                    <option value="sensitive">🔴 حساس (مشفر - بيانات شهود)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">تاريخ تحرير الوثيقة</label>
                <input
                  type="date"
                  value={newDocDate}
                  onChange={(e) => setNewDocDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-300"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">ما الذي تثبته الوثيقة قانونياً ومادياً؟</label>
                <textarea
                  rows={3}
                  value={newDocProves}
                  onChange={(e) => setNewDocProves(e.target.value)}
                  placeholder="اشرح الواقعة المادية التي تثبتها هذه الوثيقة..."
                  className="w-full p-2.5 rounded-xl border border-stone-300"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowAddEvidenceModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#0B5145] text-white font-semibold rounded-xl hover:bg-[#083B32] cursor-pointer"
                >
                  حفظ واعتماد الوثيقة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Add Timeline Event */}
      {showAddTimelineModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full text-right shadow-2xl border border-stone-200">
            <h3 className="text-lg font-bold text-[#17201D] font-serif-ar mb-1">
              إضافة محطة جديدة في الخط الزمني
            </h3>
            <p className="text-xs text-stone-500 mb-5 font-mono">
              الملف: {caseItem.id}
            </p>

            <form onSubmit={handleAddTimeline} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">التاريخ</label>
                  <input
                    type="text"
                    required
                    value={newTlDate}
                    onChange={(e) => setNewTlDate(e.target.value)}
                    placeholder="مثلاً: 05 أكتوبر 2026"
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">المصدر المرجعي</label>
                  <input
                    type="text"
                    value={newTlSource}
                    onChange={(e) => setNewTlSource(e.target.value)}
                    placeholder="محضر نيابة / إفادة عائلة"
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">عنوان الحدث</label>
                <input
                  type="text"
                  required
                  value={newTlTitle}
                  onChange={(e) => setNewTlTitle(e.target.value)}
                  placeholder="مثلاً: جلسة تجديد الحبس غيابياً أو تقديم طعن"
                  className="w-full p-2.5 rounded-xl border border-stone-300"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">التفاصيل التوثيقية للحدث</label>
                <textarea
                  rows={3}
                  value={newTlDesc}
                  onChange={(e) => setNewTlDesc(e.target.value)}
                  placeholder="شرح موجز لما جرى..."
                  className="w-full p-2.5 rounded-xl border border-stone-300"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowAddTimelineModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#0B5145] text-white font-semibold rounded-xl hover:bg-[#083B32] cursor-pointer"
                >
                  إدراج في التايملاين
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Change Status */}
      {showStatusModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-sm w-full text-right shadow-2xl border border-stone-200">
            <h3 className="text-base font-bold text-[#17201D] font-serif-ar mb-3">
              تغيير حالة توثيق القضية
            </h3>

            <div className="space-y-2 text-xs">
              {[
                { key: 'verified', label: '🟢 موثقة رسمياً ومكتملة الأدلة' },
                { key: 'investigating', label: '🟡 قيد التحقق وفحص المصادر' },
                { key: 'needs_evidence', label: '🟠 تحتاج أدلة ومستندات إضافية' },
                { key: 'urgent', label: '🔴 عاجلة (خطر صحي أو موعد جلسة وشيك)' },
                { key: 'closed', label: '⚫ مغلقة (تم الإفراج أو التسوية)' },
              ].map((s) => (
                <button
                  key={s.key}
                  onClick={() => handleStatusChange(s.key as VerificationStatus)}
                  className={`w-full p-3 rounded-xl border text-right font-semibold transition-all cursor-pointer ${
                    caseItem.status === s.key ? 'bg-[#0B5145] text-white border-[#0B5145]' : 'bg-stone-50 border-stone-200 text-stone-800 hover:bg-stone-100'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => setShowStatusModal(false)}
              className="w-full mt-4 py-2 text-xs text-stone-500 hover:text-stone-800 cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}

      {/* MODAL 4: AI Research Assistant */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#17201D] text-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full text-right shadow-2xl border border-white/15">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white font-serif-ar">
                  مساعد التحقيق بالذكاء الاصطناعي — {caseItem.id}
                </h3>
              </div>
              <button onClick={() => setShowAiModal(false)} className="text-stone-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs mb-4">
              🛡️ <strong>تذكير أخلاقي ملزم:</strong> الذكاء الاصطناعي لا يقرر المظلومية، بل يعاون الباحث في التلخيص، فحص التناقضات، وصياغة المسودات.
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              <button
                onClick={() => handleRunAiAssistant('summarize')}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white cursor-pointer"
              >
                تلخيص الأدلة والمحاضر
              </button>
              <button
                onClick={() => handleRunAiAssistant('contradictions')}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white cursor-pointer"
              >
                كشف التناقضات بين المصادر
              </button>
              <button
                onClick={() => handleRunAiAssistant('draft_en')}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white cursor-pointer"
              >
                مسودة إنجليزية للمنظمات الدولية
              </button>
            </div>

            {aiLoading ? (
              <div className="py-12 text-center text-stone-400">
                <Sparkles className="w-8 h-8 text-emerald-400 animate-spin mx-auto mb-2" />
                <p className="text-xs">جاري تشغيل محرك التحليل الجنائي وفحص الوثائق...</p>
              </div>
            ) : aiResult ? (
              <div className="p-4 rounded-xl bg-black/50 border border-white/10 font-mono text-xs text-stone-200 whitespace-pre-wrap leading-relaxed">
                {aiResult}
              </div>
            ) : (
              <div className="py-8 text-center text-stone-500 text-xs">
                انقر على إحدى الأدوات أعلاه لتشغيل المساعد.
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
