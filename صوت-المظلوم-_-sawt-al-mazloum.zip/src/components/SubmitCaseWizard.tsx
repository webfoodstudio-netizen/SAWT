import React, { useState } from 'react';
import { CaseType, SubmissionReport } from '../types';
import { 
  CheckCircle2, 
  ArrowLeft, 
  ArrowRight, 
  Upload, 
  ShieldCheck, 
  Search, 
  Lock, 
  FileText,
  AlertTriangle
} from 'lucide-react';
import { INITIAL_SUBMISSIONS } from '../data/mockData';

export const SubmitCaseWizard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'submit' | 'track'>('submit');
  const [step, setStep] = useState(1);
  const totalSteps = 8;

  // Form State
  const [formData, setFormData] = useState({
    country: 'مصر',
    city: '',
    caseType: 'detention' as CaseType,
    dateOfIncident: '',
    whatHappened: '',
    affectedPerson: '',
    personAge: '',
    personProfession: '',
    evidenceTypes: [] as string[],
    evidenceDetails: '',
    uploadedFiles: [] as string[],
    contactMethod: '',
    contactIdentifier: '',
    acceptTerms: false,
  });

  const [generatedTrackingId, setGeneratedTrackingId] = useState<string | null>(null);
  const [trackQuery, setTrackQuery] = useState('');
  const [trackResult, setTrackResult] = useState<SubmissionReport | null>(null);
  const [trackError, setTrackError] = useState(false);

  const arabCountries = [
    'مصر', 'السعودية', 'الإمارات', 'البحرين', 'تونس', 'الجزائر', 'المغرب',
    'اليمن', 'ليبيا', 'سوريا', 'السودان', 'الأردن', 'لبنان', 'العراق', 'فلسطين'
  ];

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    }
  };

  const handlePrev = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleFinishSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Generate authentic tracking ID like SUB-2026-00842
    const randomNum = Math.floor(100 + Math.random() * 900);
    const newId = `SUB-2026-00${randomNum}`;
    setGeneratedTrackingId(newId);
  };

  const handleTrackLookup = (e: React.FormEvent) => {
    e.preventDefault();
    setTrackError(false);
    const query = trackQuery.trim();
    if (!query) return;

    const found = INITIAL_SUBMISSIONS.find(s => s.trackingId.toLowerCase() === query.toLowerCase());
    if (found) {
      setTrackResult(found);
    } else if (generatedTrackingId && query.toLowerCase() === generatedTrackingId.toLowerCase()) {
      setTrackResult({
        trackingId: generatedTrackingId,
        submissionDate: '2026-10-05',
        country: formData.country,
        city: formData.city || 'غير محدد',
        caseType: formData.caseType,
        affectedPerson: formData.affectedPerson || 'مقدم البلاغ',
        summary: formData.whatHappened || 'تم استلام البيانات وجاري التحقق الأولي',
        evidenceDetails: formData.evidenceDetails || 'مستندات مرفوعة',
        documentsCount: formData.uploadedFiles.length || 1,
        contactSecure: formData.contactIdentifier || 'قناة مشفرة',
        status: 'under_review',
        statusTextAr: 'تم استلام الملف بنجاح وهو قيد الفحص الأولي من فريق التحقيق',
        lastUpdateDate: '2026-10-05',
        adminNotes: 'الملف مسجل بنجاح في نظام التوثيق المشفر.'
      });
    } else {
      setTrackResult(null);
      setTrackError(true);
    }
  };

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-10 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* View Switcher Tabs */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <button
            onClick={() => setActiveTab('submit')}
            className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'submit' 
                ? 'bg-[#0B5145] text-white shadow-sm' 
                : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50'
            }`}
          >
            تقديم بلاغ عن قضية جديدة (Wizard)
          </button>

          <button
            onClick={() => setActiveTab('track')}
            className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'track' 
                ? 'bg-[#0B5145] text-white shadow-sm' 
                : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50'
            }`}
          >
            متابعة حالة بلاغ سابق برقم المتابعة
          </button>
        </div>

        {/* TAB 1: 8-Step Wizard */}
        {activeTab === 'submit' && (
          <div>
            {generatedTrackingId ? (
              /* Success Screen with Unique Tracking ID */
              <div className="bg-white rounded-3xl p-8 sm:p-14 border border-stone-200/80 shadow-md text-center max-w-2xl mx-auto">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-10 h-10" />
                </div>

                <span className="text-xs font-mono font-bold text-emerald-700 uppercase tracking-widest block mb-1">
                  تم استلام القضية بنجاح
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold text-[#17201D] font-serif-ar mb-3">
                  رقم متابعة الملف الخاص بك
                </h2>

                <div className="p-4 bg-stone-50 rounded-2xl border-2 border-dashed border-[#0B5145] max-w-sm mx-auto my-6">
                  <span className="text-xs text-stone-500 font-mono block mb-1">احتفظ بهذا الرقم للاستعلام:</span>
                  <div className="text-2xl sm:text-3xl font-mono font-bold text-[#0B5145] select-all">
                    {generatedTrackingId}
                  </div>
                </div>

                <p className="text-stone-600 text-xs sm:text-sm leading-relaxed mb-6">
                  تم تشفير بياناتك وإرسالها إلى غرفة التحقيق الأولية. سنبدأ بمقارنة المعطيات مع الوثائق الرسمية والتواصل معك عبر القناة الآمنة التي حددتها في حال الحاجة لمستندات تكميلية.
                </p>

                <div className="flex flex-wrap items-center justify-center gap-3">
                  <button
                    onClick={() => {
                      setTrackQuery(generatedTrackingId);
                      setActiveTab('track');
                    }}
                    className="px-6 py-3 bg-[#0B5145] text-white text-xs sm:text-sm font-semibold rounded-xl hover:bg-[#083B32] transition-colors cursor-pointer"
                  >
                    الانتقال لمتابعة حالة البلاغ الآن
                  </button>

                  <button
                    onClick={() => {
                      setGeneratedTrackingId(null);
                      setStep(1);
                      setFormData({
                        country: 'مصر',
                        city: '',
                        caseType: 'detention',
                        dateOfIncident: '',
                        whatHappened: '',
                        affectedPerson: '',
                        personAge: '',
                        personProfession: '',
                        evidenceTypes: [],
                        evidenceDetails: '',
                        uploadedFiles: [],
                        contactMethod: '',
                        contactIdentifier: '',
                        acceptTerms: false,
                      });
                    }}
                    className="px-5 py-3 border border-stone-300 text-stone-700 text-xs sm:text-sm font-semibold rounded-xl hover:bg-stone-50 transition-colors cursor-pointer"
                  >
                    تقديم بلاغ آخر
                  </button>
                </div>
              </div>
            ) : (
              /* Wizard Steps Card */
              <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm">
                
                {/* Stepper Header */}
                <div className="mb-8 pb-6 border-b border-stone-100">
                  <div className="flex items-center justify-between text-xs font-mono text-stone-500 mb-2">
                    <span>الخطوة {step} من {totalSteps}</span>
                    <span className="font-bold text-[#0B5145]">
                      {Math.round((step / totalSteps) * 100)}% مكتمل
                    </span>
                  </div>

                  <div className="w-full h-2 rounded-full bg-stone-100 overflow-hidden mb-4">
                    <div 
                      className="h-full bg-[#0B5145] transition-all duration-300 rounded-full"
                      style={{ width: `${(step / totalSteps) * 100}%` }}
                    />
                  </div>

                  <h2 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar">
                    {step === 1 && '01 — أين وقعت القضية؟'}
                    {step === 2 && '02 — ما نوع القضية أو الانتهاك؟'}
                    {step === 3 && '03 — ماذا حدث بالتحديد؟'}
                    {step === 4 && '04 — من هو الشخص أو الأشخاص المعنيون؟'}
                    {step === 5 && '05 — ما الأدلة والمستندات المتوفرة؟'}
                    {step === 6 && '06 — رفع الوثائق والتسجيلات المتاحة'}
                    {step === 7 && '07 — معلومات التواصل الآمنة'}
                    {step === 8 && '08 — مراجعة البلاغ والموافقة على سياسة النشر'}
                  </h2>
                </div>

                {/* Form Steps Content */}
                <div className="min-h-[260px]">
                  
                  {/* Step 1: Location */}
                  {step === 1 && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-2">
                          الدولة العربية
                        </label>
                        <select
                          value={formData.country}
                          onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                          className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                        >
                          {arabCountries.map((c) => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-2">
                          المدينة أو المحافظة / المنطقة
                        </label>
                        <input
                          type="text"
                          value={formData.city}
                          onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                          placeholder="مثلاً: القاهرة - حي المعادي، أو تونس العاصمة..."
                          className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {/* Step 2: Case Type */}
                  {step === 2 && (
                    <div className="space-y-4">
                      <label className="block text-xs font-bold text-stone-700 mb-2">
                        اختر التصنيف الأكثر دقة
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {[
                          { type: 'detention', label: 'احتجاز تعسفي / حبس احتياطي مطول' },
                          { type: 'disappearance', label: 'اختفاء قسري / مفقود دون إعلان' },
                          { type: 'fair_trial', label: 'محاكمة تفتقر لضمانات العدالة والدفاع' },
                          { type: 'human_rights', label: 'ملاحقة نشطاء ومدافعين ونقابيين' },
                          { type: 'custody_death', label: 'إهمال طبي حرج / خطر على الحياة' },
                          { type: 'humanitarian', label: 'استهداف كوادر إغاثية / قضية إنسانية' },
                        ].map((t) => (
                          <button
                            key={t.type}
                            type="button"
                            onClick={() => setFormData({ ...formData, caseType: t.type as CaseType })}
                            className={`p-3.5 rounded-xl border text-right text-xs font-semibold transition-all cursor-pointer ${
                              formData.caseType === t.type
                                ? 'bg-[#0B5145] text-white border-[#0B5145] shadow-sm'
                                : 'bg-stone-50 border-stone-200 text-stone-800 hover:bg-stone-100'
                            }`}
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Step 3: What Happened */}
                  {step === 3 && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          تاريخ بداية الواقعة أو التوقيف (إن وُجد)
                        </label>
                        <input
                          type="date"
                          value={formData.dateOfIncident}
                          onChange={(e) => setFormData({ ...formData, dateOfIncident: e.target.value })}
                          className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          سرد الوقائع المادية بدقة وموضوعية (دون اتهامات غير مدعمة)
                        </label>
                        <textarea
                          rows={5}
                          value={formData.whatHappened}
                          onChange={(e) => setFormData({ ...formData, whatHappened: e.target.value })}
                          placeholder="اشرح بدقة: كيف تم التوقيف، ما الجهة التي داهمت أو استدعت، ما آخر معلومة مؤكدة، وهل تم العرض على النيابة أو المحكمة..."
                          className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {/* Step 4: Affected Persons */}
                  {step === 4 && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          اسم المعني أو الضحية (أو اللقب إذا كان مجهولاً)
                        </label>
                        <input
                          type="text"
                          value={formData.affectedPerson}
                          onChange={(e) => setFormData({ ...formData, affectedPerson: e.target.value })}
                          placeholder="الاسم الكامل للشخص المعني"
                          className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-bold text-stone-700 mb-1">
                            العمر / تاريخ الميلاد التقريبي
                          </label>
                          <input
                            type="text"
                            value={formData.personAge}
                            onChange={(e) => setFormData({ ...formData, personAge: e.target.value })}
                            placeholder="مثلاً: 34 عاماً"
                            className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-stone-700 mb-1">
                            المهنة أو الصفة
                          </label>
                          <input
                            type="text"
                            value={formData.personProfession}
                            onChange={(e) => setFormData({ ...formData, personProfession: e.target.value })}
                            placeholder="مثلاً: صحفي، باحث، طالب، عامل، محامٍ..."
                            className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Step 5: Evidence Details */}
                  {step === 5 && (
                    <div className="space-y-4">
                      <label className="block text-xs font-bold text-stone-700 mb-2">
                        ما نوع الأدلة المتوفرة لديك حالياً؟
                      </label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {[
                          'محضر شرطة أو أمر نيابة رسمي',
                          'تقرير طبي أو شهادة مستشفى',
                          'إفادة مكتوبة أو مسجلة من الأسرة',
                          'تسجيلات كاميرات أو صور مؤرخة',
                          'إشعار تلغراف أو شكوى للنائب العام',
                          'توكيل محامٍ وقرارات جلسات'
                        ].map((item) => (
                          <label key={item} className="flex items-center gap-2 p-2.5 rounded-lg bg-stone-50 border border-stone-200 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={formData.evidenceTypes.includes(item)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFormData({ ...formData, evidenceTypes: [...formData.evidenceTypes, item] });
                                } else {
                                  setFormData({ ...formData, evidenceTypes: formData.evidenceTypes.filter(x => x !== item) });
                                }
                              }}
                              className="accent-[#0B5145]"
                            />
                            <span>{item}</span>
                          </label>
                        ))}
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          توضيح حول الأدلة (أرقام القضايا، أسماء شهود، إلخ)
                        </label>
                        <textarea
                          rows={3}
                          value={formData.evidenceDetails}
                          onChange={(e) => setFormData({ ...formData, evidenceDetails: e.target.value })}
                          placeholder="مثلاً: رقم القضية في نيابة أمن الدولة، أو تاريخ تقديم الشكوى لنقابة المحامين..."
                          className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {/* Step 6: Upload Documents */}
                  {step === 6 && (
                    <div className="space-y-4">
                      <div className="border-2 border-dashed border-stone-300 rounded-2xl p-8 text-center bg-stone-50 hover:bg-stone-100/50 transition-colors">
                        <Upload className="w-10 h-10 text-stone-400 mx-auto mb-2" />
                        <span className="text-sm font-bold text-stone-800 block mb-1">
                          اسحب الوثائق إلى هنا أو انقر للإرفاق
                        </span>
                        <span className="text-xs text-stone-500 block mb-3">
                          (PDF, JPG, PNG, MP3) — تشفير من طرف إلى طرف (End-to-End)
                        </span>

                        <button
                          type="button"
                          onClick={() => {
                            const sampleDocs = ['محضر_التوقيف_الرسمي_ممسوح.pdf', 'بطاقة_الرقم_القومي.jpg', 'تقرير_طبي_معتمد.pdf'];
                            setFormData({ ...formData, uploadedFiles: sampleDocs });
                          }}
                          className="px-4 py-2 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-50 cursor-pointer shadow-sm"
                        >
                          محاكاة إرفاق 3 مستندات موثقة
                        </button>
                      </div>

                      {formData.uploadedFiles.length > 0 && (
                        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 space-y-1">
                          <span className="font-bold block">الملفات المرفقة ({formData.uploadedFiles.length}):</span>
                          {formData.uploadedFiles.map((file, i) => (
                            <div key={i} className="flex items-center gap-1.5 font-mono">
                              <FileText className="w-3.5 h-3.5" />
                              <span>{file} (مشفر ومحمي)</span>
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="p-3 rounded-xl bg-stone-100 text-[11px] text-stone-600 flex items-start gap-2">
                        <Lock className="w-4 h-4 text-[#0B5145] shrink-0 mt-0.5" />
                        <span>الملفات المرفوعة لا تُنشر تلقائياً؛ يقوم فريق التحري بإخفاء أي بيانات حساسة للشهود قبل إتاحة أي نسخة عامة.</span>
                      </div>
                    </div>
                  )}

                  {/* Step 7: Secure Contact */}
                  {step === 7 && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-stone-700 mb-1">
                          القناة الآمنة المفضلة للتواصل
                        </label>
                        <select
                          value={formData.contactMethod}
                          onChange={(e) => setFormData({ ...formData, contactMethod: e.target.value })}
                          className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                        >
                          <option value="">اختر الوسيلة...</option>
                          <option value="signal">تطبيق Signal (الأكثر أماناً)</option>
                          <option value="telegram">تليغرام (معرف آمن)</option>
                          <option value="protonmail">بريد مشفر (ProtonMail / Tuta)</option>
                          <option value="email">بريد إلكتروني عادي</option>
                          <option value="anonymous">بدون تواصل (بلاغ سري تماماً)</option>
                        </select>
                      </div>

                      {formData.contactMethod !== 'anonymous' && (
                        <div>
                          <label className="block text-xs font-bold text-stone-700 mb-1">
                            معرف القناة أو البريد
                          </label>
                          <input
                            type="text"
                            value={formData.contactIdentifier}
                            onChange={(e) => setFormData({ ...formData, contactIdentifier: e.target.value })}
                            placeholder="مثلاً: +2010... أو @secure_handle"
                            className="w-full p-3 rounded-xl border border-stone-300 text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                          />
                        </div>
                      )}
                    </div>
                  )}

                  {/* Step 8: Review & Terms */}
                  {step === 8 && (
                    <div className="space-y-4">
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-2">
                        <h4 className="font-bold text-stone-900 mb-2">ملخص البلاغ:</h4>
                        <div><strong>الدولة:</strong> {formData.country} · {formData.city || 'غير محدد'}</div>
                        <div><strong>نوع القضية:</strong> {formData.caseType}</div>
                        <div><strong>المعني:</strong> {formData.affectedPerson || 'لم يُحدد'}</div>
                        <div><strong>المستندات المرفقة:</strong> {formData.uploadedFiles.length} ملفات</div>
                      </div>

                      <label className="flex items-start gap-3 p-4 rounded-2xl bg-amber-50/70 border border-amber-200 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.acceptTerms}
                          onChange={(e) => setFormData({ ...formData, acceptTerms: e.target.checked })}
                          className="mt-1 accent-[#0B5145] w-4 h-4"
                        />
                        <span className="text-xs text-amber-950 leading-relaxed">
                          أقر بأن المعلومات الواردة في هذا البلاغ صحيحة وفق علمي، وأوافق على ميثاق منصة صوت المظلوم بعدم توجيه اتهامات كيدية أو غير مدعومة بوثائق، وتفويض فريق التوثيق لفحص الأدلة والتواصل مع هيئات الدفاع المستقلة.
                        </span>
                      </label>
                    </div>
                  )}

                </div>

                {/* Stepper Navigation Buttons */}
                <div className="flex items-center justify-between pt-8 border-t border-stone-100 mt-6">
                  {step > 1 ? (
                    <button
                      type="button"
                      onClick={handlePrev}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-stone-300 text-stone-700 text-xs sm:text-sm font-semibold hover:bg-stone-50 cursor-pointer"
                    >
                      <ArrowRight className="w-4 h-4" />
                      <span>السابق</span>
                    </button>
                  ) : <div />}

                  {step < totalSteps ? (
                    <button
                      type="button"
                      onClick={handleNext}
                      className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#0B5145] text-white text-xs sm:text-sm font-semibold hover:bg-[#083B32] transition-colors cursor-pointer"
                    >
                      <span>التالي</span>
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={!formData.acceptTerms}
                      onClick={handleFinishSubmit}
                      className={`inline-flex items-center gap-2 px-8 py-3 rounded-xl text-white text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                        formData.acceptTerms ? 'bg-[#0B5145] hover:bg-[#083B32] shadow-md' : 'bg-stone-300 cursor-not-allowed'
                      }`}
                    >
                      <span>إرسال القضية وتوليد رقم المتابعة</span>
                      <CheckCircle2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

              </div>
            )}
          </div>
        )}

        {/* TAB 2: Track Existing Submission */}
        {activeTab === 'track' && (
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm max-w-2xl mx-auto">
            <h3 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar mb-2">
              الاستعلام عن حالة البلاغ
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 mb-6 leading-relaxed">
              أدخل رقم المتابعة الخاص بملفك (مثلاً: <strong className="font-mono">SUB-2026-00842</strong>) للاطلاع على تطورات الفحص والمراجعة.
            </p>

            <form onSubmit={handleTrackLookup} className="flex gap-2 mb-6">
              <input
                type="text"
                value={trackQuery}
                onChange={(e) => setTrackQuery(e.target.value)}
                placeholder="SUB-2026-XXXXX"
                className="flex-1 px-4 py-3 rounded-xl border border-stone-300 font-mono text-sm uppercase focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs sm:text-sm font-semibold rounded-xl transition-colors cursor-pointer"
              >
                استعلام
              </button>
            </form>

            {trackError && (
              <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 mb-4">
                لم يتم العثور على ملف بهذا الرقم. تأكد من إدخال الرمز بصيغة SUB-2026-00842 بدقة.
              </div>
            )}

            {trackResult && (
              <div className="p-5 rounded-2xl bg-[#FBF9F5] border border-stone-200 text-right space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                  <span className="font-mono font-bold text-[#0B5145] text-sm">{trackResult.trackingId}</span>
                  <span className="text-xs text-stone-400 font-mono">تاريخ التقديم: {trackResult.submissionDate}</span>
                </div>

                <div>
                  <div className="text-xs text-stone-500 font-mono mb-1">الحالة الحالية:</div>
                  <div className="text-sm font-bold text-stone-900 bg-white p-2.5 rounded-lg border border-stone-200">
                    🟢 {trackResult.statusTextAr}
                  </div>
                </div>

                <div className="text-xs text-stone-700">
                  <strong>الشخص المعني:</strong> {trackResult.affectedPerson} ({trackResult.country} - {trackResult.city})
                </div>

                {trackResult.adminNotes && (
                  <div className="p-3 bg-stone-100 rounded-xl text-xs text-stone-600">
                    <strong>ملاحظات غرفة التحقيق:</strong> {trackResult.adminNotes}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
