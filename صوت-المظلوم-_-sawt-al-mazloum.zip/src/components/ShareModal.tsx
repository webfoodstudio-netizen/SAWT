import React, { useState } from 'react';
import { CaseItem } from '../types';
import { X, Copy, Check, Share2, Download } from 'lucide-react';
import { generateQrSvgPath } from '../utils/qrCode';

interface ShareModalProps {
  caseItem: CaseItem | null;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ caseItem, onClose }) => {
  const [copied, setCopied] = useState(false);
  if (!caseItem) return null;

  const caseUrl = `${window.location.origin}/#/case/${caseItem.id}`;
  const shareText = `قضية موثقة: ${caseItem.name} (${caseItem.id}) - محتجز في ${caseItem.country}. اطلع على ملف الأدلة والتوثيق عبر منصة صوت المظلوم:`;
  const qrSvg = generateQrSvgPath(caseUrl, 160);

  const handleCopy = () => {
    navigator.clipboard.writeText(`${shareText}\n${caseUrl}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareWhatsApp = `https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareText}\n${caseUrl}`)}`;
  const shareTelegram = `https://t.me/share/url?url=${encodeURIComponent(caseUrl)}&text=${encodeURIComponent(shareText)}`;
  const shareX = `https://twitter.com/intent/tweet?text=${encodeURIComponent(`${shareText}\n${caseUrl}`)}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full text-right shadow-2xl border border-stone-200 relative">
        <button
          onClick={onClose}
          className="absolute left-4 top-4 text-stone-400 hover:text-stone-700 cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-xl font-bold text-[#17201D] font-serif-ar mb-1">
          مشاركة ملف القضية
        </h3>
        <p className="text-xs text-stone-500 mb-6 font-mono">
          {caseItem.id} — {caseItem.name}
        </p>

        {/* QR Code preview */}
        <div className="flex flex-col items-center justify-center p-4 bg-[#FBF9F5] rounded-2xl border border-stone-200 mb-6 text-center">
          <img src={qrSvg} alt="QR" className="w-32 h-32 rounded-lg mb-2" />
          <span className="text-[11px] text-stone-500 font-mono">
            رمز QR مباشر للقضية
          </span>
        </div>

        {/* Social channels */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          <a
            href={shareWhatsApp}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold text-center transition-colors"
          >
            واتساب
          </a>
          <a
            href={shareTelegram}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-semibold text-center transition-colors"
          >
            تليغرام
          </a>
          <a
            href={shareX}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold text-center transition-colors"
          >
            منصة X
          </a>
        </div>

        {/* Direct Link Copy */}
        <div className="relative mb-4">
          <input
            type="text"
            readOnly
            value={caseUrl}
            className="w-full pr-3 pl-20 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-600 font-mono"
          />
          <button
            onClick={handleCopy}
            className="absolute left-1.5 top-1.5 px-3 py-1 bg-[#0B5145] text-white text-xs font-semibold rounded-lg hover:bg-[#083B32] transition-colors flex items-center gap-1 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ' : 'نسخ'}</span>
          </button>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 text-xs font-semibold text-stone-500 hover:text-stone-800 text-center cursor-pointer"
        >
          إغلاق النافذة
        </button>
      </div>
    </div>
  );
};
