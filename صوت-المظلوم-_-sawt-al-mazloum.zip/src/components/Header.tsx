import React, { useState } from 'react';
import { ViewType, Language } from '../types';
import { 
  Bell, 
  Menu, 
  X, 
  Globe, 
  ShieldCheck, 
  ChevronDown,
  LayoutDashboard,
  Search,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface HeaderProps {
  currentView: ViewType;
  onNavigate: (view: ViewType, caseId?: string) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  notificationsCount?: number;
  unreadCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  language,
  onLanguageChange,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const notifications = [
    {
      id: 'n1',
      caseId: 'CASE-EGY-042',
      caseName: 'محمد بن سالم',
      time: 'منذ 3 ساعات',
      text: 'تطور قانوني: انعقاد جلسة تجديد الحبس غيابياً وهيئة الدفاع تقدم مذكرة طعن مستعجلة.',
      type: 'urgent',
    },
    {
      id: 'n2',
      caseId: 'CASE-TUN-014',
      caseName: 'فاطمة الزهراء',
      time: 'منذ 6 ساعات',
      text: 'إضافة وثيقة جديدة: إفادة نقابة الصحفيين بشأن تفريغ كاميرات المراقبة.',
      type: 'update',
    },
    {
      id: 'n3',
      caseId: 'CASE-MAR-007',
      caseName: 'علي العلوي',
      time: 'منذ يوم',
      text: 'تغير حالة التوثيق: استيفاء فحص محاضر الجلسة واعتماد الملف رسمياً.',
      type: 'verified',
    }
  ];

  const primaryNavItems: { label: string; view: ViewType }[] = [
    { label: 'الرئيسية', view: 'home' },
    { label: 'القضايا', view: 'cases' },
    { label: 'الدول', view: 'countries' },
    { label: 'العاجلة', view: 'urgent' },
    { label: 'الحملات', view: 'campaigns' },
    { label: 'كيف نتحقق؟', view: 'verification_guide' },
    { label: 'شبكة المساعدة', view: 'legal_network' },
    { label: 'من نحن', view: 'about' },
    { label: 'الميثاق', view: 'charter' },
  ];

  const secondaryNavItems: { label: string; view: ViewType }[] = [
    { label: 'المركز الإعلامي', view: 'media_center' },
    { label: 'صندوق الدعم', view: 'fund' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#F5F3EE]/95 backdrop-blur-md border-b border-[#0B5145]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2.5 text-right group cursor-pointer focus:outline-none"
            >
              <div className="w-10 h-10 rounded-lg bg-[#0B5145] text-white flex items-center justify-center shadow-sm group-hover:bg-[#083B32] transition-colors">
                {/* Stylized Feather/Voice Emblem */}
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14.5v-9l6 4.5-6 4.5z" opacity="0.2"/>
                  <path d="M13.5 4.06c0 1.3-1.07 2.36-2.38 2.36-1.3 0-2.37-1.06-2.37-2.36C8.75 2.76 9.82 1.7 11.12 1.7c1.31 0 2.38 1.06 2.38 2.36zm5.8 7.37c-.36-.08-.73.12-.85.48-1.03 3.12-3.8 5.34-7.07 5.56v1.98c4.25-.23 7.82-3.1 9.07-7.14.13-.37-.08-.77-.45-.88h-.7zm-14.7.48c-.12-.36-.49-.56-.85-.48-.37.11-.58.51-.45.88 1.25 4.04 4.82 6.91 9.07 7.14v-1.98c-3.27-.22-6.04-2.44-7.07-5.56h-.7zM12 7c-2.76 0-5 2.24-5 5v3c0 2.76 2.24 5 5 5s5-2.24 5-5v-3c0-2.76-2.24-5-5-5zm3 8c0 1.66-1.34 3-3 3s-3-1.34-3-3v-3c0-1.66 1.34-3 3-3s3 1.34 3 3v3z" />
                </svg>
              </div>
              <div className="flex flex-col text-right">
                <span className="text-xl font-bold tracking-tight text-[#17201D] font-serif-ar">
                  صوت المظلوم
                </span>
                <span className="text-[11px] text-[#0B5145] font-medium leading-none hidden sm:block">
                  لأن صوت المظلوم لا يجب أن يختفي
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-[14px] font-medium text-[#17201D]/80">
            {primaryNavItems.map((item) => {
              const isActive = currentView === item.view;
              return (
                <button
                  key={item.view}
                  onClick={() => onNavigate(item.view)}
                  className={`px-2.5 py-1.5 rounded-md transition-all whitespace-nowrap cursor-pointer ${
                    isActive 
                      ? 'text-[#0B5145] font-semibold bg-[#0B5145]/8' 
                      : 'hover:text-[#0B5145] hover:bg-black/5'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Quick notifications bell */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 rounded-lg text-[#17201D]/70 hover:text-[#0B5145] hover:bg-[#0B5145]/8 transition-colors cursor-pointer"
                title="تحديثات القضايا"
                aria-label="تحديثات القضايا"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-600 ring-2 ring-[#F5F3EE]"></span>
              </button>

              {/* Notifications Popover */}
              {showNotifications && (
                <div className="absolute left-0 sm:left-auto sm:right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-stone-200 p-4 z-50 text-right">
                  <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-3">
                    <span className="text-xs text-stone-500 font-mono">آخر التطورات الموثقة</span>
                    <h4 className="text-sm font-bold text-[#17201D] flex items-center gap-1.5">
                      <Bell className="w-4 h-4 text-[#0B5145]" />
                      إشعارات القضايا
                    </h4>
                  </div>
                  <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                    {notifications.map((item) => (
                      <div 
                        key={item.id}
                        onClick={() => {
                          setShowNotifications(false);
                          onNavigate('case_detail', item.caseId);
                        }}
                        className="p-2.5 rounded-lg bg-stone-50 hover:bg-[#0B5145]/5 transition-colors cursor-pointer border border-stone-100"
                      >
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-stone-400 font-mono text-[11px]">{item.time}</span>
                          <span className="font-bold text-[#0B5145]">{item.caseId}</span>
                        </div>
                        <p className="text-xs text-stone-700 leading-relaxed font-medium">
                          {item.text}
                        </p>
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => {
                      setShowNotifications(false);
                      onNavigate('cases');
                    }}
                    className="w-full mt-3 pt-2 text-center text-xs font-semibold text-[#0B5145] hover:underline border-t border-stone-100 block cursor-pointer"
                  >
                    عرض سجل جميع التحديثات →
                  </button>
                </div>
              )}
            </div>

            {/* Language switcher */}
            <div className="relative hidden sm:block">
              <button
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-stone-700 bg-white/80 rounded-md border border-stone-200 hover:border-stone-300 transition-colors cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 text-[#0B5145]" />
                <span>{language === 'ar' ? 'العربية' : language === 'fr' ? 'Français' : 'English'}</span>
                <ChevronDown className="w-3 h-3 text-stone-400" />
              </button>
              {showLangMenu && (
                <div className="absolute left-0 mt-1.5 w-28 bg-white rounded-lg shadow-lg border border-stone-200 py-1 z-50 text-right">
                  <button
                    onClick={() => { onLanguageChange('ar'); setShowLangMenu(false); }}
                    className={`w-full px-3 py-1.5 text-xs text-right cursor-pointer hover:bg-stone-50 ${language === 'ar' ? 'font-bold text-[#0B5145]' : 'text-stone-700'}`}
                  >
                    العربية (RTL)
                  </button>
                  <button
                    onClick={() => { onLanguageChange('fr'); setShowLangMenu(false); }}
                    className={`w-full px-3 py-1.5 text-xs text-right cursor-pointer hover:bg-stone-50 ${language === 'fr' ? 'font-bold text-[#0B5145]' : 'text-stone-700'}`}
                  >
                    Français
                  </button>
                  <button
                    onClick={() => { onLanguageChange('en'); setShowLangMenu(false); }}
                    className={`w-full px-3 py-1.5 text-xs text-right cursor-pointer hover:bg-stone-50 ${language === 'en' ? 'font-bold text-[#0B5145]' : 'text-stone-700'}`}
                  >
                    English
                  </button>
                </div>
              )}
            </div>

            {/* Admin Dashboard shortcut */}
            <button
              onClick={() => onNavigate('admin_dashboard')}
              className={`p-2 rounded-lg text-stone-600 hover:text-[#0B5145] hover:bg-[#0B5145]/8 transition-colors cursor-pointer hidden md:flex items-center gap-1.5 text-xs font-medium ${
                currentView === 'admin_dashboard' ? 'text-[#0B5145] bg-[#0B5145]/10 font-bold' : ''
              }`}
              title="لوحة الإدارة والتحقيق"
            >
              <LayoutDashboard className="w-4 h-4 text-[#0B5145]" />
              <span className="hidden xl:inline">غرفة التحقيق</span>
            </button>

            {/* Primary Action Button: Submit Case */}
            <button
              onClick={() => onNavigate('submit_case')}
              className="flex items-center gap-1.5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs sm:text-sm font-semibold px-3 sm:px-4 py-2 rounded-lg shadow-sm transition-all whitespace-nowrap cursor-pointer hover:shadow"
            >
              <span>+ قدّم قضية</span>
            </button>

            {/* Mobile Hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-stone-700 hover:text-[#0B5145] rounded-md focus:outline-none cursor-pointer"
              aria-label="القائمة الرئيسية"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#F5F3EE] border-b border-stone-200 px-4 pt-2 pb-6 space-y-2">
          <div className="grid grid-cols-2 gap-1 pt-2 border-t border-stone-200">
            {primaryNavItems.concat(secondaryNavItems).map((item) => (
              <button
                key={item.view}
                onClick={() => {
                  onNavigate(item.view);
                  setMobileMenuOpen(false);
                }}
                className={`text-right px-3 py-2 rounded-md text-sm cursor-pointer ${
                  currentView === item.view 
                    ? 'bg-[#0B5145] text-white font-bold' 
                    : 'text-stone-800 hover:bg-stone-200/60'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-200 flex items-center justify-between">
            <button
              onClick={() => {
                onNavigate('admin_dashboard');
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-xs font-semibold text-[#0B5145] bg-[#0B5145]/10 px-3 py-1.5 rounded-lg"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>لوحة الإدارة والتحقيق</span>
            </button>
            <div className="flex items-center gap-2 text-xs">
              <button 
                onClick={() => { onLanguageChange('ar'); setMobileMenuOpen(false); }}
                className={`px-2 py-1 rounded ${language === 'ar' ? 'font-bold bg-white text-[#0B5145]' : 'text-stone-600'}`}
              >
                عربي
              </button>
              <button 
                onClick={() => { onLanguageChange('fr'); setMobileMenuOpen(false); }}
                className={`px-2 py-1 rounded ${language === 'fr' ? 'font-bold bg-white text-[#0B5145]' : 'text-stone-600'}`}
              >
                FR
              </button>
              <button 
                onClick={() => { onLanguageChange('en'); setMobileMenuOpen(false); }}
                className={`px-2 py-1 rounded ${language === 'en' ? 'font-bold bg-white text-[#0B5145]' : 'text-stone-600'}`}
              >
                EN
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
