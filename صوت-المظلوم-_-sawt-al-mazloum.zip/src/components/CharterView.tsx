import React from 'react';
import { CHARTER_PRINCIPLES } from '../data/mockData';
import { ShieldCheck, Scale, Heart, Sparkles } from 'lucide-react';

export const CharterView: React.FC = () => {
  return (
    <div className="bg-[#F5F3EE] min-h-screen py-12 sm:py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0B5145]/10 text-[#0B5145] text-xs font-bold mb-3">
            <Scale className="w-4 h-4" />
            <span>المرجع الأخلاقي والمهني</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-bold text-[#17201D] font-serif-ar mb-4">
            ميثاق صوت المظلوم
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            ست قواعد صارمة لا نساوم عليها؛ تحكم كل كلمة نكتبها وكل وثيقة ننشرها وكل حملة نطلقها، ليبقى العمل خالصاً للعدل وحفظ الكرامة.
          </p>
        </div>

        {/* 6 Large Ethical Pillars */}
        <div className="space-y-6 mb-16">
          {CHARTER_PRINCIPLES.map((principle) => (
            <div
              key={principle.number}
              className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm hover:shadow-md transition-shadow grid grid-cols-1 md:grid-cols-12 gap-6 items-center"
            >
              <div className="md:col-span-2 text-center md:text-right">
                <span className="text-3xl sm:text-5xl font-mono font-bold text-[#0B5145]">
                  {principle.number}
                </span>
              </div>

              <div className="md:col-span-10 text-right">
                <h3 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar mb-2">
                  {principle.title}
                </h3>
                <p className="text-stone-700 text-sm sm:text-base leading-relaxed font-normal">
                  {principle.text}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Closing Affirmation */}
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-stone-200 text-center">
          <h4 className="text-xl font-bold text-[#17201D] font-serif-ar mb-3">
            التزام علني وتعهد أخلاقي
          </h4>
          <p className="text-stone-600 text-xs sm:text-sm max-w-xl mx-auto leading-relaxed mb-6">
            يعتبر هذا الميثاق عقداً ملزماً بين فريق المنصة وجمهورها. نرحب بأي ملاحظة أو تصويب من الباحثين، المحامين، أو عموم القراء عبر لجنة التدقيق الأخلاقي المستقلة.
          </p>
          <div className="inline-flex items-center gap-2 text-xs font-mono text-[#0B5145] font-bold">
            <ShieldCheck className="w-4 h-4" />
            <span>معتمد ومحدث لسنة 2026</span>
          </div>
        </div>

      </div>
    </div>
  );
};
