import React, { useState } from 'react';
import { CaseItem } from '../types';
import { 
  ArrowLeft, 
  ChevronRight, 
  ChevronLeft, 
  FileText, 
  Layers, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Calendar,
  Share2
} from 'lucide-react';

interface FeaturedCaseSpotlightProps {
  cases: CaseItem[];
  onOpenCase: (caseId: string) => void;
  onShareCase: (caseItem: CaseItem) => void;
}

export const FeaturedCaseSpotlight: React.FC<FeaturedCaseSpotlightProps> = ({
  cases,
  onOpenCase,
  onShareCase,
}) => {
  // We can cycle between high priority cases
  const spotlightCases = cases.filter(c => c.status === 'urgent' || c.status === 'verified').slice(0, 3);
  const [currentIndex, setCurrentIndex] = useState(0);

  if (spotlightCases.length === 0) return null;
  const currentCase = spotlightCases[currentIndex] || spotlightCases[0];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % spotlightCases.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + spotlightCases.length) % spotlightCases.length);
  };

  return (
    <section className="py-12 sm:py-16 bg-[#F5F3EE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <span className="text-xs font-bold tracking-wider uppercase text-[#0B5145] font-mono block">
              ملف تحقيقي خاص
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#17201D] font-serif-ar mt-1">
              القضية البارزة
            </h2>
          </div>

          {/* Slider controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              className="w-9 h-9 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 flex items-center justify-center text-stone-700 transition-colors cursor-pointer"
              title="القضية السابقة"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <span className="text-xs font-mono text-stone-500 px-1">
              {currentIndex + 1} / {spotlightCases.length}
            </span>
            <button
              onClick={handleNext}
              className="w-9 h-9 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 flex items-center justify-center text-stone-700 transition-colors cursor-pointer"
              title="القضية التالية"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Commanding Spotlight Card */}
        <div className="bg-white rounded-3xl border border-stone-200/80 shadow-md overflow-hidden grid grid-cols-1 lg:grid-cols-12 transition-all">
          
          {/* Visual Column */}
          <div className="relative lg:col-span-6 bg-stone-900 min-h-[340px] sm:min-h-[420px] overflow-hidden group">
            <img
              src={currentCase.image}
              alt={currentCase.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center group-hover:scale-102 transition-transform duration-700"
            />
            
            {/* Subtle Gradient Overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
            
            {/* Badge on Photo */}
            <div className="absolute top-4 right-4 flex items-center gap-2">
              {currentCase.status === 'urgent' && (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-600/90 text-white backdrop-blur-sm shadow flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                  عاجلة
                </span>
              )}
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#0B5145]/90 text-white backdrop-blur-sm shadow flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" />
                موثقة
              </span>
            </div>

            {/* Bottom Meta on Image */}
            <div className="absolute bottom-4 right-4 left-4 text-white">
              <span className="text-xs font-mono text-stone-300 block mb-0.5">
                {currentCase.id}
              </span>
              <p className="text-xs text-stone-200 line-clamp-1">
                {currentCase.country} · {currentCase.city}
              </p>
            </div>
          </div>

          {/* Editorial Content Column */}
          <div className="lg:col-span-6 p-6 sm:p-8 lg:p-10 flex flex-col justify-between text-right">
            
            <div>
              {/* Case Code & Days Kicker */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-stone-100">
                <span className="text-xs font-mono font-bold text-[#0B5145] tracking-wider">
                  {currentCase.id}
                </span>
                <div className="text-xs text-stone-500 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-stone-400" />
                  <span>آخر تحديث: {currentCase.lastUpdated}</span>
                </div>
              </div>

              {/* Title & Name */}
              <h3 className="text-2xl sm:text-3xl font-bold text-[#17201D] font-serif-ar mt-4 mb-2">
                {currentCase.name}
              </h3>

              {/* Detention Days Counter */}
              {currentCase.detentionDays && (
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-xs font-medium text-stone-600">
                    الدولة: <strong className="text-stone-900">{currentCase.country}</strong>
                  </span>
                  <span className="text-stone-300">·</span>
                  <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded-md">
                    محتجز منذ {currentCase.detentionDays} يوماً
                  </span>
                </div>
              )}

              {/* Summary Description */}
              <p className="text-stone-700 text-sm sm:text-base leading-relaxed mb-6 font-normal">
                {currentCase.summary}
              </p>

              {/* Proof Breakdown */}
              <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200/60 mb-6">
                <div className="grid grid-cols-3 gap-2 text-center divide-x divide-x-reverse divide-stone-200">
                  <div>
                    <div className="text-lg sm:text-xl font-bold text-[#17201D] tabular-nums font-serif-ar">
                      {currentCase.stats.sourcesCount}
                    </div>
                    <div className="text-[11px] text-stone-500 font-medium">مصادر موثقة</div>
                  </div>
                  <div>
                    <div className="text-lg sm:text-xl font-bold text-[#17201D] tabular-nums font-serif-ar">
                      {currentCase.stats.documentsCount}
                    </div>
                    <div className="text-[11px] text-stone-500 font-medium">وثائق رسمية</div>
                  </div>
                  <div>
                    <div className="text-lg sm:text-xl font-bold text-[#17201D] tabular-nums font-serif-ar">
                      {currentCase.stats.updatesCount}
                    </div>
                    <div className="text-[11px] text-stone-500 font-medium">تحديثاً دورياً</div>
                  </div>
                </div>
              </div>

              {/* Urgent Callout if any */}
              {currentCase.urgentReason && (
                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-50/80 border border-amber-200/70 text-xs text-amber-900 mb-6">
                  <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong>سبب المتابعة العاجلة:</strong> {currentCase.urgentReason}
                  </p>
                </div>
              )}
            </div>

            {/* Action Bar */}
            <div className="flex items-center gap-3 pt-4 border-t border-stone-100">
              <button
                onClick={() => onOpenCase(currentCase.id)}
                className="flex-1 bg-[#0B5145] hover:bg-[#083B32] text-white font-semibold text-sm px-6 py-3.5 rounded-xl shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>فتح ملف القضية</span>
                <ArrowLeft className="w-4 h-4" />
              </button>

              <button
                onClick={() => onShareCase(currentCase)}
                className="p-3.5 rounded-xl border border-stone-200 text-stone-600 hover:text-[#0B5145] hover:bg-stone-50 transition-colors cursor-pointer"
                title="مشاركة القضية"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
