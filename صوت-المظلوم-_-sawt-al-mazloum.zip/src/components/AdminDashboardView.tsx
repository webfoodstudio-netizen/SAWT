import React, { useState, useMemo } from 'react';
import { CaseItem, AdminSection, VerificationStatus, VerificationStage } from '../types';
import { AdminSidebar } from './admin/AdminSidebar';
import { AdminOverviewView } from './admin/AdminOverviewView';
import { AdminCasesTableView } from './admin/AdminCasesTableView';
import { AdminCaseDetailWorkspace } from './admin/AdminCaseDetailWorkspace';
import { AdminCountriesManagementView } from './admin/AdminCountriesManagementView';
import { AdminSubmissionsView } from './admin/AdminSubmissionsView';
import { AdminTeamView } from './admin/AdminTeamView';
import { AdminNewCaseModal } from './admin/AdminNewCaseModal';
import { VisualDocumentationSection } from './admin/VisualDocumentationSection';
import { AdminSourcesView } from './admin/AdminSourcesView';
import { AdminTimelineView } from './admin/AdminTimelineView';
import { AdminCampaignsManagementView } from './admin/AdminCampaignsManagementView';
import { AdminReportsView } from './admin/AdminReportsView';
import { AdminMediaManagementView } from './admin/AdminMediaManagementView';
import { AdminSettingsView } from './admin/AdminSettingsView';
import { INITIAL_COUNTRIES, INITIAL_ACTIVITY_LOGS, INBOUND_SUBMISSIONS } from '../data/mockData';
import { 
  Bell, 
  Search, 
  ExternalLink, 
  ShieldCheck, 
  SlidersHorizontal,
  FileText,
  Layers,
  History,
  Settings,
  Lock,
  Eye,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  ChevronLeft,
  Activity,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Inbox,
  GitCompare,
  UserCheck,
  Send,
  FolderOpen,
  RefreshCw,
  AlertOctagon,
  CheckSquare,
  Square,
  Filter,
  Users,
  MapPin,
  Hash,
  Scale,
  Info
} from 'lucide-react';

export interface VisualVerificationStage {
  id: number;
  key: VerificationStage;
  name: string;
  subtitle: string;
  desc: string;
  protocol: string;
  checklist: string[];
  avgProcessingTime: string;
  assignedLead: string;
  legalStandard: string;
  accuracyIndicator: string;
  color: string;
}

export const VISUAL_VERIFICATION_STAGES: VisualVerificationStage[] = [
  {
    id: 1,
    key: 'received',
    name: 'استلام',
    subtitle: 'استقبال وتشفير البلاغات',
    desc: 'استقبال البلاغات عبر القنوات الآمنة، تشفير الهويات، وإصدار المعرف الرقمي الموحد وتثبيت التوقيت.',
    protocol: 'توليد المعرف الرقمي الموحد وتثبيت التوقيت الزمني المشفر ومنع تكرار البلاغات.',
    checklist: [
      'تشفير بيانات المبلّغ والمحتجز بخوارزمية AES-256 لحماية المصادر',
      'توليد المعرف الرقمي الموحد وتثبيت التوقيت الزمني العالمي (UTC)',
      'فحص السجلات السابقة لمنع ازدواجية أو تكرار البلاغات الميدانية'
    ],
    avgProcessingTime: '12 - 24 ساعة',
    assignedLead: 'وحدة الاستقبال والتشفير الآمن',
    legalStandard: 'بروتوكول بيركلي للأدلة الرقمية المفتوحة المصدر',
    accuracyIndicator: '99.8% موثوقية التشفير',
    color: 'emerald',
  },
  {
    id: 2,
    key: 'initial_review',
    name: 'مراجعة أولية',
    subtitle: 'فحص الاختصاص والولاية',
    desc: 'التحقق من وقوع الانتهاك ضمن النطاق العربي وتوافقه مع معايير المنصة ونبذ خطابات العنف.',
    protocol: 'التحقق من الاختصاص الجغرافي واستبعاد خطابات الكراهية والتحريض وتعيين المحقق.',
    checklist: [
      'التحقق من الاختصاص الجغرافي والقانوني بالمنطقة العربية',
      'استبعاد خطابات الكراهية أو الدعوات الانتقامية العنيفة',
      'تقييم مبدئي لسلامة المعتقل وذويه وتصنيف مستوى الخطر الحقوقي'
    ],
    avgProcessingTime: '24 - 48 ساعة',
    assignedLead: 'فريق التدقيق والفرز الأولي',
    legalStandard: 'المعايير الدولية للاحتجاز التعسفي (WGAD)',
    accuracyIndicator: '98.5% سلامة الاختصاص',
    color: 'teal',
  },
  {
    id: 3,
    key: 'evidence_collection',
    name: 'أدلة',
    subtitle: 'استيفاء الوثائق والأسانيد',
    desc: 'جمع المستندات القانونية الرسمية، محاضر النيابة، أوامر التوقيف، والتقارير الطبية وشهادات الشهود.',
    protocol: 'أرشفة النسخ الرسمية للأوامر القضائية في خزانة الأدلة المشفرة وتصنيف السرية.',
    checklist: [
      'تأكيد وجود أصل رسمي أو نسخة مصدقة من أمر الضبط أو قرار الحبس',
      'أرشفة التقارير الطبية وشهادات الأسرة في خزانة الأدلة المشفرة',
      'تصنيف درجات سرية الوثائق (عام / داخلي / سري للغاية)'
    ],
    avgProcessingTime: '3 - 5 أيام',
    assignedLead: 'وحدة التوثيق الميداني وخزانة الأدلة',
    legalStandard: 'سلسلة الحيازة القضائية (Chain of Custody)',
    accuracyIndicator: '96.9% اكتمال الأسانيد',
    color: 'amber',
  },
  {
    id: 4,
    key: 'cross_referencing',
    name: 'مقارنة',
    subtitle: 'مقاطعة المصادر وفك التناقضات',
    desc: 'مطابقة التواريخ الجنائية وروايات الشهود المستقلين وكشف أي ثغرات أو تعارضات بين المصادر.',
    protocol: 'مقاطعة الرواية مع مصدرين مستقلين على الأقل وفحص التناقضات التاريخية.',
    checklist: [
      'مقاطعة رواية الأسرة مع مصدرين حقوقيين مستقلين على الأقل',
      'التحقق من البيانات الجغرافية وسجلات الحضور ومحاضر الجلسات',
      'رصد أي تناقضات تاريخية وحسمها في مذكرة الفحص القانوني'
    ],
    avgProcessingTime: '2 - 3 أيام',
    assignedLead: 'محلل التناقضات ومقاطعة المصادر',
    legalStandard: 'قاعدة المصادر الثلاثية المستقلة',
    accuracyIndicator: '97.4% تطابق المصادر',
    color: 'orange',
  },
  {
    id: 5,
    key: 'verification',
    name: 'تحقق',
    subtitle: 'التثبت الجنائي والرقمي',
    desc: 'الفحص المجهري للأختام والتواقيع، مطابقة البصمة الرقمية للوسائط وسجلات المحاكم المعتمدة.',
    protocol: 'الفحص الجنائي الرقمي للبيانات الوصفية (Metadata) وتوثيق بصمة SHA-256 للأدلة.',
    checklist: [
      'الفحص الجنائي الرقمي للصور والوثائق وبياناتها الوصفية (Metadata)',
      'مطابقة أرقام القضايا الرسمية في لوائح النيابة والمحاكم',
      'توثيق البصمة الرقمية المشفرة (SHA-256) لمنع التلاعب بالأدلة'
    ],
    avgProcessingTime: '24 - 48 ساعة',
    assignedLead: 'خبير التحقيق الجنائي الرقمي',
    legalStandard: 'معايير الفحص الرقمي الجنائي ISO/IEC 27037',
    accuracyIndicator: '99.2% سلامة البصمة الرقمية',
    color: 'blue',
  },
  {
    id: 6,
    key: 'human_review',
    name: 'مراجعة بشرية',
    subtitle: 'إجازة الهيئة الاستشارية',
    desc: 'مراجعة تحريرية وقانونية وأخلاقية صارمة لتقييم سلامة المعتقل وأسرته وتوقيع المستشار القانوني.',
    protocol: 'تقييم أمني لحماية أسرة المعتقل وتوقيع المشرف القانوني ورئيس التحرير على إذن النشر.',
    checklist: [
      'تقييم أمني شامل لضمان عدم تعريض المعتقل أو أسرته لأي خطر انتقامي',
      'إجازة الصياغة التحريرية والتزام الحياد والنزاهة الحقوقية الصارمة',
      'توقيع المشرف القانوني ورئيس التحرير على إذن النشر الرسمي'
    ],
    avgProcessingTime: '24 ساعة',
    assignedLead: 'المستشار القانوني الأول ورئيس التحرير',
    legalStandard: 'ميثاق الشرف الأخلاقي للعمل الحقوقي المستقل',
    accuracyIndicator: '100% إجازة بشرية موثقة',
    color: 'purple',
  },
  {
    id: 7,
    key: 'published',
    name: 'نشر',
    subtitle: 'إطلاق الملف وتفعيل الرصد',
    desc: 'إتاحة الملف العام الموثق، إصدار رمز QR، وتفعيل الرصد الميداني وإخطار شبكة المحامين.',
    protocol: 'توليد الملف الحقوقي الموثق وبصمة QR المشفرة وإدراج القضية في الأرشيف المفتوح.',
    checklist: [
      'توليد الملف الحقوقي العام الموثق بصيغة الويب والطباعة المرجعية',
      'تضمين باركود QR المشفر للتحقق الفوري من مصداقية وصحة الملف',
      'إدراج القضية في الأرشيف المفتوح وإخطار شبكة المحامين والشركاء'
    ],
    avgProcessingTime: 'فوري عند الاعتماد',
    assignedLead: 'غرفة العمليات المركزية والنشر العام',
    legalStandard: 'الوصول المفتوح للمعلومات والشفافية الحقوقية',
    accuracyIndicator: '100% ملفات معتمدة ومنشورة',
    color: 'emerald',
  },
];

export const getCaseVisualStageKey = (c: CaseItem): VerificationStage => {
  if (c.verificationStage) return c.verificationStage;
  if (c.status === 'verified') return 'published';
  if (c.status === 'urgent') return 'human_review';
  if (c.status === 'needs_evidence') return 'evidence_collection';
  if (c.contradictions && c.contradictions.length > 0) return 'cross_referencing';
  return 'received';
};

interface AdminDashboardViewProps {
  cases: CaseItem[];
  onOpenCase: (caseId: string) => void;
  onUpdateCase: (updatedCase: CaseItem) => void;
  onExitToPublic?: () => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  cases,
  onOpenCase,
  onUpdateCase,
  onExitToPublic,
}) => {
  const [currentSection, setCurrentSection] = useState<AdminSection>('dashboard');
  const [selectedCaseId, setSelectedCaseId] = useState<string>(cases[0]?.id || 'CASE-EGY-0042');
  const [showNewCaseModal, setShowNewCaseModal] = useState(false);
  const [countriesList, setCountriesList] = useState(INITIAL_COUNTRIES);
  const [filterPreset, setFilterPreset] = useState<string>('all');

  // Counts for sidebar badges
  const sidebarCounts = {
    newCases: 24,
    investigating: cases.filter(c => c.status === 'investigating').length + 12,
    verified: cases.filter(c => c.status === 'verified').length + 80,
    urgent: cases.filter(c => c.status === 'urgent').length + 3,
    submissions: INBOUND_SUBMISSIONS.length,
  };

  const handleOpenCaseDetail = (caseId: string) => {
    setSelectedCaseId(caseId);
    setCurrentSection('case_detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectSection = (section: AdminSection) => {
    if (section === 'new_cases') {
      setFilterPreset('investigating');
      setCurrentSection('cases');
    } else if (section === 'investigating') {
      setFilterPreset('investigating');
      setCurrentSection('cases');
    } else if (section === 'verified') {
      setFilterPreset('verified');
      setCurrentSection('cases');
    } else if (section === 'urgent') {
      setFilterPreset('urgent');
      setCurrentSection('cases');
    } else {
      setFilterPreset('all');
      setCurrentSection(section);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveNewCase = (newCase: CaseItem) => {
    onUpdateCase(newCase);
    setSelectedCaseId(newCase.id);
    setCurrentSection('case_detail');
  };

  const activeCase = cases.find(c => c.id === selectedCaseId) || cases[0];

  // Interactive Visual Documentation Progress Bar State & Statistics
  const [activeVisualStageId, setActiveVisualStageId] = useState<number>(1);
  const [visualNoticeMsg, setVisualNoticeMsg] = useState<string | null>(null);

  // Dynamic statistics calculated directly from the passed cases array
  const visualStagesWithStats = useMemo(() => {
    return VISUAL_VERIFICATION_STAGES.map((st) => {
      const stageCases = cases.filter((c) => getCaseVisualStageKey(c) === st.key);
      const count = stageCases.length;
      const docsCount = stageCases.reduce((acc, c) => acc + (c.stats?.documentsCount || c.evidence?.length || 0), 0);
      const urgentCount = stageCases.filter((c) => c.status === 'urgent').length;
      const percentage = cases.length > 0 ? Math.round((count / cases.length) * 100) : 0;

      return {
        ...st,
        cases: stageCases,
        count,
        docsCount,
        urgentCount,
        percentage,
      };
    });
  }, [cases]);

  const activeVisualStage = useMemo(() => {
    return visualStagesWithStats.find((s) => s.id === activeVisualStageId) || visualStagesWithStats[0];
  }, [visualStagesWithStats, activeVisualStageId]);

  const totalCasesInArray = cases.length;
  const totalDocsCount = cases.reduce((acc, c) => acc + (c.stats?.documentsCount || c.evidence?.length || 0), 0);
  const totalUrgentCount = cases.filter((c) => c.status === 'urgent').length;
  const verifiedCount = cases.filter((c) => c.status === 'verified' || c.verificationStage === 'published').length;
  const overallCompletionPercent = totalCasesInArray > 0 ? Math.round((verifiedCount / totalCasesInArray) * 100) : 0;

  const handlePromoteCaseInPipeline = (caseItem: CaseItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const currentKey = getCaseVisualStageKey(caseItem);
    const currIdx = VISUAL_VERIFICATION_STAGES.findIndex((s) => s.key === currentKey);
    if (currIdx < VISUAL_VERIFICATION_STAGES.length - 1) {
      const nextStage = VISUAL_VERIFICATION_STAGES[currIdx + 1];
      const updated: CaseItem = {
        ...caseItem,
        verificationStage: nextStage.key,
        status: nextStage.key === 'published' ? 'verified' : caseItem.status,
        verificationProgress: Math.min(100, Math.round(((currIdx + 2) / 7) * 100)),
        lastUpdated: 'الآن (محدّث تلقائياً)',
      };
      onUpdateCase(updated);
      setVisualNoticeMsg(`تمت ترقية القضية [${caseItem.name}] إلى مرحلة «${nextStage.name}» بنجاح.`);
      setTimeout(() => setVisualNoticeMsg(null), 3500);
    }
  };

  const handleNextVisualStage = () => {
    if (activeVisualStageId < 7) {
      setActiveVisualStageId((prev) => prev + 1);
    }
  };

  const handlePrevVisualStage = () => {
    if (activeVisualStageId > 1) {
      setActiveVisualStageId((prev) => prev - 1);
    }
  };

  const [checkedProtocols, setCheckedProtocols] = useState<Record<string, boolean>>({});
  const [stageUrgentOnly, setStageUrgentOnly] = useState<boolean>(false);

  const handleToggleProtocol = (stageId: number, idx: number) => {
    const key = `${stageId}-${idx}`;
    setCheckedProtocols(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Country breakdown for active stage
  const activeStageCountries = useMemo(() => {
    const map: Record<string, number> = {};
    activeVisualStage.cases.forEach(c => {
      map[c.country] = (map[c.country] || 0) + 1;
    });
    return Object.entries(map).map(([country, count]) => ({ country, count }));
  }, [activeVisualStage]);

  // Filtered cases for the stage
  const displayedStageCases = useMemo(() => {
    if (stageUrgentOnly) {
      return activeVisualStage.cases.filter(c => c.status === 'urgent');
    }
    return activeVisualStage.cases;
  }, [activeVisualStage, stageUrgentOnly]);

  return (
    <div className="min-h-screen bg-[#F5F3EE] flex text-[#17201D] font-sans antialiased selection:bg-[#0B5145]/20 selection:text-[#0B5145]">
      
      {/* 1. Fixed Sidebar on the Right (RTL) */}
      <AdminSidebar
        currentSection={currentSection}
        onSelectSection={handleSelectSection}
        onExitToPublic={onExitToPublic || (() => window.location.hash = '#/')}
        counts={sidebarCounts}
      />

      {/* 2. Main Content Canvas */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        
        {/* Top Operations Command Bar */}
        <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-stone-200/80 px-6 sm:px-8 py-3.5 flex items-center justify-between">
          
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold text-stone-400">
              غرفة العمليات المركزية
            </span>
            <span className="text-stone-300">/</span>
            <span className="text-xs font-bold text-[#0B5145]">
              {currentSection === 'dashboard' && 'لوحة التحكم الرئيسية'}
              {currentSection === 'visual_documentation' && 'قسم «التوثيق البصري» ومسار التحقق السُباعي'}
              {currentSection === 'cases' && 'أرشيف جميع القضايا'}
              {currentSection === 'case_detail' && `تفاصيل الملف: ${selectedCaseId}`}
              {currentSection === 'countries' && 'إدارة أرشيف الدول'}
              {currentSection === 'submissions' && 'البلاغات الجديدة'}
              {currentSection === 'team' && 'فريق التحقيق والصلاحيات'}
              {currentSection === 'logs' && 'سجل التعديلات الميداني'}
              {currentSection === 'settings' && 'إعدادات المنصة والأمان'}
              {currentSection === 'evidence' && 'مستودع الأدلة والوثائق'}
              {currentSection === 'sources' && 'شبكة المصادر والشهود'}
              {currentSection === 'timeline' && 'الخط الزمني الشامل'}
              {currentSection === 'campaigns' && 'إدارة الحملات'}
              {currentSection === 'reports' && 'التقارير والمؤشرات'}
              {currentSection === 'media' && 'المركز الإعلامي'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentSection('visual_documentation')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer flex items-center gap-1.5 ${
                currentSection === 'visual_documentation'
                  ? 'bg-[#0B5145] text-white border-[#0B5145] shadow-sm'
                  : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>التوثيق البصري</span>
            </button>

            <button
              onClick={() => setCurrentSection('settings')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer flex items-center gap-1.5 ${
                currentSection === 'settings'
                  ? 'bg-[#0B5145] text-white border-[#0B5145] shadow-sm'
                  : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>إدارة الموقع</span>
            </button>

            <button
              onClick={() => setShowNewCaseModal(true)}
              className="px-3 py-1.5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-bold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              + إضافة قضية
            </button>

            <button
              onClick={onExitToPublic || (() => window.location.hash = '#/')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-300 text-stone-700 hover:bg-stone-50 text-xs font-semibold cursor-pointer transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#0B5145]" />
              <span>الموقع العام للجمهور</span>
            </button>
          </div>

        </header>

        {/* Dynamic View Injection */}
        <main className="flex-1 px-6 sm:px-8 pt-8">
          
          {/* قسم «التوثيق البصري» كشريط تقدم تفاعلي يعرض المراحل السبع مع إحصائيات لكل مرحلة مربوط بحالة القضايا */}
          {(currentSection === 'dashboard' || currentSection === 'visual_documentation') && (
            <section className="bg-white rounded-3xl border border-stone-200/90 shadow-sm p-6 sm:p-8 text-right mb-8">
              
              {/* Header and Sync Indicators */}
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-stone-100">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#DCEBE4] text-[#0B5145] text-xs font-bold font-mono">
                      <span className="w-2 h-2 rounded-full bg-[#0B5145] animate-ping" />
                      <span className="w-2 h-2 rounded-full bg-[#0B5145] -mr-3.5" />
                      <span>قسم «التوثيق البصري»</span>
                    </span>

                    <span className="px-2.5 py-0.5 rounded-md bg-stone-100 text-stone-700 text-xs font-mono font-medium">
                      مربوط مباشرة بمصفوفة القضايا ({totalCasesInArray} قضية)
                    </span>

                    <span className="text-[11px] text-stone-400 font-mono">
                      مسار التحقق السُباعي الميداني
                    </span>
                  </div>

                  <h2 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar pt-1 flex items-center gap-2">
                    <Eye className="w-6 h-6 text-[#0B5145]" />
                    <span>شريط تقدم تفاعلي: المراحل السبع للتوثيق والتحقق</span>
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-3xl">
                    شريط تقدم تفاعلي يعرض المراحل السبع (استلام، مراجعة أولية، أدلة، مقارنة، تحقق، مراجعة بشرية، نشر) مع إحصائيات حية لكل مرحلة مربوطة بحالة القضايا في المصفوفة الممررة.
                  </p>
                </div>

                {/* Operations & Step Nav */}
                <div className="flex items-center gap-2 self-start lg:self-center shrink-0">
                  <button
                    onClick={handlePrevVisualStage}
                    disabled={activeVisualStageId === 1}
                    className="px-3 py-1.5 rounded-xl border border-stone-200 text-stone-700 hover:bg-stone-50 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>المرحلة السابقة</span>
                  </button>

                  <button
                    onClick={handleNextVisualStage}
                    disabled={activeVisualStageId === 7}
                    className="px-3 py-1.5 bg-[#0B5145] hover:bg-[#083B32] text-white disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold rounded-xl flex items-center gap-1 cursor-pointer transition-colors shadow-sm"
                  >
                    <span>المرحلة التالية</span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Toast message if action performed */}
              {visualNoticeMsg && (
                <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 text-[#0B5145] text-xs font-semibold rounded-xl flex items-center gap-2 animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4 text-[#0B5145] shrink-0" />
                  <span>{visualNoticeMsg}</span>
                </div>
              )}

              {/* Dynamic Overall Summary Strip */}
              <div className="mt-5 pt-2 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs mb-6">
                <div className="bg-stone-50 border border-stone-200/80 p-3 rounded-xl">
                  <span className="text-[11px] text-stone-500 block font-sans">إجمالي القضايا النشطة</span>
                  <span className="text-lg font-bold font-serif-ar text-[#17201D] tabular-nums">
                    {totalCasesInArray} قضية
                  </span>
                </div>

                <div className="bg-stone-50 border border-stone-200/80 p-3 rounded-xl">
                  <span className="text-[11px] text-stone-500 block font-sans">الوثائق والأدلة المسجلة</span>
                  <span className="text-lg font-bold font-serif-ar text-[#0B5145] tabular-nums">
                    {totalDocsCount} وثيقة رسمية
                  </span>
                </div>

                <div className="bg-stone-50 border border-stone-200/80 p-3 rounded-xl">
                  <span className="text-[11px] text-stone-500 block font-sans">القضايا العاجلة والحرجة</span>
                  <span className="text-lg font-bold font-serif-ar text-rose-700 tabular-nums">
                    {totalUrgentCount} حالات عاجلة
                  </span>
                </div>

                <div className="bg-stone-50 border border-stone-200/80 p-3 rounded-xl">
                  <span className="text-[11px] text-stone-500 block font-sans">نسبة الإنجاز والاعتماد</span>
                  <span className="text-lg font-bold font-serif-ar text-[#0B5145] tabular-nums">
                    {overallCompletionPercent}% معتمدة
                  </span>
                </div>
              </div>

              {/* The Interactive Progress Rail Track */}
              <div className="relative mb-6 pt-2">
                <div className="flex items-center justify-between mb-2 text-xs font-semibold text-stone-600">
                  <div className="flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-[#0B5145]" />
                    <span>شريط التقدم التفاعلي (انقر على أي مرحلة للاطلاع على إحصائياتها وقضاياها):</span>
                  </div>
                  <span className="font-mono text-[#0B5145] font-bold">
                    المرحلة 0{activeVisualStageId} من 07: «{activeVisualStage.name}»
                  </span>
                </div>

                <div className="h-3 w-full bg-stone-100 rounded-full overflow-hidden relative border border-stone-200">
                  <div 
                    className="h-full bg-gradient-to-r from-emerald-500 via-teal-500 to-[#0B5145] transition-all duration-500 ease-out rounded-full"
                    style={{ width: `${(activeVisualStageId / 7) * 100}%` }}
                  />
                </div>
              </div>

              {/* The 7 Interactive Stage Cards / Nodes */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 sm:gap-3 mb-6">
                {visualStagesWithStats.map((stage) => {
                  const isSelected = stage.id === activeVisualStageId;
                  const isCompleted = stage.id < activeVisualStageId;

                  return (
                    <button
                      key={stage.id}
                      onClick={() => setActiveVisualStageId(stage.id)}
                      className={`relative p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected 
                          ? 'bg-[#0B5145] text-white border-[#0B5145] shadow-md ring-2 ring-[#0B5145]/30 -translate-y-0.5'
                          : isCompleted
                          ? 'bg-white border-emerald-200 text-stone-800 hover:border-emerald-400 hover:shadow-xs'
                          : 'bg-stone-50/80 border-stone-200 text-stone-700 hover:border-stone-300 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          isSelected 
                            ? 'bg-emerald-950/40 text-emerald-200' 
                            : isCompleted
                            ? 'bg-emerald-100 text-[#0B5145]'
                            : 'bg-stone-100 text-stone-500'
                        }`}>
                          0{stage.id}
                        </span>

                        {isCompleted && !isSelected && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        )}
                        {isSelected && (
                          <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
                        )}
                      </div>

                      <div className="mb-2">
                        <div className={`text-sm font-bold font-serif-ar leading-tight ${isSelected ? 'text-white' : 'text-stone-900'}`}>
                          {stage.name}
                        </div>
                        <div className={`text-[10px] leading-tight line-clamp-1 mt-0.5 ${isSelected ? 'text-emerald-100' : 'text-stone-500'}`}>
                          {stage.subtitle}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-stone-100/30 flex items-baseline justify-between mt-auto">
                        <div className={`text-lg font-bold font-serif-ar tabular-nums ${isSelected ? 'text-white' : 'text-[#0B5145]'}`}>
                          {stage.count}
                        </div>
                        <span className={`text-[10px] font-mono ${isSelected ? 'text-emerald-200' : 'text-stone-400'}`}>
                          {stage.count === 1 ? 'قضية' : 'قضايا'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Stage Deep-Dive Inspection Box */}
              <div className="p-4 sm:p-6 rounded-2xl bg-stone-50 border border-stone-200/90 text-right space-y-5">
                
                {/* Stage Header & KPI Tags */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-stone-200">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[11px] font-bold font-mono bg-[#DCEBE4] text-[#0B5145]">
                        المرحلة 0{activeVisualStage.id} من 07
                      </span>
                      <h3 className="text-lg font-bold text-stone-900 font-serif-ar">
                        {activeVisualStage.name} — {activeVisualStage.subtitle}
                      </h3>
                    </div>
                    <p className="text-xs text-stone-600 mt-1 max-w-2xl leading-relaxed">
                      {activeVisualStage.desc}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                    <span className="px-3 py-1.5 rounded-xl bg-white border border-stone-200 text-stone-700 shadow-2xs">
                      القضايا: <strong>{activeVisualStage.count}</strong>
                    </span>
                    <span className="px-3 py-1.5 rounded-xl bg-white border border-stone-200 text-stone-700 shadow-2xs">
                      التمثيل: <strong>{activeVisualStage.percentage}%</strong>
                    </span>
                    <span className="px-3 py-1.5 rounded-xl bg-white border border-stone-200 text-[#0B5145] font-bold shadow-2xs">
                      الوثائق: <strong>{activeVisualStage.docsCount}</strong>
                    </span>
                    {activeVisualStage.urgentCount > 0 && (
                      <span className="px-3 py-1.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 font-bold shadow-2xs">
                        عاجلة: <strong>{activeVisualStage.urgentCount}</strong>
                      </span>
                    )}
                  </div>
                </div>

                {/* Investigative Metadata Grid (البيانات الميدانية والقانونية) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-xl border border-stone-200/80">
                    <span className="text-[10px] text-stone-400 font-sans block mb-0.5">وحدة التحقيق المسؤولة</span>
                    <div className="font-bold text-stone-800 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-[#0B5145]" />
                      <span>{activeVisualStage.assignedLead}</span>
                    </div>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-stone-200/80">
                    <span className="text-[10px] text-stone-400 font-sans block mb-0.5">المعيار والبروتوكول الدولي</span>
                    <div className="font-bold text-stone-800 flex items-center gap-1.5">
                      <Scale className="w-3.5 h-3.5 text-[#0B5145]" />
                      <span className="truncate">{activeVisualStage.legalStandard}</span>
                    </div>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-stone-200/80">
                    <span className="text-[10px] text-stone-400 font-sans block mb-0.5">متوسط زمن المعالجة الميداني</span>
                    <div className="font-bold text-stone-800 flex items-center gap-1.5">
                      <Activity className="w-3.5 h-3.5 text-amber-600" />
                      <span>{activeVisualStage.avgProcessingTime}</span>
                    </div>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-stone-200/80">
                    <span className="text-[10px] text-stone-400 font-sans block mb-0.5">مؤشر الدقة والموثوقية الرقمية</span>
                    <div className="font-bold text-[#0B5145] flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#0B5145]" />
                      <span>{activeVisualStage.accuracyIndicator}</span>
                    </div>
                  </div>
                </div>

                {/* Interactive Protocol Checklist (قائمة فحص البروتوكول التفاعلية) */}
                <div className="bg-white p-4 rounded-xl border border-stone-200/80 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-[#0B5145]" />
                      <span className="text-xs font-bold text-stone-900">
                        قائمة فحص بروتوكول المرحلة (انقر للتأشير والتأكيد الميداني):
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-stone-400">
                      معايير التحقق الصارمة 0{activeVisualStage.id}
                    </span>
                  </div>

                  <div className="space-y-2 pt-1">
                    {activeVisualStage.checklist.map((item, idx) => {
                      const key = `${activeVisualStage.id}-${idx}`;
                      const isChecked = !!checkedProtocols[key];

                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleToggleProtocol(activeVisualStage.id, idx)}
                          className={`w-full p-2.5 rounded-lg border text-right text-xs transition-all flex items-center gap-2.5 cursor-pointer ${
                            isChecked
                              ? 'bg-emerald-50/70 border-emerald-300 text-[#0B5145]'
                              : 'bg-stone-50/50 border-stone-200 text-stone-700 hover:bg-stone-50'
                          }`}
                        >
                          {isChecked ? (
                            <CheckSquare className="w-4 h-4 text-[#0B5145] shrink-0" />
                          ) : (
                            <Square className="w-4 h-4 text-stone-400 shrink-0" />
                          )}
                          <span className={`${isChecked ? 'line-through opacity-85' : ''}`}>
                            {item}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Country Breakdown & Filter Toolbar */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  
                  {/* Countries represented */}
                  <div className="flex flex-wrap items-center gap-1.5 text-xs">
                    <span className="text-stone-500 text-[11px] flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-stone-400" />
                      <span>التوزيع الجغرافي:</span>
                    </span>
                    {activeStageCountries.length === 0 ? (
                      <span className="text-[11px] text-stone-400">لا توجد قضايا حالياً</span>
                    ) : (
                      activeStageCountries.map((c, i) => (
                        <span key={i} className="px-2 py-0.5 rounded-md bg-white border border-stone-200 text-stone-700 text-[11px] font-mono">
                          {c.country}: <strong>{c.count}</strong>
                        </span>
                      ))
                    )}
                  </div>

                  {/* Filter toggle */}
                  <div className="flex items-center gap-1.5 text-xs">
                    <button
                      type="button"
                      onClick={() => setStageUrgentOnly(false)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                        !stageUrgentOnly ? 'bg-[#0B5145] text-white' : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
                      }`}
                    >
                      الكل ({activeVisualStage.cases.length})
                    </button>
                    {activeVisualStage.urgentCount > 0 && (
                      <button
                        type="button"
                        onClick={() => setStageUrgentOnly(true)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                          stageUrgentOnly ? 'bg-rose-700 text-white' : 'bg-white border border-rose-200 text-rose-700 hover:bg-rose-50'
                        }`}
                      >
                        عاجلة فقط ({activeVisualStage.urgentCount})
                      </button>
                    )}
                  </div>
                </div>

                {/* Cases tied to this stage from the cases array */}
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between text-xs font-semibold text-stone-700 mb-2">
                    <span>القضايا المسجلة في مرحلة «{activeVisualStage.name}» ({displayedStageCases.length}):</span>
                    <span className="text-[11px] text-stone-400 font-mono">مربوط بحالة القضايا في مصفوفة cases</span>
                  </div>

                  {displayedStageCases.length === 0 ? (
                    <div className="p-6 bg-white rounded-xl border border-dashed border-stone-300 text-center text-xs text-stone-500 space-y-1">
                      <div className="font-semibold text-stone-700">لا توجد قضايا تطابق الفلتر في مرحلة «{activeVisualStage.name}»</div>
                      <p className="text-[11px] text-stone-400">جميع البلاغات جرى فحصها أو تصعيدها للمراحل التوثيقية التالية.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {displayedStageCases.map((c) => (
                        <div
                          key={c.id}
                          className="p-3.5 bg-white rounded-xl border border-stone-200/80 hover:border-[#0B5145]/40 hover:shadow-xs transition-all flex items-center justify-between gap-3 text-right"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 mb-1">
                              <span className="text-[10px] font-mono font-bold text-stone-400">
                                {c.id}
                              </span>
                              <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-stone-100 text-stone-600">
                                {c.country}
                              </span>
                              {c.status === 'urgent' && (
                                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-50 text-rose-700 border border-rose-200">
                                  عاجل
                                </span>
                              )}
                              <span className="text-[10px] font-mono text-stone-400">
                                {c.stats.documentsCount} وثائق
                              </span>
                            </div>
                            <div className="text-xs font-bold text-stone-900 truncate">
                              {c.name}
                            </div>
                            <div className="text-[10px] text-stone-500 mt-0.5 truncate">
                              {c.caseType} — {c.lastUpdated}
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              onClick={() => handleOpenCaseDetail(c.id)}
                              className="px-2.5 py-1 bg-stone-100 hover:bg-[#0B5145] hover:text-white text-stone-700 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer"
                            >
                              فتح الملف
                            </button>
                            {activeVisualStage.id < 7 && (
                              <button
                                onClick={(e) => handlePromoteCaseInPipeline(c, e)}
                                title="ترقية القضية للمرحلة التالية في المسار"
                                className="px-2.5 py-1 bg-[#0B5145] hover:bg-[#083B32] text-white text-[11px] font-semibold rounded-lg transition-colors cursor-pointer shadow-2xs"
                              >
                                ترقية ←
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>

            </section>
          )}

          {/* View: Overview Dashboard */}
          {currentSection === 'dashboard' && (
            <AdminOverviewView
              cases={cases}
              onOpenCaseDetail={handleOpenCaseDetail}
              onNavigateSection={handleSelectSection}
              onAddNewCase={() => setShowNewCaseModal(true)}
              onUpdateCase={onUpdateCase}
            />
          )}

          {/* View: Visual Documentation Dedicated Section */}
          {currentSection === 'visual_documentation' && (
            <VisualDocumentationSection
              cases={cases}
              onOpenCaseDetail={handleOpenCaseDetail}
              onNavigateSection={handleSelectSection}
              onUpdateCase={onUpdateCase}
              isStandalonePage={true}
            />
          )}

          {/* View: Cases Table */}
          {currentSection === 'cases' && (
            <AdminCasesTableView
              cases={cases}
              onOpenCaseDetail={handleOpenCaseDetail}
              onAddNewCase={() => setShowNewCaseModal(true)}
              initialFilter={filterPreset}
            />
          )}

          {/* View: Case Detail Workspace */}
          {currentSection === 'case_detail' && activeCase && (
            <AdminCaseDetailWorkspace
              caseItem={activeCase}
              onBack={() => setCurrentSection('cases')}
              onUpdateCase={onUpdateCase}
              onOpenPublicDossier={(id) => {
                window.location.hash = `#/case/${id}`;
              }}
            />
          )}

          {/* View: Countries Management */}
          {currentSection === 'countries' && (
            <AdminCountriesManagementView
              countries={countriesList}
              onSelectCountryFilter={(name) => {
                setFilterPreset(name);
                setCurrentSection('cases');
              }}
            />
          )}

          {/* View: Submissions */}
          {currentSection === 'submissions' && (
            <AdminSubmissionsView />
          )}

          {/* View: Team Management */}
          {currentSection === 'team' && (
            <AdminTeamView />
          )}

          {/* View: Activity Logs */}
          {currentSection === 'logs' && (
            <div className="space-y-6 text-right pb-12">
              <div className="pb-4 border-b border-stone-200">
                <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
                  <History className="w-6 h-6 text-[#0B5145]" />
                  <span>سجل التعديلات والأنشطة الميدانية الشامل</span>
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  سجل غير قابل للتعديل يوثق كل إضافة، تعديل، فحص وثيقة، وتغيير لحالة القضايا في المنصة.
                </p>
              </div>

              <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm divide-y divide-stone-100 text-xs">
                {INITIAL_ACTIVITY_LOGS.map((log) => (
                  <div key={log.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-stone-900 text-sm font-serif-ar">{log.user}</span>
                        <span className="px-2 py-0.5 rounded bg-stone-100 text-[10px] text-stone-600 font-mono">{log.role}</span>
                        {log.targetCaseId && (
                          <span className="font-mono font-bold text-[#0B5145] text-xs">[{log.targetCaseId}]</span>
                        )}
                      </div>
                      <p className="text-stone-700 text-xs">{log.action}</p>
                    </div>
                    <div className="text-stone-400 font-mono text-[11px] self-end sm:self-auto">
                      {log.timestamp} ({log.timeAgo})
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* View: Evidence Vault */}
          {currentSection === 'evidence' && (
            <div className="space-y-6 text-right pb-12">
              <div className="pb-4 border-b border-stone-200">
                <h1 className="text-2xl font-bold text-[#17201D] font-serif-ar flex items-center gap-2">
                  <FileText className="w-6 h-6 text-[#0B5145]" />
                  <span>مستودع الأدلة والوثائق الموحد</span>
                </h1>
                <p className="text-xs text-stone-500 mt-1">
                  إدارة الوثائق المفحوصة والمشفرة مع تطبيق مستويات السرية الثلاثة
                </p>
              </div>

              <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm overflow-x-auto text-xs">
                <table className="w-full text-right">
                  <thead>
                    <tr className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold font-mono">
                      <th className="py-3 px-3">رقم القضية</th>
                      <th className="py-3 px-3">اسم الوثيقة</th>
                      <th className="py-3 px-3">نوعها</th>
                      <th className="py-3 px-3">مستوى السرية</th>
                      <th className="py-3 px-3">التاريخ</th>
                      <th className="py-3 px-3">من رفعها</th>
                      <th className="py-3 px-3 text-left">الملف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {cases.flatMap(c => c.evidence.map(e => ({ ...e, caseId: c.id, caseName: c.name }))).map((ev, i) => (
                      <tr key={i} className="hover:bg-stone-50">
                        <td className="py-3 px-3 font-mono font-bold text-[#0B5145]">{ev.caseId}</td>
                        <td className="py-3 px-3 font-bold text-stone-900">{ev.title}</td>
                        <td className="py-3 px-3 text-stone-600">{ev.type}</td>
                        <td className="py-3 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            ev.confidentiality === 'public' ? 'bg-emerald-100 text-emerald-800' :
                            ev.confidentiality === 'internal' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                          }`}>
                            {ev.confidentiality}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-mono text-stone-500">{ev.date}</td>
                        <td className="py-3 px-3 text-stone-600">{ev.uploader || 'أحمد المنصوري'}</td>
                        <td className="py-3 px-3 text-left">
                          <button
                            onClick={() => handleOpenCaseDetail(ev.caseId)}
                            className="text-xs text-[#0B5145] font-bold hover:underline"
                          >
                            عرض في القضية ←
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* View: Settings & Security & Site Administration */}
          {currentSection === 'settings' && (
            <AdminSettingsView cases={cases} />
          )}

          {/* View: Sources & Witnesses */}
          {currentSection === 'sources' && (
            <AdminSourcesView
              cases={cases}
              onOpenCaseDetail={handleOpenCaseDetail}
            />
          )}

          {/* View: Unified Timeline */}
          {currentSection === 'timeline' && (
            <AdminTimelineView
              cases={cases}
              onOpenCaseDetail={handleOpenCaseDetail}
            />
          )}

          {/* View: Campaigns Management */}
          {currentSection === 'campaigns' && (
            <AdminCampaignsManagementView
              cases={cases}
              onOpenCaseDetail={handleOpenCaseDetail}
            />
          )}

          {/* View: Statistical Reports */}
          {currentSection === 'reports' && (
            <AdminReportsView
              cases={cases}
            />
          )}

          {/* View: Media Center Releases */}
          {currentSection === 'media' && (
            <AdminMediaManagementView
              cases={cases}
              onOpenCaseDetail={handleOpenCaseDetail}
            />
          )}

        </main>
      </div>

      {/* Modal: New Case */}
      <AdminNewCaseModal
        isOpen={showNewCaseModal}
        onClose={() => setShowNewCaseModal(false)}
        onSaveCase={handleSaveNewCase}
      />

    </div>
  );
};
