import React, { useState } from 'react';
import { X, CheckCircle2, Lock, Upload, Send } from 'lucide-react';

interface SubmitInfoModalProps {
  caseId: string | null;
  onClose: () => void;
}

export const SubmitInfoModal: React.FC<SubmitInfoModalProps> = ({ caseId, onClose }) => {
  const [tipText, setTipText] = useState('');
  const [secureContact, setSecureContact] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!caseId) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full text-right shadow-2xl border border-stone-200 relative">
        <button
          onClick={onClose}
          className="absolute left-4 top-4 text-stone-400 hover:text-stone-700 cursor-pointer p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-xl font-bold text-[#17201D] font-serif-ar mb-1">
          إرسال إفادة أو وثيقة تكميلية
        </h3>
        <p className="text-xs text-stone-500 mb-6 font-mono">
          بشأن الملف: <strong className="text-[#0B5145]">{caseId}</strong>
        </p>

        {submitted ? (
          <div className="py-8 text-center">
            <CheckCircle2 className="w-12 h-12 text-[#0B5145] mx-auto mb-3" />
            <h4 className="text-lg font-bold text-stone-900 mb-1">تم إرسال المعلومات بأمان</h4>
            <p className="text-xs text-stone-600">
              سيقوم فريق التحقيق بمطابقة الإفادة مع السجلات المعتمدة. شكراً لمساهمتك في التثبت.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                المعلومة أو التطور الجديد
              </label>
              <textarea
                required
                rows={4}
                value={tipText}
                onChange={(e) => setTipText(e.target.value)}
                placeholder="اكتب تفاصيل التطور أو المعلومة الجديدة أو ما يثبتها..."
                className="w-full p-3 rounded-xl border border-stone-300 text-xs sm:text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                وسيلة تواصل آمنة (اختياري، في حال أردت أن نتابع معك)
              </label>
              <input
                type="text"
                value={secureContact}
                onChange={(e) => setSecureContact(e.target.value)}
                placeholder="Signal / Telegram / البريد الإلكتروني"
                className="w-full p-2.5 rounded-xl border border-stone-300 text-xs sm:text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
              />
            </div>

            <div className="p-3 bg-stone-50 rounded-xl text-[11px] text-stone-500 leading-relaxed border border-stone-200 flex items-start gap-2">
              <Lock className="w-4 h-4 text-[#0B5145] shrink-0 mt-0.5" />
              <span>
                جميع البلاغات والمعلومات مرسلة عبر خوادم مشفرة؛ لن يُكشف مصدر الإفادة أو هويتك مطلقاً.
              </span>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 rounded-xl cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs sm:text-sm font-semibold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>إرسال الإفادة</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
