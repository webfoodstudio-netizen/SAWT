import React from 'react';
import { ViewType } from '../types';
import { ShieldCheck, Scale, Globe, Lock, ArrowUp } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: ViewType) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#17201D] text-stone-300 border-t border-white/10 pt-16 pb-12 text-right">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand & Mission Column */}
          <div className="lg:col-span-4">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-lg bg-[#0B5145] text-white flex items-center justify-center font-bold text-lg font-serif-ar">
                ص
              </div>
              <span className="text-xl font-bold font-serif-ar text-white">
                صوت المظلوم
              </span>
            </div>
            
            <p className="text-xs sm:text-sm text-stone-400 leading-relaxed mb-4">
              منصة عربية مستقلة لتوثيق ومتابعة القضايا الإنسانية، التثبت الصحفي والحقوقي، وربط الملفات الموثقة بشبكة المساعدة القانونية والإعلامية.
            </p>

            <blockquote className="text-xs font-serif-ar text-emerald-300 border-r-2 border-emerald-400 pr-3 py-1 mb-4">
              "لأن صوت المظلوم لا يجب أن يختفي."
            </blockquote>

            <div className="flex items-center gap-2 text-xs text-stone-400 font-mono">
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>خوادم مشفرة · سياسة صارمة لحماية الشهود</span>
            </div>
          </div>

          {/* Quick Nav Links 1 */}
          <div className="lg:col-span-3 space-y-2.5 text-xs">
            <h4 className="text-sm font-bold text-white font-serif-ar mb-3">
              أرشيف القضايا والمتابعة
            </h4>
            <div>
              <button onClick={() => onNavigate('cases')} className="hover:text-white transition-colors cursor-pointer">
                أرشيف القضايا الموثقة
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('urgent')} className="hover:text-rose-300 transition-colors cursor-pointer flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                الحالات العاجلة والطارئة
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('countries')} className="hover:text-white transition-colors cursor-pointer">
                خريطة الدول العربية وأولوية المتابعة
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('campaigns')} className="hover:text-white transition-colors cursor-pointer">
                الحملات والمطالب القانونية
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('submit_case')} className="text-emerald-400 font-bold hover:underline cursor-pointer">
                + تقديم بلاغ عن قضية جديدة
              </button>
            </div>
          </div>

          {/* Quick Nav Links 2 */}
          <div className="lg:col-span-3 space-y-2.5 text-xs">
            <h4 className="text-sm font-bold text-white font-serif-ar mb-3">
              الثقة والمساندة
            </h4>
            <div>
              <button onClick={() => onNavigate('verification_guide')} className="hover:text-white transition-colors cursor-pointer">
                كيف نتحقق من صحة القضايا؟
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('legal_network')} className="hover:text-white transition-colors cursor-pointer">
                شبكة المساعدة القانونية
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('media_center')} className="hover:text-white transition-colors cursor-pointer">
                المركز الإعلامي وحقائب الصحافة
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('fund')} className="hover:text-white transition-colors cursor-pointer">
                صندوق صوت المظلوم للتضامن
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('charter')} className="hover:text-white transition-colors cursor-pointer">
                ميثاق الشرف الأخلاقي
              </button>
            </div>
          </div>

          {/* Quick Nav Links 3 */}
          <div className="lg:col-span-2 space-y-2.5 text-xs">
            <h4 className="text-sm font-bold text-white font-serif-ar mb-3">
              المنصة والإدارة
            </h4>
            <div>
              <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer">
                لماذا وُجد صوت المظلوم؟
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('admin_dashboard')} className="hover:text-emerald-300 transition-colors cursor-pointer font-semibold text-stone-300">
                لوحة التحقيق والتدقيق
              </button>
            </div>
            <div className="pt-4">
              <button
                onClick={scrollToTop}
                className="inline-flex items-center gap-1.5 p-2 rounded-lg bg-white/10 hover:bg-white/20 text-stone-300 text-xs transition-colors cursor-pointer"
              >
                <ArrowUp className="w-3.5 h-3.5" />
                <span>إلى أعلى الصفحة</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom copyright & ethical statement */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500 text-center sm:text-right">
          <div>
            جميع الحقوق محفوظة لمنصة «صوت المظلوم» © {new Date().getFullYear()} — عمل حقوقي وإنساني مستقل.
          </div>
          <div className="flex items-center gap-4 text-[11px] font-mono">
            <span>NO VIOLENCE</span>
            <span>·</span>
            <span>VERIFIED EVIDENCE ONLY</span>
            <span>·</span>
            <span>HUMAN DIGNITY</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
