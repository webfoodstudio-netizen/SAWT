import React, { useState } from 'react';
import { CaseItem } from '../types';
import { 
  FileText, 
  Download, 
  Printer, 
  Share2, 
  Globe, 
  ExternalLink, 
  CheckCircle,
  FileArchive,
  Image as ImageIcon
} from 'lucide-react';
import { ASSET_IMAGES } from '../data/mockData';

interface MediaCenterViewProps {
  cases: CaseItem[];
  onOpenCase: (caseId: string) => void;
}

export const MediaCenterView: React.FC<MediaCenterViewProps> = ({ cases, onOpenCase }) => {
  const [selectedCaseId, setSelectedCaseId] = useState<string>(cases[0]?.id || 'CASE-EGY-042');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const currentCase = cases.find(c => c.id === selectedCaseId) || cases[0];

  const handleCopyPressText = () => {
    if (!currentCase) return;
    const text = `[بيان صحفي - منصة صوت المظلوم]
الملف التوثيقي: ${currentCase.id} - ${currentCase.name}
الدولة: ${currentCase.country} (${currentCase.city})
الحالة: ${currentCase.status === 'urgent' ? 'عاجلة' : 'موثقة'}
تاريخ التحديث: ${currentCase.lastUpdated}
الملخص: ${currentCase.summary}
المصادر المفحوصة: ${currentCase.stats.sourcesCount} مصادر معتمدة
الوثائق المتاحة: ${currentCase.stats.documentsCount} وثائق رسمية
الرابط الرسمي المعتمد: ${window.location.origin}/#/case/${currentCase.id}`;

    navigator.clipboard.writeText(text);
    setCopiedId(currentCase.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-10 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header */}
        <div className="max-w-3xl mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0B5145]/10 text-[#0B5145] text-xs font-bold mb-2">
            <FileText className="w-4 h-4" />
            <span>الصحافة والتحقيقات المستقلة</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-2">
            المركز الإعلامي وحقائب الصحافة (Press Kits)
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            نوفر للصحفيين والمراسلين والمنظمات الدولية حقائب إعلامية مدققة تضم ملخصات الوقائع، التسلسل الزمني، الوثائق المتاحة للنشر، والصور المصرح بها قانونياً وأخلاقياً.
          </p>
        </div>

        {/* Press Releases Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          
          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-mono text-[#0B5145] font-bold block mb-1">
                بيان صحفي عاجل · 05 أكتوبر 2026
              </span>
              <h3 className="text-base font-bold text-stone-900 font-serif-ar mb-2">
                نداء إلى المقرر الخاص المعني بالاحتجاز التعسفي بشأن قضية محمد بن سالم
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed mb-4">
                تطالب المنصة بالإفراج الصحي الفوري بعد 214 يوماً من الحبس الاحتياطي دون تمكين من الرعاية الطبية.
              </p>
            </div>
            <button
              onClick={() => onOpenCase('CASE-EGY-042')}
              className="text-xs font-bold text-[#0B5145] hover:underline self-start cursor-pointer"
            >
              قراءة البيان ومراجعة المرفقات ←
            </button>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-mono text-[#0B5145] font-bold block mb-1">
                مذكرة توثيقية · 04 أكتوبر 2026
              </span>
              <h3 className="text-base font-bold text-stone-900 font-serif-ar mb-2">
                تقرير استقصائي حول مراكز الاحتجاز غير الرسمية في جنوب اليمن
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed mb-4">
                مطابقة إفادات 7 معتقلين سابقين وتوثيق أسماء 43 مفقوداً بالتنسيق مع روابط الأسر.
              </p>
            </div>
            <button
              onClick={() => onOpenCase('CASE-YEM-003')}
              className="text-xs font-bold text-[#0B5145] hover:underline self-start cursor-pointer"
            >
              قراءة المذكرة ومراجعة المرفقات ←
            </button>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-mono text-[#0B5145] font-bold block mb-1">
                نشرة رصد دورية · 01 أكتوبر 2026
              </span>
              <h3 className="text-base font-bold text-stone-900 font-serif-ar mb-2">
                المؤشر الإقليمي لأولوية المتابعة الحقوقية لشهر سبتمبر 2026
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed mb-4">
                تحليل إحصائي مستقل شمل 12 دولة عربية ورصد 128 قضية موثقة و17 حالة عاجلة.
              </p>
            </div>
            <a
              href="#/countries"
              className="text-xs font-bold text-[#0B5145] hover:underline self-start cursor-pointer"
            >
              الاطلاع على تقرير المؤشر ←
            </a>
          </div>

        </div>

        {/* Interactive Press Kit Generator / Viewer */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-stone-200 mb-8">
            <div>
              <h2 className="text-2xl font-bold text-[#17201D] font-serif-ar">
                منشئ وتنزيل الحقيبة الصحفية (Press Kit)
              </h2>
              <p className="text-xs text-stone-500 mt-1">
                اختر الملف للحصول على حزمة المحتوى المصرح به للصحافة (بالعربية، الإنجليزية، والفرنسية).
              </p>
            </div>

            {/* Case Picker */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-stone-600">اختر القضية:</span>
              <select
                value={selectedCaseId}
                onChange={(e) => setSelectedCaseId(e.target.value)}
                className="px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs font-semibold text-stone-800"
              >
                {cases.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.id} — {c.name} ({c.country})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {currentCase && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Preview Document Area */}
              <div className="lg:col-span-8 bg-[#FBF9F5] p-6 sm:p-8 rounded-2xl border border-stone-200 font-mono text-xs text-stone-800 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-stone-200 text-[11px] text-stone-500">
                  <span>SAWT AL-MAZLOUM // MEDIA DOSSIER</span>
                  <span>REF: {currentCase.id}</span>
                </div>

                <div>
                  <h3 className="text-lg font-bold font-serif-ar text-[#17201D] font-sans">
                    ملف صحفي: {currentCase.name}
                  </h3>
                  <div className="text-stone-500 text-[11px]">
                    الدولة: {currentCase.country} · التحديث: {currentCase.lastUpdated} · الحالة: {currentCase.status}
                  </div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-stone-200 leading-relaxed font-sans text-xs">
                  <strong className="block text-stone-900 mb-1">الموجز التحريري:</strong>
                  {currentCase.summary}
                </div>

                <div className="space-y-1 font-sans text-xs">
                  <strong className="block text-stone-900">المحطات الزمنية الموثقة:</strong>
                  {currentCase.timeline.slice(0, 3).map((t, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-stone-600">
                      <span className="text-[#0B5145] font-bold font-mono">[{t.date}]</span>
                      <span>{t.title}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-3 border-t border-stone-200 flex items-center justify-between text-[11px] text-stone-500 font-sans">
                  <span>اللغات المتاحة: العربية · Français · English</span>
                  <span>الصور: مصرح بالاستخدام الصحفي مع الإسناد لمصدر "صوت المظلوم"</span>
                </div>
              </div>

              {/* Action Downloads Sidebar */}
              <div className="lg:col-span-4 space-y-4">
                <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                  <h4 className="text-sm font-bold text-stone-900 font-serif-ar">
                    تحميل الحزم الإعلامية
                  </h4>

                  <button
                    onClick={handleCopyPressText}
                    className="w-full py-3 px-4 rounded-xl bg-white border border-stone-300 text-stone-800 text-xs font-semibold hover:bg-stone-100 flex items-center justify-center gap-2 cursor-pointer transition-colors"
                  >
                    <FileText className="w-4 h-4 text-[#0B5145]" />
                    <span>{copiedId ? 'تم نسخ النص الصحفي بنجاح!' : 'نسخ النص الصحفي المعتمد'}</span>
                  </button>

                  <button
                    onClick={() => window.print()}
                    className="w-full py-3 px-4 rounded-xl bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-sm"
                  >
                    <Printer className="w-4 h-4" />
                    <span>تصدير ملف PDF الصحفي جاهز للطباعة</span>
                  </button>

                  <a
                    href={currentCase.image}
                    download={`${currentCase.id}-photo.jpg`}
                    className="w-full py-3 px-4 rounded-xl bg-white border border-stone-300 text-stone-800 text-xs font-semibold hover:bg-stone-100 flex items-center justify-center gap-2 cursor-pointer transition-colors"
                  >
                    <ImageIcon className="w-4 h-4 text-[#0B5145]" />
                    <span>تحميل الصور المصرح بنشرها</span>
                  </a>
                </div>

                <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs text-amber-900 leading-relaxed">
                  <strong>ملاحظة للصحفيين:</strong> تتوفر إفادات صوتية ومقابلات للمصادر المصرح بها عند التواصل المباشر عبر البريد المعتمد للمكتب الإعلامي: <code className="font-mono text-[#0B5145]">media@mazloum.org</code>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
