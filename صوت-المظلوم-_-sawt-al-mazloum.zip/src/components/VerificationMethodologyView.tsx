import React from 'react';
import { 
  ShieldCheck, 
  FileSearch, 
  Layers, 
  CalendarCheck, 
  AlertCircle, 
  UserCheck, 
  Send,
  Scale
} from 'lucide-react';

export const VerificationMethodologyView: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'نستقبل المعلومات والبلاغ',
      desc: 'عبر قنواتنا المشفرة أو مكاتب التنسيق الميدانية، نتلقى الإفادات الأولية وننشئ معرفاً رقمياً آمناً للملف.',
      icon: Send,
    },
    {
      num: '02',
      title: 'نطلب الأدلة والمستندات',
      desc: 'نطالب بأصل المحاضر الرسمية، أوامر التوقيف، البطاقات التعريفية، التقارير الطبية، أو قرارات المحاكم.',
      icon: FileSearch,
    },
    {
      num: '03',
      title: 'نقارن المصادر المتعددة',
      desc: 'لا نعتمد على رواية واحدة مطلقاً؛ نطابق إفادات الأسرة مع هيئة الدفاع ومع سجلات نقابة المحامين ومصادر مستقلة.',
      icon: Layers,
    },
    {
      num: '04',
      title: 'نتحقق من التواريخ والبيانات الوصفية',
      desc: 'نفحص صحة الأختام القضائية، بصمات الإيداع، التسلسل الزمني للأحداث، والبيانات التقنية للملفات والصور.',
      icon: CalendarCheck,
    },
    {
      num: '05',
      title: 'نبحث عن التناقضات والفجوات',
      desc: 'نخضع الملف لاختبار نزاهة صارم؛ أي معلومة يشوبها تناقض أو ادعاء غير مثبت تُعزل فوراً تحت تصنيف (قيد التحقق).',
      icon: AlertCircle,
    },
    {
      num: '06',
      title: 'يراجعها باحث إنساني مستقل',
      desc: 'الذكاء الاصطناعي لا يقرر المظلومية؛ القرار النهائي بشري تحرره هيئة تحرير حقوقية وقانونية معتمدة.',
      icon: UserCheck,
    },
    {
      num: '07',
      title: 'ننشر فقط ما نستطيع إثباته',
      desc: 'ننشر الملف مع فصل قاطع بين ما هو مثبت بالوثائق وما هو قيد التحري، مع تحديث مستمر ومراجعة علنية.',
      icon: Scale,
    },
  ];

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-12 sm:py-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0B5145]/10 text-[#0B5145] text-xs font-bold mb-3">
            <ShieldCheck className="w-4 h-4" />
            <span>منهجية التثبت والأمانة العلمية</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-bold text-[#17201D] font-serif-ar mb-4">
            كيف نعرف أن القضية حقيقية؟
          </h1>
          <p className="text-stone-600 text-sm sm:text-lg leading-relaxed">
            العدل يبدأ بالتثبت؛ لا نتسرع في تبني الروايات ولا نطلق أحكاماً دون فحص مستقل. إليك المسار المنهجي الذي يمر به كل ملف قبل أن يرى النور.
          </p>
        </div>

        {/* The 7 Steps Journey */}
        <div className="space-y-6 mb-16">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={step.num}
                className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/80 shadow-sm hover:shadow-md transition-shadow grid grid-cols-1 md:grid-cols-12 gap-6 items-center"
              >
                <div className="md:col-span-2 flex items-center gap-4 md:flex-col md:items-center text-center">
                  <div className="w-14 h-14 rounded-2xl bg-[#0B5145]/10 text-[#0B5145] flex items-center justify-center">
                    <Icon className="w-7 h-7" />
                  </div>
                  <span className="text-xl sm:text-2xl font-mono font-bold text-[#0B5145]">
                    {step.num}
                  </span>
                </div>

                <div className="md:col-span-10 text-right">
                  <h3 className="text-xl font-bold text-[#17201D] font-serif-ar mb-2">
                    {step.title}
                  </h3>
                  <p className="text-stone-700 text-sm leading-relaxed font-normal">
                    {step.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Big Golden Credo Banner */}
        <div className="bg-[#0B5145] text-white rounded-3xl p-8 sm:p-14 text-center shadow-lg relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto">
            <span className="text-xs font-mono tracking-widest uppercase text-emerald-200 block mb-3">
              القاعدة الذهبية لمنصة صوت المظلوم
            </span>
            <blockquote className="text-2xl sm:text-4xl font-bold font-serif-ar leading-snug mb-4">
              "ما لا نستطيع إثباته، لا نقدمه كحقيقة."
            </blockquote>
            <p className="text-stone-200 text-sm sm:text-base leading-relaxed">
              نفضل تأخير النشر والانتظار حتى التحقق الكامل على المجازفة بنشر معلومة مغلوطة تضر بكرامة الضحية أو تمس مصداقية القضية.
            </p>
          </div>
        </div>

        {/* Tri-Fold Ethical Guarantee */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12 text-right">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
            <h4 className="font-bold text-[#17201D] text-base mb-2 font-serif-ar">
              01 — حماية الهوية والبيانات
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              أي مستند يحوي بيانات شخصية للشهود أو أرقام هواتف أو عناوين أسر الضحايا يخضع لتشفير فوري وإخفاء تام من الواجهة العامة.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
            <h4 className="font-bold text-[#17201D] text-base mb-2 font-serif-ar">
              02 — عدم التمييز
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              نوثق الانتهاك بمعزل عن الهوية الفكرية أو السياسية لصاحبه؛ فالحق في المحاكمة العادلة والكرامة الإنسانية أصيل لكل إنسان.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
            <h4 className="font-bold text-[#17201D] text-base mb-2 font-serif-ar">
              03 — التصحيح العلني
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              إذا طرأ أي مستجد رسمي ينفي معلومة سابقة، نعلن التصحيح بشكل صريح في سجل التعديلات المتاح مع تاريخ وساعة المراجعة.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};
