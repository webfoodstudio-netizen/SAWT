import React, { useState } from 'react';
import { CountryPriority } from '../types';
import { MapPin, ArrowLeft, ShieldAlert, CheckCircle, Clock, Globe } from 'lucide-react';

interface ArabWorldSectionProps {
  countries: CountryPriority[];
  onSelectCountry: (countryName: string) => void;
  onViewAllCountries: () => void;
}

export const ArabWorldSection: React.FC<ArabWorldSectionProps> = ({
  countries,
  onSelectCountry,
  onViewAllCountries,
}) => {
  // Sort countries dynamically by priority score
  const sortedCountries = [...countries].sort((a, b) => b.priorityScore - a.priorityScore);
  const [selectedCountry, setSelectedCountry] = useState<CountryPriority>(sortedCountries[0]);

  return (
    <section className="py-16 sm:py-24 bg-[#F5F3EE] border-t border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title & Philosophy */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-mono font-bold uppercase text-[#0B5145] tracking-widest block mb-1">
            الأرشيف الجغرافي العربي
          </span>
          <h2 className="text-2xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-3">
            العالم العربي: أولوية المتابعة
          </h2>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            لا نصنف الدول سياسياً، بل نحتسب أولوية المتابعة دورياً بناءً على: عدد القضايا الموثقة، الحالات العاجلة، حداثة التطورات، والحاجة لتدخل قانوني طارئ.
          </p>
        </div>

        {/* Interactive Layout: Map / Pins & Active Country Spotlight */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left/Main Column: Stylized Arab Region Map Representation */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-stone-800 flex items-center gap-2">
                <Globe className="w-4 h-4 text-[#0B5145]" />
                خارطة توزيع ملفات المتابعة الحقوقية
              </h3>
              <span className="text-xs text-stone-500 font-mono">انقر على الدولة للاطلاع</span>
            </div>

            {/* Stylized Interactive Map Canvas */}
            <div className="relative aspect-[16/10] bg-[#FAF8F5] rounded-2xl border border-stone-200/70 p-4 flex items-center justify-center overflow-hidden">
              
              {/* Background Geographic Silhouette Guide */}
              <svg className="w-full h-full text-stone-200/70" viewBox="0 0 900 550" fill="currentColor">
                {/* Simplified contour of Arab region */}
                <path d="M 180,210 Q 230,190 280,220 T 380,240 T 460,210 T 560,250 T 640,240 T 730,340 T 780,410 T 710,510 T 640,480 T 560,420 T 470,350 T 360,330 T 260,310 Z" opacity="0.4" />
                <path d="M 520,310 Q 560,300 600,320 T 620,380 T 580,430 T 540,360 Z" opacity="0.3" />
              </svg>

              {/* Interactive Country Pins */}
              <div className="absolute inset-0">
                {countries.map((c) => {
                  const isSelected = selectedCountry.code === c.code;
                  // Fallback coordinate positioning
                  const coords = c.coordinates || { x: 450, y: 250 };
                  const leftPercent = (coords.x / 900) * 100;
                  const topPercent = (coords.y / 550) * 100;

                  return (
                    <button
                      key={c.code}
                      onClick={() => setSelectedCountry(c)}
                      style={{ left: `${leftPercent}%`, top: `${topPercent}%` }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 transition-all cursor-pointer group z-20 ${
                        isSelected ? 'scale-125 z-30' : 'hover:scale-110'
                      }`}
                      title={`${c.nameAr} (${c.totalCases} قضية)`}
                    >
                      <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold transition-all shadow-md ${
                        isSelected 
                          ? 'bg-[#0B5145] text-white ring-4 ring-[#0B5145]/20' 
                          : 'bg-white text-stone-800 border border-stone-300 hover:border-[#0B5145]'
                      }`}>
                        <span className={`w-2 h-2 rounded-full ${c.urgentCases > 0 ? 'bg-rose-500' : 'bg-emerald-500'}`} />
                        <span>{c.nameAr}</span>
                        <span className="text-[10px] opacity-75 font-mono">{c.totalCases}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Map legend */}
              <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-stone-200 text-[11px] text-stone-600 flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-rose-500" /> بها حالات عاجلة
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" /> متابعة موثقة
                </span>
              </div>
            </div>

            {/* Country Selector Grid / Quick list */}
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mt-4 pt-4 border-t border-stone-100">
              {sortedCountries.slice(0, 8).map((c) => (
                <button
                  key={c.code}
                  onClick={() => setSelectedCountry(c)}
                  className={`px-3 py-2 rounded-xl text-xs font-medium text-right transition-colors cursor-pointer border ${
                    selectedCountry.code === c.code 
                      ? 'bg-[#0B5145]/10 border-[#0B5145] text-[#0B5145] font-bold' 
                      : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span>{c.nameAr}</span>
                    <span className="text-[10px] font-mono text-stone-500">{c.totalCases}</span>
                  </div>
                </button>
              ))}
            </div>

          </div>

          {/* Right Column: Selected Country Dossier Card */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-sm text-right flex flex-col justify-between h-full">
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-stone-100 mb-6">
                <div>
                  <span className="text-xs font-mono font-bold text-stone-400">ملف الدولة</span>
                  <h3 className="text-2xl sm:text-3xl font-bold text-[#17201D] font-serif-ar mt-0.5">
                    {selectedCountry.nameAr}
                  </h3>
                </div>
                <div className="text-left">
                  <span className="text-xs text-stone-400 font-mono block">آخر تحديث</span>
                  <span className="text-xs font-bold text-[#0B5145]">{selectedCountry.lastUpdate}</span>
                </div>
              </div>

              {/* Statistics Breakdown */}
              <div className="space-y-4 mb-8">
                
                <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200/60 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-[#0B5145]/10 text-[#0B5145] flex items-center justify-center font-bold text-sm">
                      Σ
                    </div>
                    <span className="text-sm font-semibold text-stone-800">إجمالي القضايا المسجلة</span>
                  </div>
                  <span className="text-2xl font-bold text-[#17201D] tabular-nums font-serif-ar">
                    {selectedCountry.totalCases}
                  </span>
                </div>

                <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle className="w-5 h-5 text-emerald-600" />
                    <span className="text-sm font-semibold text-emerald-950">قضايا موثقة بالكامل</span>
                  </div>
                  <span className="text-xl font-bold text-emerald-800 tabular-nums font-serif-ar">
                    {selectedCountry.verifiedCases}
                  </span>
                </div>

                <div className="bg-amber-50/60 p-4 rounded-2xl border border-amber-100 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Clock className="w-5 h-5 text-amber-600" />
                    <span className="text-sm font-semibold text-amber-950">قضايا قيد التحقق وفحص الأدلة</span>
                  </div>
                  <span className="text-xl font-bold text-amber-800 tabular-nums font-serif-ar">
                    {selectedCountry.investigatingCases}
                  </span>
                </div>

                <div className="bg-rose-50/60 p-4 rounded-2xl border border-rose-100 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <ShieldAlert className="w-5 h-5 text-rose-600" />
                    <span className="text-sm font-semibold text-rose-950">حالات عاجلة تتطلب تدخلاً طارئاً</span>
                  </div>
                  <span className="text-xl font-bold text-rose-700 tabular-nums font-serif-ar">
                    {selectedCountry.urgentCases}
                  </span>
                </div>

              </div>

              {/* Dynamic Priority Explanation */}
              <div className="p-4 rounded-2xl bg-[#F5F3EE] text-xs text-stone-600 leading-relaxed mb-6">
                <span className="font-bold text-stone-800 block mb-1">معايير أولوية المتابعة لدولة {selectedCountry.nameAr}:</span>
                سجلت المنصة مؤخراً مواعيد جلسات قضائية قريبة وتلقي وثائق تستدعي فحصاً قانونياً عاجلاً وتنسيقاً مع شبكة المحامين المحليين.
              </div>
            </div>

            {/* Direct Link to View Country Cases */}
            <div className="space-y-3">
              <button
                onClick={() => onSelectCountry(selectedCountry.nameAr)}
                className="w-full bg-[#0B5145] hover:bg-[#083B32] text-white font-semibold text-sm py-3.5 px-6 rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>مشاهدة قضايا {selectedCountry.nameAr}</span>
                <ArrowLeft className="w-4 h-4" />
              </button>

              <button
                onClick={onViewAllCountries}
                className="w-full text-center text-xs font-bold text-stone-600 hover:text-[#0B5145] py-2 cursor-pointer"
              >
                عرض أرشيف كافة الدول العربية كاملة →
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
