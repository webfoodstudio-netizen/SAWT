import React from 'react';
import { Share2, FileText, Scale, Megaphone, ArrowLeft } from 'lucide-react';
import { ViewType } from '../types';

interface ChangeStripProps {
  onNavigate: (view: ViewType) => void;
  onOpenSubmitTip: () => void;
}

export const ChangeStrip: React.FC<ChangeStripProps> = ({ onNavigate, onOpenSubmitTip }) => {
  return (
    <section className="py-14 sm:py-18 bg-[#0B5145] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        <h2 className="text-2xl sm:text-3xl font-bold font-serif-ar mb-3 text-white">
          كن جزءاً من التغيير
        </h2>
        
        <p className="text-stone-200 text-sm sm:text-base max-w-2xl mx-auto mb-10 leading-relaxed font-normal">
          ساعدنا في توثيق القضايا، مراجعة الأدلة، وحماية الكرامة. كل إفادة موثقة أو مرافعة قانونية تسهم في إنصاف مظلوم.
        </p>

        {/* 4 Interactive Action Tiles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 max-w-5xl mx-auto">
          
          {/* Action 1: Share Cases */}
          <button
            onClick={() => onNavigate('cases')}
            className="p-6 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/15 transition-all text-right group cursor-pointer"
          >
            <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform">
              <Share2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold font-serif-ar mb-1 text-white">
              شارك القضية
            </h3>
            <p className="text-xs text-stone-200 leading-relaxed">
              انشر الملفات الموثقة للرأي العام والمؤسسات الحقوقية والإعلامية لكسر جدار الصمت.
            </p>
          </button>

          {/* Action 2: Send Tip / Evidence */}
          <button
            onClick={onOpenSubmitTip}
            className="p-6 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/15 transition-all text-right group cursor-pointer"
          >
            <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold font-serif-ar mb-1 text-white">
              أرسل معلومة أو وثيقة
            </h3>
            <p className="text-xs text-stone-200 leading-relaxed">
              لديك إفادة أو محضر أو مستند؟ أرسله عبر قنواتنا المشفرة مع ضمان أقصى درجات السرية.
            </p>
          </button>

          {/* Action 3: Legal Support */}
          <button
            onClick={() => onNavigate('legal_network')}
            className="p-6 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/15 transition-all text-right group cursor-pointer"
          >
            <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform">
              <Scale className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold font-serif-ar mb-1 text-white">
              دعم قانوني
            </h3>
            <p className="text-xs text-stone-200 leading-relaxed">
              إذا كنت محامياً أو باحثاً أو مترجماً، انضم لشبكتنا المعتمدة لتقديم المساندة القضائية.
            </p>
          </button>

          {/* Action 4: Join Campaigns */}
          <button
            onClick={() => onNavigate('campaigns')}
            className="p-6 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/15 transition-all text-right group cursor-pointer"
          >
            <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform">
              <Megaphone className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold font-serif-ar mb-1 text-white">
              انضم للحملات السلمية
            </h3>
            <p className="text-xs text-stone-200 leading-relaxed">
              وقع العرائض الموجهة للهيئات القضائية والمقررين الأمميين الخاصة بكل ملف إنساني.
            </p>
          </button>

        </div>

      </div>
    </section>
  );
};
