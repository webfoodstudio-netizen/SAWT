import React, { useState, useMemo } from 'react';
import { CaseItem, VerificationStatus, CaseType } from '../types';
import { 
  Search, 
  Filter, 
  MapPin, 
  Clock, 
  CheckCircle, 
  ShieldAlert, 
  ArrowLeft, 
  FileText,
  SlidersHorizontal,
  X
} from 'lucide-react';

interface CasesArchiveViewProps {
  cases: CaseItem[];
  onOpenCase: (caseId: string) => void;
  initialFilter?: string;
  initialCountry?: string;
}

export const CasesArchiveView: React.FC<CasesArchiveViewProps> = ({
  cases,
  onOpenCase,
  initialFilter = 'all',
  initialCountry = 'all',
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(initialFilter);
  const [countryFilter, setCountryFilter] = useState<string>(initialCountry);
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'days' | 'sources'>('latest');

  // Extract unique countries
  const countries = useMemo(() => {
    const list = Array.from(new Set(cases.map(c => c.country)));
    return list.sort();
  }, [cases]);

  // Filtered & sorted cases
  const filteredCases = useMemo(() => {
    return cases.filter(item => {
      // Search
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchId = item.id.toLowerCase().includes(q);
        const matchName = item.name.toLowerCase().includes(q);
        const matchCountry = item.country.toLowerCase().includes(q);
        const matchCity = item.city.toLowerCase().includes(q);
        const matchSummary = item.summary.toLowerCase().includes(q);
        if (!matchId && !matchName && !matchCountry && !matchCity && !matchSummary) {
          return false;
        }
      }

      // Status
      if (statusFilter !== 'all') {
        if (statusFilter === 'urgent' && item.status !== 'urgent') return false;
        if (statusFilter === 'verified' && item.status !== 'verified') return false;
        if (statusFilter === 'investigating' && item.status !== 'investigating') return false;
      }

      // Country
      if (countryFilter !== 'all' && item.country !== countryFilter) {
        return false;
      }

      // Type
      if (typeFilter !== 'all' && item.caseType !== typeFilter) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'days') {
        return (b.detentionDays || 0) - (a.detentionDays || 0);
      }
      if (sortBy === 'sources') {
        return b.stats.sourcesCount - a.stats.sourcesCount;
      }
      // Latest updated
      return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
    });
  }, [cases, searchTerm, statusFilter, countryFilter, typeFilter, sortBy]);

  const resetFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setCountryFilter('all');
    setTypeFilter('all');
    setSortBy('latest');
  };

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-10 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-right max-w-3xl mb-8">
          <span className="text-xs font-mono font-bold uppercase text-[#0B5145] tracking-widest block mb-1">
            الأرشيف الصحفي والحقوقي
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-2">
            سجل القضايا الموثقة
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            ملفات إنسانية موثقة وقيد التحقق تتم متابعتها وتحديثها باستمرار وفق المعايير الحقوقية الصارمة.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/80 shadow-sm mb-10 text-right">
          
          {/* Search Input */}
          <div className="relative mb-6">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث بالاسم، رقم القضية (CASE-EGY-042)، اسم المنظمة، أو المحامي..."
              className="w-full pr-12 pl-4 py-3.5 rounded-2xl bg-stone-50 border border-stone-200 text-stone-900 placeholder-stone-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#0B5145] focus:bg-white transition-all"
            />
            <Search className="absolute right-4 top-4 w-5 h-5 text-stone-400 pointer-events-none" />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute left-4 top-4 text-stone-400 hover:text-stone-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Interactive Filters Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Status Tabs */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                حالة التوثيق
              </label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-medium text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#0B5145] cursor-pointer"
              >
                <option value="all">الكل ({cases.length})</option>
                <option value="verified">موثقة فقط</option>
                <option value="urgent">عاجلة تتطلب تدخلاً</option>
                <option value="investigating">قيد التحقق</option>
              </select>
            </div>

            {/* Country Selector */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                الدولة العربية
              </label>
              <select
                value={countryFilter}
                onChange={(e) => setCountryFilter(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-medium text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#0B5145] cursor-pointer"
              >
                <option value="all">كافة الدول ({countries.length})</option>
                {countries.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Case Type */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                نوع القضية
              </label>
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-medium text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#0B5145] cursor-pointer"
              >
                <option value="all">كافة الأنواع</option>
                <option value="detention">احتجاز تعسفي</option>
                <option value="disappearance">اختفاء قسري ومفقودين</option>
                <option value="fair_trial">محاكمة غير عادلة</option>
                <option value="human_rights">انتهاك حقوقي ونقابي</option>
                <option value="custody_death">خطر وفاة وإهمال صحي</option>
                <option value="humanitarian">قضية إنسانية وإغاثية</option>
              </select>
            </div>

            {/* Sort Order */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                الترتيب
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full px-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-medium text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#0B5145] cursor-pointer"
              >
                <option value="latest">آخر التحديثات</option>
                <option value="days">الأطول احتجازاً</option>
                <option value="sources">الأكثر وثائق ومصادر</option>
              </select>
            </div>

          </div>

          {/* Active Results Summary */}
          <div className="flex items-center justify-between mt-6 pt-4 border-t border-stone-100 text-xs text-stone-500">
            <span>
              تم العثور على <strong className="text-stone-900 font-bold">{filteredCases.length}</strong> قضية تطابق شروط البحث
            </span>

            {(searchTerm || statusFilter !== 'all' || countryFilter !== 'all' || typeFilter !== 'all') && (
              <button
                onClick={resetFilters}
                className="text-[#0B5145] font-semibold hover:underline cursor-pointer"
              >
                إعادة ضبط عوامل التصفية
              </button>
            )}
          </div>

        </div>

        {/* Big Documentary Cases List */}
        {filteredCases.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-stone-200">
            <FileText className="w-12 h-12 text-stone-300 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-stone-800 mb-1">لم نعثر على قضايا مطابقة</h3>
            <p className="text-stone-500 text-xs max-w-sm mx-auto mb-4">
              جرّب تغيير كلمات البحث أو إعادة ضبط خيارات التصفية للدول والحالات.
            </p>
            <button
              onClick={resetFilters}
              className="px-4 py-2 bg-[#0B5145] text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              عرض جميع القضايا
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredCases.map((caseItem) => {
              const isUrgent = caseItem.status === 'urgent';
              const isVerified = caseItem.status === 'verified';

              return (
                <div
                  key={caseItem.id}
                  className="bg-white rounded-3xl border border-stone-200/80 p-6 sm:p-8 shadow-sm hover:shadow-md transition-all grid grid-cols-1 lg:grid-cols-12 gap-6 items-center text-right"
                >
                  
                  {/* Photo area */}
                  <div className="lg:col-span-3 aspect-[4/3] rounded-2xl overflow-hidden bg-stone-900 relative shadow-sm">
                    <img
                      src={caseItem.image}
                      alt={caseItem.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <span className="absolute bottom-2.5 right-2.5 text-xs font-mono font-bold text-white bg-black/50 px-2 py-0.5 rounded">
                      {caseItem.id}
                    </span>
                  </div>

                  {/* Case Content */}
                  <div className="lg:col-span-6 flex flex-col justify-between">
                    <div>
                      {/* Status & Country line */}
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold ${
                          isUrgent ? 'bg-rose-100 text-rose-800' : isVerified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {isUrgent ? '● عاجلة' : isVerified ? '● موثقة' : '● قيد التحقق'}
                        </span>
                        
                        <span className="text-xs text-stone-500 flex items-center gap-1 font-medium">
                          <MapPin className="w-3.5 h-3.5 text-stone-400" />
                          {caseItem.country} · {caseItem.city}
                        </span>
                      </div>

                      <h3 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar mb-2">
                        {caseItem.name}
                      </h3>

                      <p className="text-xs sm:text-sm text-stone-600 line-clamp-2 leading-relaxed mb-4">
                        {caseItem.summary}
                      </p>

                      {/* Evidence & Numbers summary */}
                      <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-stone-500">
                        <span>{caseItem.stats.sourcesCount} مصادر</span>
                        <span>·</span>
                        <span>{caseItem.stats.documentsCount} وثائق</span>
                        <span>·</span>
                        <span>{caseItem.stats.updatesCount} تحديثات</span>
                        {caseItem.detentionDays && (
                          <>
                            <span>·</span>
                            <span className="text-stone-800 font-bold">محتجز منذ {caseItem.detentionDays} يوماً</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions Column */}
                  <div className="lg:col-span-3 flex flex-col sm:flex-row lg:flex-col justify-between items-end gap-3 pt-4 lg:pt-0 border-t lg:border-t-0 lg:border-r border-stone-100 lg:pr-6">
                    <div className="text-right w-full">
                      <span className="text-[11px] text-stone-400 font-mono block">آخر تحديث</span>
                      <span className="text-xs font-bold text-[#0B5145]">{caseItem.lastUpdated}</span>
                    </div>

                    <button
                      onClick={() => onOpenCase(caseItem.id)}
                      className="w-full bg-[#0B5145] hover:bg-[#083B32] text-white text-xs sm:text-sm font-semibold py-3 px-5 rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>فتح الملف</span>
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
};
