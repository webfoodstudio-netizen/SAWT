import React, { useState } from 'react';
import { CaseItem, VerificationStage, Language } from '../types';
import { 
  ArrowRight, 
  Share2, 
  FileText, 
  Shield, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  Scale, 
  Megaphone, 
  Download, 
  Printer, 
  Eye, 
  Lock, 
  Sparkles, 
  ExternalLink,
  MessageSquare,
  Bot
} from 'lucide-react';
import { generateQrSvgPath } from '../utils/qrCode';

interface CaseDossierViewProps {
  caseItem: CaseItem;
  onBack: () => void;
  onShare: (item: CaseItem) => void;
  onSubmitTip: (caseId: string) => void;
  onOpenCampaign: (campaignId?: string) => void;
  onOpenAiAssistant: (caseItem: CaseItem) => void;
  language: Language;
}

export const CaseDossierView: React.FC<CaseDossierViewProps> = ({
  caseItem,
  onBack,
  onShare,
  onSubmitTip,
  onOpenCampaign,
  onOpenAiAssistant,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'timeline' | 'evidence' | 'actions'>('overview');
  const [showAiModal, setShowAiModal] = useState(false);
  const [aiAssistantTab, setAiAssistantTab] = useState<'summary' | 'cross_exam' | 'translation' | 'petition'>('summary');
  const [copiedAiText, setCopiedAiText] = useState(false);
  const qrDataUrl = generateQrSvgPath(window.location.origin + '#/case/' + caseItem.id, 180);

  const stages: { key: VerificationStage; label: string }[] = [
    { key: 'received', label: 'استلام' },
    { key: 'initial_review', label: 'مراجعة أولية' },
    { key: 'evidence_collection', label: 'أدلة' },
    { key: 'cross_referencing', label: 'مقارنة' },
    { key: 'verification', label: 'تحقق' },
    { key: 'human_review', label: 'مراجعة بشرية' },
    { key: 'published', label: 'نشر' },
  ];

  // Helper to find index of current stage
  const currentStageIndex = stages.findIndex(s => s.key === caseItem.verificationStage) !== -1
    ? stages.findIndex(s => s.key === caseItem.verificationStage)
    : (caseItem.status === 'verified' ? 6 : 4);

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAiText(true);
    setTimeout(() => setCopiedAiText(false), 2000);
  };

  return (
    <div className="bg-[#F5F3EE] min-h-screen pb-20">
      
      {/* Top Breadcrumb & Action Bar */}
      <div className="bg-white border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-wrap items-center justify-between gap-4">
          
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-sm font-semibold text-stone-700 hover:text-[#0B5145] transition-colors cursor-pointer"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة إلى الأرشيف</span>
          </button>

          <div className="flex items-center gap-2">
            
            {/* AI Research Helper Button */}
            <button
              onClick={() => {
                setShowAiModal(true);
                if (onOpenAiAssistant) onOpenAiAssistant(caseItem);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-[#0B5145] bg-[#0B5145]/10 hover:bg-[#0B5145]/20 transition-colors cursor-pointer border border-[#0B5145]/20 shadow-xs"
              title="مساعد الذكاء الاصطناعي للتحقيق والتلخيص والترجمة"
            >
              <Bot className="w-4 h-4 text-[#0B5145]" />
              <span>مساعد التحقيق الذكي</span>
            </button>

            {/* Print / Export button */}
            <button
              onClick={() => window.print()}
              className="p-2 rounded-lg text-stone-600 hover:text-[#0B5145] hover:bg-stone-100 transition-colors cursor-pointer"
              title="طباعة ملف القضية (Press Kit)"
            >
              <Printer className="w-4 h-4" />
            </button>

            {/* Share button */}
            <button
              onClick={() => onShare(caseItem)}
              className="inline-flex items-center gap-1.5 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-sm transition-all cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>مشاركة الملف</span>
            </button>

          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 sm:pt-10">
        
        {/* Case Dossier Header Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm mb-8 text-right">
          
          {/* Top metadata row */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-stone-100">
            <div className="flex items-center gap-3">
              <span className="text-sm font-mono font-bold px-3 py-1 rounded-md bg-[#0B5145]/10 text-[#0B5145]">
                {caseItem.id}
              </span>
              <span className="text-sm font-semibold text-stone-700">
                {caseItem.country} · {caseItem.city}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs text-stone-400 font-mono">
                آخر تحديث: {caseItem.lastUpdated}
              </span>

              {caseItem.status === 'urgent' && (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-600 text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                  عاجلة
                </span>
              )}

              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                caseItem.status === 'verified' ? 'bg-emerald-700 text-white' : 'bg-amber-600 text-white'
              }`}>
                {caseItem.status === 'verified' ? 'موثقة رسمياً' : 'قيد التحقق'}
              </span>
            </div>
          </div>

          {/* Title & Core Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mt-6">
            
            {/* Visual Column */}
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] bg-stone-900 shadow-md">
                <img
                  src={caseItem.image}
                  alt={caseItem.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-3 right-3 text-white text-xs opacity-80">
                  صورة موثقة وخاضعة لسياسة حماية الكرامة
                </div>
              </div>

              {/* Ethics policy note */}
              <div className="mt-3 p-3 rounded-xl bg-stone-50 border border-stone-200/60 text-[11px] text-stone-500 leading-relaxed">
                🛡️ <strong>معيار الحماية:</strong> تلتزم المنصة بعدم نشر أي صور عنيفة أو مهينة، ولا صور للأطفال، ولا معلومات تكشف مكان شخص معرض للخطر.
              </div>
            </div>

            {/* Content & Facts Column */}
            <div className="lg:col-span-7 flex flex-col justify-between">
              <div>
                <h1 className="text-3xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-3">
                  {caseItem.name}
                </h1>

                {caseItem.detentionDays && (
                  <div className="inline-block px-3 py-1 bg-stone-100 text-stone-800 rounded-md text-xs font-semibold mb-4">
                    محتجز منذ {caseItem.detentionDays} يوماً · تاريخ التوقيف: {caseItem.incidentDate}
                  </div>
                )}

                <p className="text-stone-700 text-sm sm:text-base leading-relaxed mb-6 font-normal">
                  {caseItem.summary}
                </p>

                {/* The Split: What We Know vs What is Under Verification */}
                <div className="space-y-4 mb-6">
                  
                  {/* Verified facts */}
                  <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80">
                    <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 mb-2">
                      <CheckCircle className="w-4 h-4 text-emerald-700" />
                      <span>ما تم التثبت منه (معطيات مدعومة بأدلة ووثائق):</span>
                    </div>
                    <ul className="space-y-1.5 pr-2">
                      {caseItem.whatWeKnow.map((fact, i) => (
                        <li key={i} className="text-xs text-emerald-950 flex items-start gap-2 leading-relaxed">
                          <span className="text-emerald-600 font-bold shrink-0">✓</span>
                          <span>{fact}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Under verification */}
                  <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-900 mb-2">
                      <AlertTriangle className="w-4 h-4 text-amber-700" />
                      <span>ما لا يزال قيد التحقق (معلومات تحتاج وثائق أو إفادات تأكيدية):</span>
                    </div>
                    <ul className="space-y-1.5 pr-2">
                      {caseItem.whatUnderVerification.map((pending, i) => (
                        <li key={i} className="text-xs text-amber-950 flex items-start gap-2 leading-relaxed">
                          <span className="text-amber-600 font-bold shrink-0">⚠️</span>
                          <span>{pending}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

              </div>

              {/* Urgent Reason Banner */}
              {caseItem.urgentReason && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-900">
                  <strong>خطر وتطور عاجل:</strong> {caseItem.urgentReason}
                </div>
              )}
            </div>

          </div>

        </div>

        {/* Story by the Numbers Bar */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/80 shadow-sm mb-8 text-center">
          <div className="text-xs font-bold text-[#0B5145] font-mono tracking-wider uppercase mb-3">
            قصة القضية بالأرقام
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 divide-y md:divide-y-0 md:divide-x md:divide-x-reverse divide-stone-100">
            
            <div className="pt-2 md:pt-0">
              <div className="text-3xl sm:text-4xl font-bold text-[#17201D] tabular-nums font-serif-ar">
                {caseItem.stats.daysCount || caseItem.detentionDays || 180}
              </div>
              <div className="text-xs text-stone-500 font-medium mt-1">يوماً في المتابعة</div>
            </div>

            <div className="pt-2 md:pt-0">
              <div className="text-3xl sm:text-4xl font-bold text-[#17201D] tabular-nums font-serif-ar">
                {caseItem.stats.sourcesCount}
              </div>
              <div className="text-xs text-stone-500 font-medium mt-1">مصادر تمت مراجعتها</div>
            </div>

            <div className="pt-2 md:pt-0">
              <div className="text-3xl sm:text-4xl font-bold text-[#17201D] tabular-nums font-serif-ar">
                {caseItem.stats.documentsCount}
              </div>
              <div className="text-xs text-stone-500 font-medium mt-1">وثائق ومستندات</div>
            </div>

            <div className="pt-2 md:pt-0">
              <div className="text-3xl sm:text-4xl font-bold text-[#17201D] tabular-nums font-serif-ar">
                {caseItem.stats.updatesCount}
              </div>
              <div className="text-xs text-stone-500 font-medium mt-1">تحديثات دورية</div>
            </div>

            <div className="pt-2 md:pt-0 col-span-2 md:col-span-1">
              <div className="text-lg sm:text-xl font-bold text-[#0B5145] font-serif-ar pt-2">
                {caseItem.lastUpdated}
              </div>
              <div className="text-xs text-stone-500 font-medium mt-1">آخر تطور رئيسي</div>
            </div>

          </div>
        </div>

        {/* Visual Verification Pipeline Progress Rail */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/80 shadow-sm mb-8 text-right">
          <div className="flex items-center justify-between mb-6">
            <div>
              <span className="text-xs font-mono font-bold text-[#0B5145]">مسار التوثيق المنهجي</span>
              <h3 className="text-lg font-bold text-[#17201D] font-serif-ar">
                مراحل التحقق من القضية
              </h3>
            </div>
            <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#0B5145]/10 text-[#0B5145]">
              المرحلة الحالية: {stages[currentStageIndex]?.label || 'المتابعة'}
            </span>
          </div>

          {/* Stepper bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
            {stages.map((stage, idx) => {
              const isPassed = idx <= currentStageIndex;
              const isCurrent = idx === currentStageIndex;

              return (
                <div
                  key={stage.key}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    isCurrent 
                      ? 'bg-[#0B5145] text-white border-[#0B5145] shadow-sm font-bold' 
                      : isPassed 
                        ? 'bg-[#0B5145]/10 text-[#0B5145] border-[#0B5145]/20 font-medium' 
                        : 'bg-stone-50 text-stone-400 border-stone-200'
                  }`}
                >
                  <div className="text-[10px] font-mono mb-1 opacity-75">0{idx + 1}</div>
                  <div className="text-xs leading-snug">{stage.label}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Section Tabs: Overview, Timeline, Evidence, Action */}
        <div className="flex items-center gap-2 border-b border-stone-200 mb-8 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'overview' ? 'bg-[#0B5145] text-white' : 'text-stone-600 hover:bg-white'
            }`}
          >
            الخط الزمني (Timeline)
          </button>
          <button
            onClick={() => setActiveTab('evidence')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'evidence' ? 'bg-[#0B5145] text-white' : 'text-stone-600 hover:bg-white'
            }`}
          >
            الأدلة والمصادر ({caseItem.evidence.length})
          </button>
          <button
            onClick={() => setActiveTab('actions')}
            className={`px-4 py-2.5 rounded-lg text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'actions' ? 'bg-[#0B5145] text-white' : 'text-stone-600 hover:bg-white'
            }`}
          >
            كيف يمكنك المساعدة؟
          </button>
        </div>

        {/* TAB 1: Chronological Timeline */}
        {activeTab === 'overview' && (
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm text-right mb-8">
            <h3 className="text-xl font-bold text-[#17201D] font-serif-ar mb-6">
              الخط الزمني الموثق للأحداث
            </h3>

            <div className="relative border-r-2 border-[#0B5145]/20 pr-6 mr-3 space-y-8">
              {caseItem.timeline.map((event, idx) => (
                <div key={event.id || idx} className="relative group">
                  {/* Timeline dot */}
                  <div className="absolute -right-[31px] top-1.5 w-4 h-4 rounded-full bg-white border-4 border-[#0B5145] shadow-sm" />

                  <div className="bg-stone-50 rounded-2xl p-5 border border-stone-200/70 hover:border-[#0B5145]/40 transition-colors">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <h4 className="text-base font-bold text-stone-900 font-serif-ar">
                        {event.title}
                      </h4>
                      <span className="text-xs font-mono font-semibold px-2.5 py-0.5 rounded bg-white text-[#0B5145] border border-stone-200">
                        {event.date}
                      </span>
                    </div>

                    <p className="text-sm text-stone-700 leading-relaxed mb-3">
                      {event.description}
                    </p>

                    {event.sourceTier && (
                      <div className="text-[11px] text-stone-500 font-mono">
                        المصدر التوثيقي: <strong className="text-stone-700">{event.sourceTier}</strong>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: Evidence Matrix & Sources */}
        {activeTab === 'evidence' && (
          <div className="space-y-6 mb-8 text-right">
            
            {/* Confidentiality Tiers Explanation Card */}
            <div className="bg-white rounded-3xl p-6 border border-stone-200/80 shadow-sm">
              <h4 className="text-sm font-bold text-[#17201D] mb-3 flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#0B5145]" />
                مستويات سرية وتصنيف الأدلة في المنصة
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                  <div className="font-bold text-emerald-900 mb-1">🟢 عام (Public)</div>
                  <p className="text-emerald-800">متاح لاطلاع الجمهور والصحفيين والباحثين بعد التحقق الكامل والتأكد من أمان النشر.</p>
                </div>
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                  <div className="font-bold text-amber-900 mb-1">🟡 داخلي (Internal)</div>
                  <p className="text-amber-800">متاح لفريق التحقيق وهيئة الدفاع القانونية فقط؛ يحتوي تفاصيل تحت الفحص المستمر.</p>
                </div>
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200">
                  <div className="font-bold text-rose-900 mb-1">🔴 حساس (Sensitive)</div>
                  <p className="text-rose-800">مشفر ومحمي تماماً (أرقام الهواتف، العناوين، أسماء الأطفال والشهود) لحماية الأرواح.</p>
                </div>
              </div>
            </div>

            {/* Evidence List */}
            <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm">
              <h3 className="text-xl font-bold text-[#17201D] font-serif-ar mb-6">
                سجل الأدلة والمستندات المفحوصة
              </h3>

              <div className="space-y-4">
                {caseItem.evidence.map((item) => {
                  const typeLabel = 
                    item.type === 'official' ? 'وثيقة رسمية' :
                    item.type === 'legal' ? 'مستند قانوني / محامي' :
                    item.type === 'testimony' ? 'إفادة / شهادة عيان' : 'تحقيق صحفي';

                  return (
                    <div 
                      key={item.id}
                      className="p-5 rounded-2xl bg-stone-50 border border-stone-200/80 hover:border-stone-300 transition-colors"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-white text-stone-800 border border-stone-200">
                            {typeLabel}
                          </span>
                          <span className="text-xs font-mono text-stone-500">
                            {item.date}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                            item.confidentiality === 'public' ? 'bg-emerald-100 text-emerald-800' :
                            item.confidentiality === 'internal' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                          }`}>
                            {item.confidentiality === 'public' ? 'عام' : item.confidentiality === 'internal' ? 'داخلي' : 'حساس مشفر'}
                          </span>

                          <span className="text-[11px] font-mono text-stone-500">
                            مستوى الثقة: {item.credibility === 'high' ? 'عالٍ جداً' : 'مراجع ومطابق'}
                          </span>
                        </div>
                      </div>

                      <h4 className="text-base font-bold text-[#17201D] mb-1">
                        {item.title}
                      </h4>

                      <p className="text-xs sm:text-sm text-stone-700 leading-relaxed mb-3">
                        <strong className="text-stone-900">ما الذي يثبته:</strong> {item.provesWhat}
                      </p>

                      {item.confidentiality === 'public' && (
                        <div className="text-xs text-[#0B5145] font-semibold flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>تم فحص المستند واعتماده من فريق التوثيق الميداني</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: What Can You Do? (Action Hub) */}
        {activeTab === 'actions' && (
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm text-right mb-8">
            <h3 className="text-2xl font-bold text-[#17201D] font-serif-ar mb-2">
              ما الذي تستطيع فعله لمساندة هذه القضية؟
            </h3>
            <p className="text-stone-600 text-sm mb-8 leading-relaxed">
              القضية ليست مجرد قراءة؛ كل خطوة عملية تسهم في كسر التعتيم وتوفير الحماية القانونية للمحتجز.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              
              {/* Action 1: Share Case */}
              <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200/70 hover:border-[#0B5145] transition-all flex flex-col justify-between">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-[#0B5145]/10 text-[#0B5145] flex items-center justify-center mb-3">
                    <Share2 className="w-5 h-5" />
                  </div>
                  <h4 className="text-base font-bold text-[#17201D] mb-1">01 — شارك القضية</h4>
                  <p className="text-xs text-stone-600 leading-relaxed mb-4">
                    انشر رابط الملف الرسمي على منصات التواصل واجعله مرجعاً موثوقاً أمام الرأي العام.
                  </p>
                </div>
                <button
                  onClick={() => onShare(caseItem)}
                  className="w-full py-2.5 px-4 bg-[#0B5145] text-white text-xs font-semibold rounded-xl hover:bg-[#083B32] transition-colors cursor-pointer"
                >
                  نسخ رابط النشر ومشاركته
                </button>
              </div>

              {/* Action 2: Submit Tip / Info */}
              <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200/70 hover:border-[#0B5145] transition-all flex flex-col justify-between">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-700 flex items-center justify-center mb-3">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <h4 className="text-base font-bold text-[#17201D] mb-1">02 — أرسل معلومة أو وثيقة</h4>
                  <p className="text-xs text-stone-600 leading-relaxed mb-4">
                    هل لديك تحديث جديد أو معلومة حول مكان الاحتجاز أو محضر رسمي يخص هذا الملف؟
                  </p>
                </div>
                <button
                  onClick={() => onSubmitTip(caseItem.id)}
                  className="w-full py-2.5 px-4 bg-amber-600 text-white text-xs font-semibold rounded-xl hover:bg-amber-700 transition-colors cursor-pointer"
                >
                  إرسال إفادة تكميلية مشفرة
                </button>
              </div>

              {/* Action 3: Join Campaign */}
              <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200/70 hover:border-[#0B5145] transition-all flex flex-col justify-between">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-700 flex items-center justify-center mb-3">
                    <Megaphone className="w-5 h-5" />
                  </div>
                  <h4 className="text-base font-bold text-[#17201D] mb-1">03 — وقّع العريضة الرسمية</h4>
                  <p className="text-xs text-stone-600 leading-relaxed mb-4">
                    انضم لآلاف الموقعين على المطلب القانوني العاجل لضمان الرعاية الصحية وحق الدفاع.
                  </p>
                </div>
                <button
                  onClick={() => onOpenCampaign(caseItem.campaignId)}
                  className="w-full py-2.5 px-4 bg-rose-600 text-white text-xs font-semibold rounded-xl hover:bg-rose-700 transition-colors cursor-pointer"
                >
                  الانضمام للحملة المرافقة
                </button>
              </div>

            </div>
          </div>
        )}

        {/* Official Case QR Code & Media Kit Section */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm text-right grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          
          <div className="md:col-span-8">
            <span className="text-xs font-mono font-bold text-[#0B5145] block mb-1">
              الملف الصحفي والترميز الرقمي
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar mb-2">
              رمز الاستجابة السريعة (QR) للقضية
            </h3>
            <p className="text-stone-600 text-sm leading-relaxed mb-4">
              يمكن استخدام هذا الرمز في المنشورات، البوسترات، التقارير الصحفية، والمؤتمرات؛ لتمكين الجمهور من الوصول المباشر والفوري إلى الملف المحدث ووثائقه المعتمدة.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <a
                href={qrDataUrl}
                download={`${caseItem.id}-qrcode.svg`}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-50 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>تحميل رمز QR بصيغة SVG عالية الدقة</span>
              </a>

              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-xs font-semibold text-stone-800 transition-colors cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>تصدير Press Kit جاهز للطباعة</span>
              </button>
            </div>
          </div>

          <div className="md:col-span-4 flex flex-col items-center justify-center p-6 bg-[#FBF9F5] rounded-2xl border border-stone-200 text-center">
            <img
              src={qrDataUrl}
              alt={`QR Code for ${caseItem.id}`}
              className="w-40 h-40 rounded-xl shadow-sm mb-2"
            />
            <span className="text-xs font-mono font-bold text-[#0B5145]">
              {caseItem.id}
            </span>
            <span className="text-[11px] text-stone-500 mt-0.5">
              امسح للوصول إلى الملف المحدث
            </span>
          </div>

        </div>

      </div>

      {/* Interactive AI Research & Verification Assistant Modal */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl text-right max-h-[90vh] flex flex-col border border-stone-200 animate-fadeIn">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-stone-100 shrink-0">
              <button
                onClick={() => setShowAiModal(false)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-600 cursor-pointer"
              >
                ✕
              </button>
              <div className="flex items-center gap-2">
                <div>
                  <h3 className="text-lg font-bold text-stone-900 font-serif-ar">
                    مساعد التحقيق الصحفي والتحليل الذكي
                  </h3>
                  <span className="text-xs text-stone-500 font-mono">
                    الملف: {caseItem.id} · {caseItem.name}
                  </span>
                </div>
                <div className="w-10 h-10 rounded-2xl bg-[#DCEBE4] text-[#0B5145] flex items-center justify-center shrink-0">
                  <Bot className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Assistant Function Tabs */}
            <div className="flex items-center gap-1.5 py-3 border-b border-stone-100 overflow-x-auto shrink-0 text-xs font-semibold">
              <button
                onClick={() => setAiAssistantTab('summary')}
                className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap ${
                  aiAssistantTab === 'summary' ? 'bg-[#0B5145] text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                ملخص تحقيقي تنفيذي
              </button>
              <button
                onClick={() => setAiAssistantTab('cross_exam')}
                className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap ${
                  aiAssistantTab === 'cross_exam' ? 'bg-[#0B5145] text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                فحص التناقضات والأدلة
              </button>
              <button
                onClick={() => setAiAssistantTab('translation')}
                className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap ${
                  aiAssistantTab === 'translation' ? 'bg-[#0B5145] text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                English UN Brief (ترجمة دولية)
              </button>
              <button
                onClick={() => setAiAssistantTab('petition')}
                className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap ${
                  aiAssistantTab === 'petition' ? 'bg-[#0B5145] text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                صياغة نداء حقوقي
              </button>
            </div>

            {/* Dynamic Content Body */}
            <div className="py-4 overflow-y-auto flex-1 text-xs text-stone-700 leading-relaxed space-y-4">
              
              {aiAssistantTab === 'summary' && (
                <div className="space-y-3 bg-[#FBF9F5] p-5 rounded-2xl border border-stone-200/80">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                    <span className="font-bold text-[#0B5145]">ملخص الوقائع القانونية المعتمدة:</span>
                    <span className="text-[10px] text-stone-400 font-mono">تدقيق صحفي معتمد</span>
                  </div>
                  <p>
                    <strong>الشخص المعني:</strong> {caseItem.name} {caseItem.alias ? `(${caseItem.alias})` : ''} — {caseItem.country} ({caseItem.city}).
                  </p>
                  <p>
                    <strong>توصيف الحالة:</strong> {caseItem.summary}
                  </p>
                  <div>
                    <strong className="block text-stone-900 mb-1">الأسانيد المؤكدة:</strong>
                    <ul className="list-disc list-inside space-y-1 text-stone-600">
                      {caseItem.whatWeKnow.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {aiAssistantTab === 'cross_exam' && (
                <div className="space-y-3 bg-[#FBF9F5] p-5 rounded-2xl border border-stone-200/80">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                    <span className="font-bold text-amber-800 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      <span>تقرير تدقيق المصادر والتناقضات:</span>
                    </span>
                    <span className="text-[10px] font-mono text-stone-400">فحص الآليات المستقلة</span>
                  </div>

                  {caseItem.contradictions && caseItem.contradictions.length > 0 ? (
                    <div className="space-y-2">
                      <p className="text-amber-900 font-medium">
                        تم رصد تباين محتمل بين مصادر الإثبات:
                      </p>
                      {caseItem.contradictions.map((c, idx) => (
                        <div key={idx} className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900">
                          {c}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>لا توجد تناقضات معلقة؛ تطابقت جميع إفادات الأسرة مع محاضر الجلسات الرسمية.</span>
                    </div>
                  )}

                  <div>
                    <strong className="block text-stone-900 mb-1">النقاط قيد الفحص التكميلي:</strong>
                    <ul className="list-disc list-inside space-y-1 text-stone-600">
                      {caseItem.whatUnderVerification.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {aiAssistantTab === 'translation' && (
                <div className="space-y-3 bg-white p-5 rounded-2xl border border-stone-200 text-left font-mono text-xs text-stone-800 leading-relaxed" dir="ltr">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-200 text-[11px] text-stone-400 font-sans">
                    <span>URGENT HUMAN RIGHTS DOSSIER</span>
                    <span>{caseItem.id}</span>
                  </div>
                  <p className="font-bold font-sans text-stone-900 text-sm">
                    SUBJECT: Arbitrary detention and fair trial concerns regarding {caseItem.name} ({caseItem.country}).
                  </p>
                  <p>
                    <strong>Summary:</strong> {caseItem.summary.slice(0, 180)}...
                  </p>
                  <p>
                    <strong>Verified Facts:</strong> Documented custody since {caseItem.incidentDate || '2026'}, holding without trial for over {caseItem.detentionDays || 120} days. Family and independent legal counsel confirm restricted medical access.
                  </p>
                  <p className="text-stone-500 text-[11px]">
                    Official verified link: {window.location.origin}/#/case/{caseItem.id}
                  </p>
                </div>
              )}

              {aiAssistantTab === 'petition' && (
                <div className="space-y-3 bg-[#FBF9F5] p-5 rounded-2xl border border-stone-200/80">
                  <span className="font-bold text-[#0B5145] block pb-1 border-b border-stone-200">
                    مسودة نداء عاجل إلى المنظمات والهيئات الحقوقية:
                  </span>
                  <div className="p-4 bg-white rounded-xl border border-stone-200 text-stone-700 leading-relaxed">
                    «نوجه هذا النداء الإنساني العاجل بخصوص {caseItem.name}، المحتجز في {caseItem.country} ({caseItem.city}) منذ أكثر من {caseItem.detentionDays || 90} يوماً. نطالب بالتدخل الفوري لتمكينه من حقه الطبيعي في الدفاع القانوني المستقل، وتوفير الرعاية الطبية اللازمة، ووقف الحبس الاحتياطي غير المبرر طبقاً للمواثيق الدولية لحقوق الإنسان.»
                  </div>
                </div>
              )}

            </div>

            {/* Modal Footer Controls */}
            <div className="pt-4 border-t border-stone-100 flex items-center justify-between shrink-0">
              <span className="text-[11px] text-stone-400">
                أداة مساعدة صحفية — تخضع لكافة معايير الميثاق التحريري
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopyText(`[ملف قضية: ${caseItem.id}] ${caseItem.name}\n${caseItem.summary}\nرابط التوثيق: ${window.location.origin}/#/case/${caseItem.id}`)}
                  className="px-4 py-2 bg-[#0B5145] hover:bg-[#083B32] text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  {copiedAiText ? '✓ تم النسخ' : 'نسخ المحتوى'}
                </button>
                <button
                  onClick={() => setShowAiModal(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
