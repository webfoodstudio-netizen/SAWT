import React from 'react';
import { CaseItem } from '../types';
import { ShieldAlert, AlertCircle, ArrowLeft, Clock, MapPin, HeartPulse, Scale, UserX } from 'lucide-react';

interface UrgentCasesViewProps {
  cases: CaseItem[];
  onOpenCase: (caseId: string) => void;
  onOpenCampaign: (campaignId?: string) => void;
}

export const UrgentCasesView: React.FC<UrgentCasesViewProps> = ({
  cases,
  onOpenCase,
  onOpenCampaign,
}) => {
  // Only genuine urgent cases
  const urgentCases = cases.filter(c => c.status === 'urgent');

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-10 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header with Strict Definition */}
        <div className="max-w-3xl mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold mb-2">
            <ShieldAlert className="w-4 h-4 text-rose-600" />
            <span>معيار الاستجابة الطارئة</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-3">
            الآن تحتاج هذه القضايا إلى الانتباه
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            لا نستخدم وسم "العاجل" إلا بضوابط صارمة: جلسة قضائية خلال 48 ساعة، خطر مثبت على الحياة أو حرمان من علاج منقذ، شخص مفقود حديثاً، أو وثيقة جوهرية مهددة بالطمس.
          </p>
        </div>

        {/* Criteria Pills Guide */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-10">
          <div className="p-3.5 rounded-2xl bg-white border border-rose-200/80 flex items-center gap-3">
            <Scale className="w-5 h-5 text-rose-600 shrink-0" />
            <div className="text-xs">
              <strong className="text-rose-950 block">جلسة خلال 48 ساعة</strong>
              <span className="text-stone-500">تحتاج حضور مراقبين قانونيين</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white border border-rose-200/80 flex items-center gap-3">
            <HeartPulse className="w-5 h-5 text-rose-600 shrink-0" />
            <div className="text-xs">
              <strong className="text-rose-950 block">خطر صحي حرج</strong>
              <span className="text-stone-500">حاجة ماسة لدواء أو رعاية طارئة</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white border border-rose-200/80 flex items-center gap-3">
            <UserX className="w-5 h-5 text-rose-600 shrink-0" />
            <div className="text-xs">
              <strong className="text-rose-950 block">شخص مفقود</strong>
              <span className="text-stone-500">ساعات أولى حرجة لتحديد المكان</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white border border-rose-200/80 flex items-center gap-3">
            <Clock className="w-5 h-5 text-rose-600 shrink-0" />
            <div className="text-xs">
              <strong className="text-rose-950 block">تطور قانوني مهم</strong>
              <span className="text-stone-500">مهلة طعن دستوري أو إحالة جنائية</span>
            </div>
          </div>
        </div>

        {/* Urgent Cases Feed */}
        <div className="space-y-6">
          {urgentCases.map((caseItem) => (
            <div
              key={caseItem.id}
              className="bg-white rounded-3xl border-2 border-rose-200 p-6 sm:p-8 shadow-sm hover:shadow-md transition-shadow grid grid-cols-1 lg:grid-cols-12 gap-6 items-center"
            >
              
              {/* Photo Area with urgent badge */}
              <div className="lg:col-span-4 relative rounded-2xl overflow-hidden aspect-[4/3] bg-stone-900 shadow">
                <img
                  src={caseItem.image}
                  alt={caseItem.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                
                <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-rose-600 text-white text-xs font-bold flex items-center gap-1.5 shadow">
                  <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                  <span>عاجل جداً</span>
                </div>

                <div className="absolute bottom-3 right-3 left-3 text-white text-xs">
                  <span className="font-mono font-bold block">{caseItem.id}</span>
                  <span>{caseItem.country} · {caseItem.city}</span>
                </div>
              </div>

              {/* Information & Urgent Callout */}
              <div className="lg:col-span-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-stone-500 mb-2 font-mono">
                    <span>آخر تحديث: {caseItem.lastUpdated}</span>
                    {caseItem.detentionDays && (
                      <span className="text-rose-700 font-bold bg-rose-50 px-2 py-0.5 rounded">
                        محتجز منذ {caseItem.detentionDays} يوماً
                      </span>
                    )}
                  </div>

                  <h3 className="text-2xl font-bold text-[#17201D] font-serif-ar mb-2">
                    {caseItem.name}
                  </h3>

                  {/* Highlighted Urgent reason */}
                  <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200/80 text-xs sm:text-sm text-rose-950 font-medium mb-4 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-700 shrink-0 mt-0.5" />
                    <span><strong>دافع الاستعجال:</strong> {caseItem.urgentReason || caseItem.summary}</span>
                  </div>

                  <p className="text-xs sm:text-sm text-stone-700 leading-relaxed line-clamp-2 mb-6">
                    {caseItem.summary}
                  </p>
                </div>

                {/* Action CTA Buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-stone-100">
                  <button
                    onClick={() => onOpenCase(caseItem.id)}
                    className="flex-1 bg-rose-700 hover:bg-rose-800 text-white font-semibold text-xs sm:text-sm py-3 px-6 rounded-xl shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>فتح الملف والاطلاع على الأدلة</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>

                  {caseItem.campaignId && (
                    <button
                      onClick={() => onOpenCampaign(caseItem.campaignId)}
                      className="px-5 py-3 rounded-xl border border-stone-300 hover:bg-stone-50 text-xs sm:text-sm font-semibold text-stone-800 transition-colors cursor-pointer"
                    >
                      متابعة العريضة والحملة
                    </button>
                  )}
                </div>

              </div>

            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
