import React, { useState } from 'react';
import { FUND_METRICS } from '../data/mockData';
import { ShieldCheck, Heart, PieChart, FileText, CheckCircle2, DollarSign, ArrowLeft } from 'lucide-react';

export const FundView: React.FC = () => {
  const [donationAmount, setDonationAmount] = useState<number>(50);
  const [selectedPurpose, setSelectedPurpose] = useState<string>('legal');
  const [donated, setDonated] = useState(false);

  const handleSimulateDonation = (e: React.FormEvent) => {
    e.preventDefault();
    setDonated(true);
    setTimeout(() => setDonated(false), 3000);
  };

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-10 sm:py-16">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header */}
        <div className="max-w-3xl mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0B5145]/10 text-[#0B5145] text-xs font-bold mb-2">
            <Heart className="w-4 h-4" />
            <span>التضامن الحقوقي الممنهج</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-3">
            صندوق صوت المظلوم للتضامن والعدالة
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            صندوق مخصص لتغطية التكاليف القانونية، رسوم المحاكم والطعون، ترجمة المحاضر، وتوفير الرعاية الطبية الطارئة للمعتقلين وأسرهم وفق حوكمة مالية خاضعة لتدقيق محاسبي دوري مستقل.
          </p>
        </div>

        {/* 3 Core Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mb-10">
          
          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm">
            <span className="text-xs text-stone-500 font-mono block mb-1">إجمالي التبرعات المحصلة</span>
            <div className="text-3xl font-bold text-[#0B5145] font-mono tabular-nums">
              ${FUND_METRICS.totalRaised.toLocaleString()}
            </div>
            <span className="text-[11px] text-stone-400 mt-1 block">تغطية تبرعات فردية ومؤسسية مستقلة</span>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm">
            <span className="text-xs text-stone-500 font-mono block mb-1">إجمالي المصروفات المنفذة</span>
            <div className="text-3xl font-bold text-stone-900 font-mono tabular-nums">
              ${FUND_METRICS.totalSpent.toLocaleString()}
            </div>
            <span className="text-[11px] text-stone-400 mt-1 block">أتعاب محامين ورسوم تقاضٍ وترجمة</span>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm">
            <span className="text-xs text-stone-500 font-mono block mb-1">عدد الحالات المدعومة قانونياً</span>
            <div className="text-3xl font-bold text-emerald-700 font-mono tabular-nums">
              {FUND_METRICS.casesSupported}
            </div>
            <span className="text-[11px] text-stone-400 mt-1 block">ملف إنساني تم تقديم العون له</span>
          </div>

        </div>

        {/* Expenses Breakdown */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm mb-10">
          <h2 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar mb-6 flex items-center gap-2">
            <PieChart className="w-5 h-5 text-[#0B5145]" />
            <span>أين تذهب أموال الصندوق؟ (الشفافية المالية)</span>
          </h2>

          <div className="space-y-4">
            {FUND_METRICS.breakdown.map((item, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-stone-50 border border-stone-200/70">
                <div className="flex flex-wrap items-center justify-between text-xs sm:text-sm font-semibold text-stone-800 mb-2">
                  <span>{item.title}</span>
                  <span className="font-mono text-[#0B5145] font-bold">
                    ${item.amount.toLocaleString()} ({item.percentage}%)
                  </span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-stone-200 overflow-hidden mb-1">
                  <div
                    className="h-full bg-[#0B5145] rounded-full"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
                <div className="text-[11px] text-stone-500 font-mono">
                  تم دعم {item.count} تدخلاً في هذا الباب
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Audited Reports Ledger */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm mb-10">
          <h2 className="text-xl sm:text-2xl font-bold text-[#17201D] font-serif-ar mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#0B5145]" />
            <span>تقارير الامتثال والتدقيق المحاسبي المستقل</span>
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed mb-6">
            تخضع جميع المعاملات المالية للصندوق لمراجعة ربع سنوية من مكاتب تدقيق محاسبي دولية مستقلة في جنيف، لضمان عدم توجيه أي قرش إلا للأغراض الإنسانية والقانونية المشروعة.
          </p>

          <div className="divide-y divide-stone-100 border border-stone-200 rounded-2xl overflow-hidden">
            {FUND_METRICS.audits.map((a, i) => (
              <div key={i} className="p-4 bg-stone-50/50 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div>
                  <strong className="text-stone-900 block font-serif-ar text-sm">{a.period}</strong>
                  <span className="text-stone-500">{a.firm} · تاريخ الاعتماد: {a.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded bg-emerald-100 text-emerald-800 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {a.status}
                  </span>
                  <button
                    onClick={() => alert(`جاري تحميل تقرير التدقيق المالي المعتمد لـ (${a.period})...`)}
                    className="px-3 py-1 rounded border border-stone-300 text-stone-700 hover:bg-stone-100 cursor-pointer"
                  >
                    تنزيل التقرير (PDF)
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Donation Interface */}
        <div className="bg-[#0B5145] text-white rounded-3xl p-6 sm:p-10 shadow-lg text-right">
          <div className="max-w-2xl">
            <h3 className="text-2xl font-bold font-serif-ar mb-2 text-white">
              المساهمة في تمويل مرافعة قانونية أو ترجمة ملف
            </h3>
            <p className="text-stone-200 text-xs sm:text-sm leading-relaxed mb-6">
              تصل مساهمتك مباشرة إلى هيئة الدفاع المعتمدة عن المعتقل أو لسداد رسوم توثيق المحاضر في النيابات.
            </p>

            {donated ? (
              <div className="p-6 bg-white/10 rounded-2xl border border-white/20 text-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-300 mx-auto mb-2" />
                <h4 className="text-lg font-bold text-white mb-1">شكراً لمساهمتك الكريمة</h4>
                <p className="text-xs text-stone-200">تم تسجيل التعهد وسيتم إرسال إيصال التبرع المعتمد لبريدك.</p>
              </div>
            ) : (
              <form onSubmit={handleSimulateDonation} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-2">
                    المبلغ (USD):
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {[25, 50, 100, 250, 500].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setDonationAmount(amt)}
                        className={`px-4 py-2 rounded-xl text-xs font-mono font-bold cursor-pointer transition-colors ${
                          donationAmount === amt 
                            ? 'bg-white text-[#0B5145]' 
                            : 'bg-white/15 text-white hover:bg-white/25'
                        }`}
                      >
                        ${amt}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-2">
                    تخصيص التبرع:
                  </label>
                  <select
                    value={selectedPurpose}
                    onChange={(e) => setSelectedPurpose(e.target.value)}
                    className="w-full sm:w-80 p-2.5 rounded-xl bg-white text-stone-900 text-xs font-semibold focus:outline-none"
                  >
                    <option value="legal">أتعاب ورسوم المحاماة المستقلة</option>
                    <option value="translation">ترجمة المحاضر والعرائض للأمم المتحدة</option>
                    <option value="medical">رعاية طبية عاجلة ودواء للمحتجزين</option>
                    <option value="general">حيثما تكون الحاجة أكثر إلحاحاً</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="px-8 py-3 bg-white text-[#0B5145] hover:bg-stone-100 font-bold text-xs sm:text-sm rounded-xl shadow transition-all cursor-pointer"
                >
                  تأكيد المساهمة الشفافة (${donationAmount})
                </button>
              </form>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
