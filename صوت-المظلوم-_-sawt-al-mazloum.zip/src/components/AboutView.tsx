import React from 'react';
import { Shield, Eye, Lock, RefreshCw, Users, FileCheck, Scale } from 'lucide-react';

export const AboutView: React.FC = () => {
  const pillars = [
    { title: 'نوثق', desc: 'نرصد الوقائع فور حدوثها ونسجل السرديات المادية بأرقام وتواريخ قابلة للمراجعة.' },
    { title: 'نتحقق', desc: 'نطابق أصل المستندات والمحاضر وندقق الأختام والشهادات قبل نشر أي سطر.' },
    { title: 'نحمي', desc: 'نضع سلامة المعتقلين وعائلاتهم والشهود فوق أي سبق أو ضجيج إعلامي.' },
    { title: 'نوصل', desc: 'نربط الملفات الموثقة بشبكة المحامين والمنظمات الدولية ووسائل الإعلام المستقلة.' },
    { title: 'نتابع', desc: 'القضية ليست خبراً يُمحى؛ نظل نحدث الملف يوماً بيوم حتى رفع المظلمة كاملة.' },
  ];

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-12 sm:py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header: Why does it exist? */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold uppercase text-[#0B5145] tracking-widest block mb-2">
            الهوية والرسالة
          </span>
          <h1 className="text-3xl sm:text-5xl font-bold text-[#17201D] font-serif-ar mb-4">
            لماذا وُجد صوت المظلوم؟
          </h1>
          <p className="text-stone-600 text-sm sm:text-lg leading-relaxed">
            وُجدت المنصة لأن مئات القضايا الإنسانية في العالم العربي تُدفن في الصمت أو تُبتذل في الجدل العابر. نحن نؤمن أن القضية ليست منشوراً للتفاعل؛ القضية ملف إنساني حيّ يستحق التوثيق والعدالة.
          </p>
        </div>

        {/* 5 Operational Actions */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-16">
          {pillars.map((p, idx) => (
            <div key={idx} className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm text-center">
              <span className="text-xs font-mono text-[#0B5145] font-bold block mb-1">0{idx + 1}</span>
              <h3 className="text-lg font-bold text-[#17201D] font-serif-ar mb-1">{p.title}</h3>
              <p className="text-[11px] text-stone-600 leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>

        {/* Vision & Methodology */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-stone-200/80 shadow-sm mb-12 space-y-8">
          <div>
            <h2 className="text-2xl font-bold text-[#17201D] font-serif-ar mb-3 flex items-center gap-2">
              <Eye className="w-5 h-5 text-[#0B5145]" />
              <span>رؤيتنا</span>
            </h2>
            <p className="text-stone-700 text-sm sm:text-base leading-relaxed">
              أن يمتلك كل إنسان مظلوم في العالم العربي ملفاً توثيقياً محترماً، مدعماً بالحقائق والأدلة، محصناً ضد التشويه والنسيان، ومتاحاً لمن يستطيع تقديم العون القانوني أو الإنساني.
            </p>
          </div>

          <div className="pt-6 border-t border-stone-100">
            <h2 className="text-2xl font-bold text-[#17201D] font-serif-ar mb-3 flex items-center gap-2">
              <Scale className="w-5 h-5 text-[#0B5145]" />
              <span>منهجنا الأخلاقي والمهني</span>
            </h2>
            <p className="text-stone-700 text-sm sm:text-base leading-relaxed">
              نحن جهة توثيق واستقصاء مستقلة تماماً، لا تتبع أي حزب سياسي أو حكومة أو تيار أيديولوجي. مرجعنا الوحيد هو العدل، كرامة الإنسان، وحكم القانون الدولي لحقوق الإنسان.
            </p>
          </div>
        </div>

        {/* Policies: Corrections & Data Protection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-700 flex items-center justify-center mb-4">
              <RefreshCw className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-stone-900 font-serif-ar mb-2">
              سياسة التصحيح العلني
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              إذا ثبت عدم دقة أي معلومة نشرتها المنصة، نعلن التصحيح بشكل صريح في الصفحة ذاتها وفي سجل التعديلات مع ذكر سبب الخطأ. الشفافية ركيزة مصداقيتنا.
            </p>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-[#0B5145]/10 text-[#0B5145] flex items-center justify-center mb-4">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-stone-900 font-serif-ar mb-2">
              سياسة حماية البيانات والضحايا
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              نستخدم خوادم مشفرة وقنوات تواصل لا تسجل بيانات IP أو عناوين المتعاملين. لا نكشف أسماء الشهود أو بيانات الأطفال أو مواقع الإقامة الآمنة تحت أي ظرف.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};
