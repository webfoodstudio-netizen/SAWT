import React, { useState } from 'react';
import { CampaignItem } from '../types';
import { Megaphone, Users, Share2, CheckCircle2, ArrowLeft, Shield, AlertCircle } from 'lucide-react';

interface CampaignsViewProps {
  campaigns: CampaignItem[];
  onOpenCase: (caseId: string) => void;
  onShareCampaign: (campaign: CampaignItem) => void;
}

export const CampaignsView: React.FC<CampaignsViewProps> = ({
  campaigns,
  onOpenCase,
  onShareCampaign,
}) => {
  const [signedCampaigns, setSignedCampaigns] = useState<Record<string, boolean>>({});
  const [signingModalCampaign, setSigningModalCampaign] = useState<CampaignItem | null>(null);
  const [signerName, setSignerName] = useState('');
  const [signerEmail, setSignerEmail] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signingModalCampaign) return;
    setSignedCampaigns(prev => ({ ...prev, [signingModalCampaign.id]: true }));
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setSigningModalCampaign(null);
      setSignerName('');
      setSignerEmail('');
    }, 1800);
  };

  return (
    <div className="bg-[#F5F3EE] min-h-screen py-10 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        
        {/* Header */}
        <div className="max-w-3xl mb-8">
          <span className="text-xs font-mono font-bold uppercase text-[#0B5145] tracking-widest block mb-1">
            المناصرة السلمية الموجهة
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#17201D] font-serif-ar mb-3">
            حملات مرتبطة بقضايا موثقة
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            لا نطلق حملات عامة أو شعارات مبهمة؛ كل حملة على المنصة مرتبطة بملف إنساني محدد، بمطلب قانوني واقعي، وتهدف للتأثير السلمي المباشر لدى الهيئات المعنية.
          </p>
        </div>

        {/* Campaign Cards List */}
        <div className="space-y-8">
          {campaigns.map((camp) => {
            const hasSigned = !!signedCampaigns[camp.id];
            const currentParticipants = camp.participantsCount + (hasSigned ? 1 : 0);
            const percentage = Math.min(100, Math.round((currentParticipants / camp.targetCount) * 100));

            return (
              <div
                key={camp.id}
                className="bg-white rounded-3xl border border-stone-200/80 p-6 sm:p-10 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center"
              >
                
                {/* Photo area */}
                <div className="lg:col-span-4 relative rounded-2xl overflow-hidden aspect-[4/3] bg-stone-900 shadow">
                  <img
                    src={camp.image}
                    alt={camp.caseName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  
                  <div className="absolute top-3 right-3 px-3 py-1 rounded-md bg-white/90 text-[#0B5145] font-mono text-xs font-bold">
                    حملة {camp.caseCode}
                  </div>

                  <div className="absolute bottom-3 right-3 left-3 text-white text-xs">
                    <span className="font-bold text-sm block font-serif-ar">{camp.caseName}</span>
                    <span className="text-stone-300">{camp.country}</span>
                  </div>
                </div>

                {/* Campaign Core Content */}
                <div className="lg:col-span-8 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-mono font-bold text-[#0B5145] bg-[#0B5145]/10 px-2.5 py-0.5 rounded">
                        {camp.id}
                      </span>
                      <span className="text-xs text-stone-500">حملة سلمية نشطة</span>
                    </div>

                    <h2 className="text-2xl font-bold text-[#17201D] font-serif-ar mb-3">
                      {camp.title}
                    </h2>

                    {/* Specific Demand Box */}
                    <div className="p-4 rounded-2xl bg-[#F5F3EE] border border-stone-200 mb-6">
                      <span className="text-xs font-bold text-stone-800 block mb-1">
                        المطلب القانوني والإنساني المحدد:
                      </span>
                      <p className="text-xs sm:text-sm text-stone-700 leading-relaxed font-medium">
                        "{camp.demand}"
                      </p>
                    </div>

                    {/* Progress Bar & Numerical Metrics */}
                    <div className="space-y-2 mb-6">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="text-stone-500">
                          الهدف: <strong className="text-stone-900 tabular-nums">{camp.targetCount.toLocaleString()} توقيع</strong>
                        </span>
                        <span className="text-[#0B5145] font-bold tabular-nums">
                          {currentParticipants.toLocaleString()} مشارك ({percentage}%)
                        </span>
                      </div>

                      {/* Progress bar line */}
                      <div className="w-full h-3 rounded-full bg-stone-100 overflow-hidden">
                        <div
                          className="h-full bg-[#0B5145] rounded-full transition-all duration-500"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-stone-400 font-mono pt-1">
                        <span>{camp.sharesCount.toLocaleString()} مشاركة مجتمعية</span>
                        <span>تأثير قانوني مباشر</span>
                      </div>
                    </div>

                    {/* Campaign Updates */}
                    {camp.updates.length > 0 && (
                      <div className="mb-6 border-t border-stone-100 pt-3">
                        <span className="text-xs font-bold text-stone-600 block mb-1.5">
                          آخر تطور للحملة:
                        </span>
                        <div className="text-xs text-stone-700 flex items-start gap-1.5">
                          <span className="text-[#0B5145] font-bold">•</span>
                          <span>{camp.updates[0]}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Action Controls */}
                  <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-stone-100">
                    {hasSigned ? (
                      <div className="px-5 py-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm font-bold flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>تم تسجيل توقيعك بنجاح على هذا المطلب</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => setSigningModalCampaign(camp)}
                        className="bg-[#0B5145] hover:bg-[#083B32] text-white font-semibold text-xs sm:text-sm py-3 px-6 rounded-xl shadow-sm transition-colors cursor-pointer"
                      >
                        توقيع العريضة والمطلب الآن
                      </button>
                    )}

                    <button
                      onClick={() => onShareCampaign(camp)}
                      className="px-4 py-3 rounded-xl border border-stone-200 text-stone-700 hover:bg-stone-50 text-xs sm:text-sm font-semibold flex items-center gap-2 transition-colors cursor-pointer"
                    >
                      <Share2 className="w-4 h-4" />
                      <span>مشاركة الحملة</span>
                    </button>

                    <button
                      onClick={() => onOpenCase(camp.caseId)}
                      className="text-xs font-bold text-[#0B5145] hover:underline mr-auto cursor-pointer"
                    >
                      مراجعة ملف القضية كاملًا والأدلة ←
                    </button>
                  </div>

                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Sign Campaign Modal */}
      {signingModalCampaign && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full text-right shadow-2xl border border-stone-200">
            <h3 className="text-xl font-bold text-[#17201D] font-serif-ar mb-2">
              التوقيع على مطلب قضية {signingModalCampaign.caseName}
            </h3>
            <p className="text-xs text-stone-600 mb-6 leading-relaxed">
              توقيعك يرسل إشعاراً حقوقياً للجهات المعنية ويعزز الموقف القانوني لهيئة الدفاع.
            </p>

            {isSuccess ? (
              <div className="p-8 text-center">
                <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto mb-3" />
                <h4 className="text-lg font-bold text-stone-900 mb-1">شكراً لتضامنك ومساندتك</h4>
                <p className="text-xs text-stone-600">تم تسجيل توقيعك وإضافته إلى العريضة الرسمية المرفوعة.</p>
              </div>
            ) : (
              <form onSubmit={handleSign} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الاسم الكامل (أو صفة التضامن)
                  </label>
                  <input
                    type="text"
                    required
                    value={signerName}
                    onChange={(e) => setSignerName(e.target.value)}
                    placeholder="مثلاً: محمد أحمد (محامٍ / مواطن / باحث)"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs sm:text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    البريد الإلكتروني (لتأكيد التوقيع ولا يُنشر علناً)
                  </label>
                  <input
                    type="email"
                    required
                    value={signerEmail}
                    onChange={(e) => setSignerEmail(e.target.value)}
                    placeholder="email@example.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs sm:text-sm focus:ring-2 focus:ring-[#0B5145] focus:outline-none"
                  />
                </div>

                <div className="p-3 bg-stone-50 rounded-xl text-[11px] text-stone-500 leading-relaxed border border-stone-200">
                  🔒 بياناتك مشفرة ومحمية وفق سياسة الخصوصية؛ لن يتم مشاركة بريدك الإلكتروني مع أي طرف خارجي.
                </div>

                <div className="flex items-center justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setSigningModalCampaign(null)}
                    className="px-4 py-2.5 text-xs font-semibold text-stone-600 hover:bg-stone-100 rounded-xl cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#0B5145] text-white text-xs sm:text-sm font-semibold rounded-xl hover:bg-[#083B32] transition-colors cursor-pointer"
                  >
                    تأكيد التوقيع
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
