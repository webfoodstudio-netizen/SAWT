export type VerificationStatus = 
  | 'verified' 
  | 'investigating' 
  | 'urgent' 
  | 'resolved'
  | 'needs_evidence'
  | 'closed';

export type CaseType = 
  | 'detention' 
  | 'disappearance' 
  | 'fair_trial' 
  | 'human_rights' 
  | 'custody_death' 
  | 'humanitarian' 
  | 'other';

export type VerificationStage = 
  | 'received'
  | 'initial_review'
  | 'evidence_collection'
  | 'cross_referencing'
  | 'verification'
  | 'human_review'
  | 'published'
  | 'followup';

export interface TimelineEvent {
  id: string;
  date: string;
  title: string;
  description: string;
  sourceTier?: string;
  source?: string;
  addedBy?: string;
  verificationLevel?: string;
  verified: boolean;
}

export type EvidenceSourceType = 'official' | 'journalistic' | 'testimony' | 'legal';
export type ConfidentialityLevel = 'public' | 'internal' | 'sensitive';

export interface EvidenceItem {
  id: string;
  title: string;
  type: EvidenceSourceType;
  date: string;
  credibility: 'high' | 'medium' | 'reviewed';
  provesWhat: string;
  confidentiality: ConfidentialityLevel;
  sourceUrl?: string;
  source?: string;
  fileName?: string;
  uploader?: string;
  uploadDate?: string;
  verificationStatus?: 'verified' | 'pending' | 'flagged';
  notes?: string;
}

export interface CaseItem {
  id: string; // e.g. CASE-EGY-0042
  name: string;
  alias?: string;
  country: string;
  countryCode: string; // EGY, TUN, MAR, YEM, SYR, etc.
  city: string;
  detentionDays?: number;
  status: VerificationStatus;
  caseType: CaseType;
  incidentDate: string;
  lastUpdated: string;
  createdDate?: string;
  image: string;
  summary: string;
  whatWeKnow: string[]; // Verified with evidence
  whatUnderVerification: string[]; // Unverified / pending
  verificationStage: VerificationStage;
  stats: {
    sourcesCount: number;
    documentsCount: number;
    updatesCount: number;
    daysCount?: number;
    affectedCount?: number;
    testimoniesCount?: number;
    legalSourcesCount?: number;
  };
  timeline: TimelineEvent[];
  evidence: EvidenceItem[];
  urgentReason?: string;
  campaignId?: string;
  legalAidStatus?: string;
  contradictions?: string[];
  researcherNotes?: string;
  riskAssessment?: 'منخفض' | 'متوسط' | 'عالي' | 'حرج';
  leadResearcher?: string;
  verificationProgress?: number; // 0 to 100 percentage
}

export interface CampaignItem {
  id: string;
  caseId: string;
  caseName: string;
  caseCode: string;
  title: string;
  demand: string;
  participantsCount: number;
  targetCount: number;
  sharesCount: number;
  country: string;
  image: string;
  active: boolean;
  updates: string[];
}

export interface LegalPartner {
  id: string;
  name: string;
  role: 'محامٍ معتمد' | 'باحث حقوقي' | 'منظمة حقوقية' | 'صحفي استقصائي' | 'مترجم قانوني';
  roleEn: string;
  country: string;
  city: string;
  bio: string;
  verifiedStatus: boolean;
  specializations: string[];
  contactMethod: string;
  activeCasesCount: number;
}

export interface SubmissionReport {
  id?: string;
  trackingId: string;
  submissionDate: string;
  country: string;
  city: string;
  caseType: CaseType;
  affectedPerson: string;
  summary: string;
  evidenceDetails: string;
  documentsCount: number;
  contactSecure: string;
  senderName?: string;
  riskLevel?: 'منخفض' | 'متوسط' | 'عالي' | 'حرج';
  hasDocuments?: boolean;
  status: 'received' | 'under_review' | 'evidence_requested' | 'verified_in_pipeline' | 'rejected';
  statusTextAr: string;
  lastUpdateDate: string;
  adminNotes?: string;
  assignedResearcher?: string;
}

export interface CountryPriority {
  code: string;
  nameAr: string;
  nameEn: string;
  totalCases: number;
  verifiedCases: number;
  investigatingCases: number;
  urgentCases: number;
  lastUpdate: string;
  priorityScore: number; // calculated dynamically
  coordinates?: { x: number; y: number };
  statusNote?: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: 'مدير المنصة' | 'باحث أول' | 'محقق أدلة' | 'محرر حقوقي' | 'مسؤول قانوني' | 'مسؤول إعلامي';
  email: string;
  avatar: string;
  permissions: string[];
  activeCasesCount: number;
  lastActive: string;
  twoFactorEnabled: boolean;
}

export interface ActivityLogItem {
  id: string;
  user: string;
  role: string;
  action: string;
  targetCaseId?: string;
  targetCaseName?: string;
  timeAgo: string;
  timestamp: string;
  category: 'document' | 'status' | 'summary' | 'pipeline' | 'verification';
}

export interface ContradictionItem {
  id: string;
  caseId: string;
  caseName: string;
  title: string;
  sourceA: string;
  sourceB: string;
  status: 'needs_human_review' | 'resolved' | 'investigating';
  detectedDate: string;
  notes: string;
}

export type AdminSection = 
  | 'dashboard'
  | 'cases'
  | 'new_cases'
  | 'investigating'
  | 'verified'
  | 'urgent'
  | 'countries'
  | 'evidence'
  | 'sources'
  | 'timeline'
  | 'campaigns'
  | 'submissions'
  | 'team'
  | 'reports'
  | 'media'
  | 'logs'
  | 'settings'
  | 'case_detail'
  | 'visual_documentation';

export type ViewType = 
  | 'home'
  | 'cases'
  | 'case_detail'
  | 'countries'
  | 'urgent'
  | 'campaigns'
  | 'verification_guide'
  | 'submit_case'
  | 'legal_network'
  | 'media_center'
  | 'charter'
  | 'about'
  | 'fund'
  | 'admin_dashboard';

export type Language = 'ar' | 'fr' | 'en';
