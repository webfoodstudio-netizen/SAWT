import { 
  CaseItem, 
  CampaignItem, 
  LegalPartner, 
  CountryPriority, 
  SubmissionReport,
  TeamMember,
  ActivityLogItem,
  ContradictionItem
} from '../types';

import heroImg from '../assets/images/hero_editorial_archive_1791207107412.jpg';
import detainedImg from '../assets/images/case_detained_silhouette_1791207118394.jpg';
import courthouseImg from '../assets/images/case_courthouse_hall_1791207130991.jpg';
import deskImg from '../assets/images/case_investigative_desk_1791207142763.jpg';

export const ASSET_IMAGES = {
  hero: heroImg,
  detained: detainedImg,
  courthouse: courthouseImg,
  investigative: deskImg,
};

export const INITIAL_CASES: CaseItem[] = [
  {
    id: 'CASE-EGY-0042',
    name: 'محمد بن سالم',
    alias: 'أبو عمر',
    country: 'مصر',
    countryCode: 'EGY',
    city: 'القاهرة',
    detentionDays: 214,
    status: 'urgent',
    caseType: 'detention',
    incidentDate: '2026-03-14',
    createdDate: '2026-03-16',
    lastUpdated: 'منذ 3 ساعات',
    image: detainedImg,
    summary: 'تم توقيف محمد بن سالم في 14 مارس 2026 من منزله، وجرى نقله إلى مكان غير معلن لأسابيع دون تمكينه من لقاء محامٍ أو توجيه لائحة اتهام واضحة، ولا يزال محتجزاً حتى الآن دون محاكمة عادلة أو تقرير طبي مستقل بشأن وضعه الصحي المتدهور.',
    whatWeKnow: [
      'وثيقة رسمية صادرة عن محكمة الجنايات تفيد باستمرار تجديد الحبس الاحتياطي دون حضور المتهم.',
      'إفادة خطية ومسجلة من عائلة المحتجز ومحاميه المقيد بالنقض تثبت منعه من الزيارة لمدة 180 يوماً.',
      'شهادة مصدر طبي مستقل تؤكد حاجته الماسة لعلاج منتظم لأمراض القلب والشريان التاجي.',
      'تقرير من منظمة حقوقية مستقلة يوثق عدم توجيه اتهامات منسوبة لأدلة مادية ملموسة.'
    ],
    whatUnderVerification: [
      'أنباء متداولة عن نقله المؤقت لمستشفى السجن قبل أسبوعين؛ لم يتم التثبت من السجلات الطبية الرسمية بعد.',
      'مزاعم عن وجود تحقيق تكميلي لدى نيابة أمن الدولة؛ جاري طلب إفادة رسمية من نقابة المحامين.'
    ],
    verificationStage: 'human_review',
    verificationProgress: 82,
    stats: {
      sourcesCount: 8,
      documentsCount: 4,
      updatesCount: 12,
      daysCount: 214,
      affectedCount: 1,
      testimoniesCount: 2,
      legalSourcesCount: 1,
    },
    urgentReason: 'جلسة تجديد حبس حاسمة خلال 48 ساعة مع تدهور شديد وموثق في حالته الصحية ومنع الدواء عنه.',
    campaignId: 'CAMP-EGY-042',
    legalAidStatus: 'تم توكيل محامٍ من شبكة الدعم بالتعاون مع هيئة الدفاع المستقلة.',
    contradictions: [
      'اختلاف في تاريخ الاعتقال: المصدر A يفيد بـ 14 مارس، بينما محضر النيابة مؤرخ بـ 16 مارس (تاريخ إثبات متأخر).'
    ],
    researcherNotes: 'الملف مستوفٍ للشروط التوثيقية من الفئة (أ). تم فحص أصل محاضر التحقيق والتأكد من بصمات الإيداع وتطابق التواريخ مع مراعاة سرية هوية الشهود.',
    riskAssessment: 'عالي',
    leadResearcher: 'سارة الشامي — باحث أول',
    timeline: [
      {
        id: 'tl-1',
        date: '14 مارس 2026',
        title: 'بداية القضية وتوقيف الشخص من منزله',
        description: 'داهمت قوة أمنية منزل محمد بن سالم في ساعات الفجر الأولى واقتادته إلى جهة مجهولة دون إبراز إذن تفتيش أو توقيف.',
        sourceTier: 'إفادة الأسرة + محضر شكوى رسمي',
        source: 'شهادة العائلة ومحضر الشكوى',
        addedBy: 'أحمد — باحث توثيق',
        verificationLevel: 'موثق قطعي',
        verified: true,
      },
      {
        id: 'tl-2',
        date: '16 مارس 2026',
        title: 'وصلت إفادة الأسرة والإنذارات القضائية',
        description: 'تقدمت الأسرة ببرقيات عاجلة للنائب العام ووزارة العدل للاستفسار عن مكان احتجازه دون تلقي أي رد.',
        sourceTier: 'إيصالات البريد المستعجل',
        source: 'إيصال البريد السريع الرسمي',
        addedBy: 'سارة — باحث أول',
        verificationLevel: 'موثق قطعي',
        verified: true,
      },
      {
        id: 'tl-3',
        date: '19 مارس 2026',
        title: 'تم التواصل مع المحامي وهيئة الدفاع',
        description: 'جرى توثيق البلاغ رسمياً لدى غرفة التوثيق الحقوقية وتوكيل محامٍ معتمد لمتابعة النيابات.',
        sourceTier: 'سجلات شبكة المساعدة',
        source: 'توكيل رسمي مصدق',
        addedBy: 'طارق — مسؤول قانوني',
        verificationLevel: 'موثق',
        verified: true,
      },
      {
        id: 'tl-4',
        date: '25 مارس 2026',
        title: 'إضافة وثيقة رسمية وظهور المحتجز في جلسة مغلقة',
        description: 'عُرض على النيابة دون إخطار محاميه الموكل، وجرى التحقيق معه في غياب أي سند قانوني.',
        sourceTier: 'محضر نيابة رسمي',
        source: 'محضر جلسة رقم 1408',
        addedBy: 'أحمد — باحث توثيق',
        verificationLevel: 'موثق قطعي',
        verified: true,
      },
      {
        id: 'tl-5',
        date: '02 أبريل 2026',
        title: 'مراجعة مصدر مستقل ومقارنة البيانات',
        description: 'تمت مطابقة البيانات مع سجلات نقابة المحامين وملاحظات مراقب حقوقي مستقل حضر في مقر المحكمة.',
        sourceTier: 'مراقب حقوقي مستقل',
        source: 'تقرير مراقبة المحاكمات',
        addedBy: 'مروان — محقق أدلة',
        verificationLevel: 'موثق',
        verified: true,
      },
      {
        id: 'tl-6',
        date: '05 أكتوبر 2026',
        title: 'آخر تحديث: نداء عاجل لمقرري الأمم المتحدة',
        description: 'إطلاق نداء عاجل لإدخال أدوية القلب وإحالة الملف للمقرر الخاص المعني بالاحتجاز التعسفي في الأمم المتحدة.',
        sourceTier: 'بيان هيئة الدفاع',
        source: 'مذكرة المقررين الخواص',
        addedBy: 'سارة — باحث أول',
        verificationLevel: 'موثق',
        verified: true,
      }
    ],
    evidence: [
      {
        id: 'ev-1',
        title: 'محضر توقيف وقرار تجديد حبس رسمي',
        type: 'official',
        date: '2026-03-25',
        credibility: 'high',
        provesWhat: 'يثبت واقعة الاحتجاز وتاريخ التوقيف وتجديد الحبس دون توجيه تهمة جنائية واضحة.',
        confidentiality: 'public',
        fileName: 'decision_remand_official_2026.pdf',
        uploader: 'أحمد المنصوري (مدير)',
        uploadDate: '2026-03-26',
        verificationStatus: 'verified',
        sourceUrl: '#'
      },
      {
        id: 'ev-2',
        title: 'إفادة مسجلة وموثقة بالشهر العقاري من المحامي المعتمد',
        type: 'legal',
        date: '2026-04-05',
        credibility: 'high',
        provesWhat: 'تثبت منع الدفاع من تصوير أوراق القضية ومنع حضور التحقيقات الأولية.',
        confidentiality: 'public',
        fileName: 'legal_affidavit_counsel.pdf',
        uploader: 'طارق عبد الرؤوف (قانوني)',
        uploadDate: '2026-04-06',
        verificationStatus: 'verified',
        sourceUrl: '#'
      },
      {
        id: 'ev-3',
        title: 'تقرير طبي صادر عن مستشفى جامعي عام',
        type: 'official',
        date: '2025-11-20',
        credibility: 'high',
        provesWhat: 'يثبت إصابة المحتجز بقصور الشريان التاجي والحاجة لدواء يومي لا ينقطع.',
        confidentiality: 'public',
        fileName: 'cardiac_medical_report.pdf',
        uploader: 'سارة الشامي (باحث أول)',
        uploadDate: '2026-03-28',
        verificationStatus: 'verified',
        sourceUrl: '#'
      },
      {
        id: 'ev-4',
        title: 'إفادة مباشرة من شاهد عيان حضر واقعة المداهمة',
        type: 'testimony',
        date: '2026-03-15',
        credibility: 'reviewed',
        provesWhat: 'تثبت عدم وجود إذن قضائي وتجريد المنزل من أجهزة الاتصال ومقتنيات شخصية.',
        confidentiality: 'internal',
        fileName: 'witness_statement_redacted.wav',
        uploader: 'مروان البوعزيزي (محقق)',
        uploadDate: '2026-03-17',
        verificationStatus: 'verified',
      },
      {
        id: 'ev-5',
        title: 'تحقيق صحفي استقصائي منشور في منصة مستقلة',
        type: 'journalistic',
        date: '2026-05-12',
        credibility: 'high',
        provesWhat: 'يوثق تكرار نمط الاحتجاز المشابه لـ 14 شخصاً في نفس المنطقة.',
        confidentiality: 'public',
        fileName: 'investigative_journalism_case42.pdf',
        uploader: 'ياسمين حداد (محرر)',
        uploadDate: '2026-05-14',
        verificationStatus: 'verified',
        sourceUrl: '#'
      }
    ]
  },
  {
    id: 'CASE-TUN-0014',
    name: 'فاطمة الزهراء البوعزيزي',
    alias: 'أمينة',
    country: 'تونس',
    countryCode: 'TUN',
    city: 'تونس العاصمة',
    detentionDays: 78,
    status: 'investigating',
    caseType: 'disappearance',
    incidentDate: '2026-07-19',
    createdDate: '2026-07-21',
    lastUpdated: 'منذ 6 ساعات',
    image: courthouseImg,
    summary: 'اختفت الناشطة والباحثة الميدانية فاطمة الزهراء عقب مغادرتها لمقر عملها بوسط العاصمة، مع تضارب إفادات الجهات الرسمية حول توقيفها أو وجودها في أي مركز احتجاز، مما يثير مخاوف شديدة من احتجاز قسري خارج الأطر القانونية.',
    whatWeKnow: [
      'آخر ظهور مؤكد مسجل بكاميرات مراقبة على بعد 200 متر من محطة المترو بتاريخ 19 يوليو.',
      'إفادة من نقابة الصحفيين والباحثين تؤكد انقطاع هاتفها في نفس التوقيت.',
      'شكوى رسمية مقيدة لدى وكيل الجمهورية بالمحكمة الابتدائية بتونس برقم 8412/2026.'
    ],
    whatUnderVerification: [
      'مزاعم عن مشاهدتها في مركز بوشوشة للأمن؛ لم يتمكن المحامي من تأكيد السجلات حتى الآن.',
      'اتصال مجهول تلقته الأسرة يطلب التراجع عن البلاغات؛ جاري التحقق من مصدر الخط تقنياً.'
    ],
    verificationStage: 'evidence_collection',
    verificationProgress: 65,
    stats: {
      sourcesCount: 6,
      documentsCount: 2,
      updatesCount: 6,
      daysCount: 78,
      affectedCount: 1,
      testimoniesCount: 3,
      legalSourcesCount: 1,
    },
    urgentReason: 'شخص مفقود منذ أكثر من شهرين دون إقرار رسمي بمكان التواجد مع خطر على السلامة الجسدية.',
    campaignId: 'CAMP-TUN-014',
    legalAidStatus: 'تم تشكيل هيئة دفاع ثلاثية بالتنسيق مع الرابطة التونسية للدفاع عن حقوق الإنسان.',
    researcherNotes: 'الحالة تصنف ضمن حالات الاختفاء القسري المشتبه بها حتى ثبوت العكس. تم عزل أرقام هواتف الأسرة لمنع الابتزاز.',
    riskAssessment: 'حرج',
    leadResearcher: 'مروان البوعزيزي — محقق أدلة',
    timeline: [
      {
        id: 'tl-tun-1',
        date: '19 يوليو 2026',
        title: 'انقطاع الاتصال ومغادرة العمل',
        description: 'غادرت فاطمة مقر جمعية الأبحاث عند الساعة الخامسة مساءً وانقطع الاتصال بهاتفها بعد ربع ساعة.',
        verified: true,
      },
      {
        id: 'tl-tun-2',
        date: '23 يوليو 2026',
        title: 'تقديم عريضة لدى النيابة العامة',
        description: 'إيداع شكوى رسمية بشأن الاختفاء القسري والمطالبة بتفريغ تسجيلات كاميرات المراقبة.',
        verified: true,
      }
    ],
    evidence: [
      {
        id: 'ev-tun-1',
        title: 'وصل استلام عريضة وكيل الجمهورية بتونس',
        type: 'official',
        date: '2026-07-23',
        credibility: 'high',
        provesWhat: 'يثبت إخطار الدولة رسمياً بالاختفاء وتحميلها المسؤولية القانونية.',
        confidentiality: 'public',
        fileName: 'prosecutor_receipt_tunis.pdf',
        uploader: 'طارق عبد الرؤوف',
        uploadDate: '2026-07-24',
        verificationStatus: 'verified'
      }
    ]
  },
  {
    id: 'CASE-MAR-0007',
    name: 'علي العلوي',
    alias: 'الصحفي الحر',
    country: 'المغرب',
    countryCode: 'MAR',
    city: 'الرباط',
    detentionDays: 148,
    status: 'verified',
    caseType: 'fair_trial',
    incidentDate: '2026-05-10',
    createdDate: '2026-05-12',
    lastUpdated: 'منذ يوم',
    image: courthouseImg,
    summary: 'متابعة قضائية لصحفي ومدون مستقل على خلفية تحقيقات نُشرت حول تدبير صفقات عمومية، تتضمن خروقات جوهرية لمسطرة المحاكمة العادلة وحرماناً من مناقشة شهود الإثبات ورفض إجراء خبرة تقنية محايدة على أدلة الاتهام.',
    whatWeKnow: [
      'محاضر الجلسات الرسمية تبين رفض المحكمة استدعاء 4 شهود نفي رئيسيين.',
      'تقرير نقابة الصحفيين يبرز أن المواد المنشورة تندرج تحت حرية الرأي والتعبير الصحفي.',
      'وجود وثائق تثبت صحة المعطيات المنشورة من تقارير المجلس الأعلى للحسابات.'
    ],
    whatUnderVerification: [
      'مزاعم عن إضافة محاضر استماع لم يُوقع عليها المعني بالأمر؛ جاري فحص ملف القضية بمحكمة الاستئناف.'
    ],
    verificationStage: 'published',
    verificationProgress: 94,
    stats: {
      sourcesCount: 12,
      documentsCount: 5,
      updatesCount: 14,
      daysCount: 148,
      affectedCount: 1,
      testimoniesCount: 4,
      legalSourcesCount: 2,
    },
    campaignId: 'CAMP-MAR-007',
    legalAidStatus: 'هيئة الدفاع تضم 6 محامين مع إيداع مذكرة طعن لدى المجلس الاستشاري.',
    researcherNotes: 'القضية مدعمة بأدلة ورقية صلبة. تم تفريغ كافة محاضر جلسات المحكمة الابتدائية.',
    riskAssessment: 'متوسط',
    leadResearcher: 'ياسمين حداد — محرر حقوقي',
    timeline: [
      {
        id: 'tl-mar-1',
        date: '10 مايو 2026',
        title: 'استدعاء واستنطاق أولي',
        description: 'الاستماع لعلي العلوي لدى الفرقة الوطنية للشرطة القضائية.',
        verified: true,
      },
      {
        id: 'tl-mar-2',
        date: '15 يونيو 2026',
        title: 'انطلاق الجلسات ورفض الدفوع الشكلية',
        description: 'المحكمة ترفض كافة الدفوع الشكلية المتعلقة ببطلان المحاضر.',
        verified: true,
      }
    ],
    evidence: [
      {
        id: 'ev-mar-1',
        title: 'محاضر الجلسات العلنية بالمحكمة الابتدائية بالرباط',
        type: 'official',
        date: '2026-06-15',
        credibility: 'high',
        provesWhat: 'تثبت رفض المحكمة لطلبات السراح وتجاهل شهود النفي.',
        confidentiality: 'public',
        fileName: 'court_minutes_rabat.pdf',
        uploader: 'طارق عبد الرؤوف',
        uploadDate: '2026-06-16',
        verificationStatus: 'verified'
      }
    ]
  },
  {
    id: 'CASE-YEM-0003',
    name: 'ملف مراكز الاحتجاز السرية في عدن',
    alias: 'معتقلو المنشآت غير الرسمية',
    country: 'اليمن',
    countryCode: 'YEM',
    city: 'عدن',
    detentionDays: 340,
    status: 'urgent',
    caseType: 'human_rights',
    incidentDate: '2025-10-30',
    createdDate: '2025-11-05',
    lastUpdated: 'منذ 4 ساعات',
    image: deskImg,
    summary: 'توثيق انتهاكات ممنهجة واحتجاز جماعي لعشرات المدنيين في منشآت غير خاضعة لسلطة النيابة العامة والقضاء في عدن، مع ورود إفادات متطابقة عن ممارسات تعذيب وحرمان تام من الرعاية الطبية.',
    whatWeKnow: [
      'تطابق إفادات 7 معتقلين سابقين حول أسماء المرافق والقائمين عليها وأساليب الاحتجاز.',
      'شهادات طبية مسجلة لمعتقلين أُفرج عنهم تظهر آثار سوء معاملة بالغة.',
      'تقارير رابطة أمهات المختطفين التي تحصر أسماء 43 محتجزاً دون مسوغ قانوني.'
    ],
    whatUnderVerification: [
      'أماكن مراكز الاحتجاز الميدانية الجديدة في الضواحي؛ يتم تدقيق صور الأقمار الاصطناعية قبل النشر.',
      'حالات وفاة غير معلنة تحت وطأة الإهمال الصحي؛ جاري مطابقة كشوف المقابر الرسمية.'
    ],
    verificationStage: 'cross_referencing',
    verificationProgress: 75,
    stats: {
      sourcesCount: 9,
      documentsCount: 7,
      updatesCount: 11,
      daysCount: 340,
      affectedCount: 43,
      testimoniesCount: 7,
      legalSourcesCount: 2,
    },
    urgentReason: 'خطر دائم على أرواح المحتجزين نظراً لتفشي الأمراض الصدرية والحرمان من الرعاية الطبية الطارئة.',
    campaignId: 'CAMP-YEM-003',
    legalAidStatus: 'تنسيق مع نقابة المحامين في عدن لتقديم عرائض جماعية للمجلس الأعلى للقضاء.',
    researcherNotes: 'تم إخفاء أسماء الشهود بالكامل وتعديل الأصوات في التسجيلات حرصاً على حياتهم وحياة ذويهم.',
    riskAssessment: 'حرج',
    leadResearcher: 'سارة الشامي — باحث أول',
    timeline: [
      {
        id: 'tl-yem-1',
        date: '30 أكتوبر 2025',
        title: 'موجة توقيفات واسعة بلا مذكرات',
        description: 'مداهمة منازل نشطاء وموظفين مدنيين في عدة مديريات بمحافظة عدن.',
        verified: true,
      }
    ],
    evidence: [
      {
        id: 'ev-yem-1',
        title: 'إفادات صوتية مشفرة لشهود عيان ومعتقلين مفرج عنهم',
        type: 'testimony',
        date: '2026-08-10',
        credibility: 'high',
        provesWhat: 'تثبت نمط المعاملة غير الإنسانية وغياب التفتيش القضائي.',
        confidentiality: 'sensitive',
        fileName: 'witness_voice_encrypted.bin',
        uploader: 'أحمد المنصوري',
        uploadDate: '2026-08-12',
        verificationStatus: 'verified'
      }
    ]
  },
  {
    id: 'CASE-SYR-0031',
    name: 'ملف توثيق مفقودي سجون النظام البائد والمقابر الجماعية',
    alias: 'شهداء ومفقودو صيدنايا وفروع المخابرات المحررة',
    country: 'سوريا',
    countryCode: 'SYR',
    city: 'دمشق / ريف دمشق / صيدنايا',
    detentionDays: 1520,
    status: 'urgent',
    caseType: 'disappearance',
    incidentDate: '2024-12-10',
    createdDate: '2024-12-15',
    lastUpdated: 'منذ ساعتين',
    image: deskImg,
    summary: 'في ظل التحول التاريخي وسقوط النظام السوري الاستبدادي البائد، يركز هذا الملف على التوثيق الجنائي والحقوقي المستقل لمصير عشرات الآلاف من المفقودين والمعتقلين في سجون صيدنايا والأفرع الأمنية المحررة، وحماية السجلات من التلف، وتوثيق المقابر الجماعية بالتعاون مع لجان عائلات الضحايا والطب الشرعي المستقل، مع استبعاد تام لكافة السجلات المزيفة التي كان يلفقها النظام البائد.',
    whatWeKnow: [
      'استرداد وتأمين سجلات ورقية ومحركات أقراص صلبة من مباني الاستخبارات المحررة في دمشق وحمص وحلب.',
      'توثيق مواقع 14 مقبرة جماعية جديدة بالتعاون مع الأهالي وخبراء الطب الجنائي المستقلين.',
      'تطابق بيانات أكثر من 1,200 عائلة مع قيود وسجلات المحتجزين المحررة حديثاً.',
      'استبعاد كامل لكشوف الوفيات المزيفة التي كانت تصدرها دوائر نفوس النظام البائد دون تسليم رفات.'
    ],
    whatUnderVerification: [
      'فحص نتائج تحاليل الحمض النووي (DNA) الجارية في مختبرات الطب الشرعي المحايدة لتحديد هويات الرفات.',
      'التحقق من ملفات الأسرى والمفقودين الذين تم ترحيلهم قسراً قبل تحرير السجون إلى مناطق نائية.'
    ],
    verificationStage: 'verification',
    verificationProgress: 88,
    stats: {
      sourcesCount: 16,
      documentsCount: 12,
      updatesCount: 22,
      daysCount: 1520,
      affectedCount: 1840,
      testimoniesCount: 14,
      legalSourcesCount: 5,
    },
    urgentReason: 'حاجة قصوى لتأمين مواقع المقابر الجماعية والسجلات المحررة وحمايتها من العبث الجوي أو المناخي لضمان حفظ حقوق الضحايا والعدالة الانتقالية.',
    campaignId: 'CAMP-SYR-031',
    leadResearcher: 'سارة الشامي — باحث أول (وحدة الشام)',
    riskAssessment: 'عالي',
    researcherNotes: 'التحقيق يعتمد حصراً على السجلات الميدانية المضبوطة، شهادات الناجين والأطباء، وفحوصات الـDNA المستقلة. نرفض اعتماد أي وثيقة صدرت عن أجهزة النظام السوري السابقة لثبوت تزويرها الممنهج لأسباب وتواريخ الوفاة.',
    timeline: [
      {
        id: 'tl-syr-1',
        date: '10 ديسمبر 2024',
        title: 'تحرير السجون وضبط أرشيف الأفرع الأمنية',
        description: 'دخول فرق التوثيق المدنية ولجان الأهالي إلى سجن صيدنايا والأفرع الأمنية والبدء بختم وتشميع غرف الأرشيف.',
        sourceTier: 'سجلات ميدانية موثقة بالفيديو',
        source: 'محاضر الضبط الميداني للأرشيف',
        addedBy: 'سارة الشامي',
        verificationLevel: 'موثق قطعي',
        verified: true,
      },
      {
        id: 'tl-syr-2',
        date: '15 مايو 2025',
        title: 'تأسيس بنك البصمة الوراثية لأهالي المفقودين',
        description: 'إطلاق حملة جمع عينات اللعاب والدم من أسر الضحايا بمطابقة معملية بإشراف خبراء دوليين مستقلين.',
        sourceTier: 'سجلات لجان الطب الشرعي المستقلة',
        source: 'بنك الـ DNA الميداني',
        addedBy: 'أحمد المنصوري',
        verificationLevel: 'موثق',
        verified: true,
      },
      {
        id: 'tl-syr-3',
        date: '05 أكتوبر 2026',
        title: 'إيداع التقرير الجنائي الشامل لدى الهيئة الأممية للمفقودين',
        description: 'تسليم سجل إلكتروني مشفر يوثق 1,840 حالة اختفاء قسري مثبتة بالوثائق الأصلية المضبوطة.',
        sourceTier: 'مذكرة رسمية للهيئة المستقلة',
        source: 'محضر إيداع جنيف الرسمي',
        addedBy: 'طارق عبد الرؤوف',
        verificationLevel: 'موثق قطعي',
        verified: true,
      }
    ],
    evidence: [
      {
        id: 'ev-syr-1',
        title: 'سجلات إيداع ودفاتر سجن صيدنايا الأصلية المضبوطة',
        type: 'official',
        date: '2024-12-12',
        credibility: 'high',
        provesWhat: 'تثبت أسماء المعتقلين وتواريخ دخولهم ومواقع الزنازين دون تلاعب.',
        confidentiality: 'internal',
        fileName: 'sednaya_liberated_registry_archive.pdf',
        uploader: 'سارة الشامي',
        uploadDate: '2024-12-14',
        verificationStatus: 'verified'
      },
      {
        id: 'ev-syr-2',
        title: 'تقارير المسح الجيولوجي ومطابقة المقابر الجماعية بالرادار المخترق للأرض (GPR)',
        type: 'legal',
        date: '2025-08-20',
        credibility: 'high',
        provesWhat: 'تحدد بدقة مواقع المدافن غير المعلنة في محيط القطيفة ونجها.',
        confidentiality: 'sensitive',
        fileName: 'gpr_radar_mass_graves_survey.pdf',
        uploader: 'مروان البوعزيزي',
        uploadDate: '2025-08-22',
        verificationStatus: 'verified'
      }
    ]
  },
  {
    id: 'CASE-SAU-0019',
    name: 'سليمان الداوود',
    alias: 'د. سليمان',
    country: 'السعودية',
    countryCode: 'SAU',
    city: 'الرياض',
    detentionDays: 412,
    status: 'verified',
    caseType: 'detention',
    incidentDate: '2025-08-19',
    createdDate: '2025-08-25',
    lastUpdated: 'منذ 5 ساعات',
    image: detainedImg,
    summary: 'أكاديمي وباحث اقتصادي محتجز على خلفية آراء استشارية ومقالات تناولت السياسات النقدية، مع استمرار حبسه في سجن الحائر دون السماح له بتوكيل محامٍ يختاره بنفسه، وتأجيل جلسات المحكمة الجزائية المتخصصة لمدد تفوق الآجال القانونية.',
    whatWeKnow: [
      'لائحة الاتهامات تقتصر على تغريدات ودراسات منشورة في دوريات علمية واقتصادية.',
      'منع الزيارة العائلية المباشرة واقتصارها على مكالمات صوتية قصيرة متباعدة.',
      'تأجيل جلسات المحاكمة 6 مرات دون إبداء مبررات موضوعية من هيئة الحكم.'
    ],
    whatUnderVerification: [
      'أنباء عن تدهور صحته بسبب السكري؛ طلبت الأسرة إشرافاً طبياً مستقلاً ولم يرد جواب حتى الآن.'
    ],
    verificationStage: 'published',
    verificationProgress: 90,
    stats: {
      sourcesCount: 8,
      documentsCount: 3,
      updatesCount: 9,
      daysCount: 412,
      affectedCount: 1,
      testimoniesCount: 2,
      legalSourcesCount: 2,
    },
    campaignId: 'CAMP-SAU-019',
    legalAidStatus: 'متابعة عبر الآليات الدولية ومراسلات الفريق العامل المعني بالاحتجاز التعسفي.',
    leadResearcher: 'أحمد المنصوري — مدير المنصة',
    riskAssessment: 'متوسط',
    timeline: [
      {
        id: 'tl-sau-1',
        date: '19 أغسطس 2025',
        title: 'الاعتقال المفاجئ من مقر السكن',
        description: 'توقيف سليمان الداوود من منزله بالرياض دون استدعاء مسبق.',
        verified: true,
      }
    ],
    evidence: [
      {
        id: 'ev-sau-1',
        title: 'دراسات وأوراق السياسات الاقتصادية موضوع الدعوى',
        type: 'journalistic',
        date: '2025-08-01',
        credibility: 'high',
        provesWhat: 'تثبت الطبيعة الأكاديمية والمهنية الصرفة للمحتوى.',
        confidentiality: 'public',
        fileName: 'economic_monograph_dawood.pdf',
        uploader: 'ياسمين حداد',
        uploadDate: '2025-08-26',
        verificationStatus: 'verified'
      }
    ]
  },
  {
    id: 'CASE-DZA-0028',
    name: 'كريم بلحاج',
    alias: 'النقابي',
    country: 'الجزائر',
    countryCode: 'DZA',
    city: 'وهران',
    detentionDays: 165,
    status: 'needs_evidence',
    caseType: 'human_rights',
    incidentDate: '2026-04-23',
    createdDate: '2026-04-26',
    lastUpdated: 'منذ يومين',
    image: courthouseImg,
    summary: 'ناشط نقابي ومدافع عن حقوق العمال بالقطاع الصناعي، يواجه متابعة قضائية بتهم المساس بالمصلحة الوطنية بعد تنظيمه إضراباً للمطالبة بظروف سلامة مهنية.',
    whatWeKnow: [
      'محضر الإيداع الصادر عن محكمة وهران بتاريخ 23 أبريل 2026.',
      'وجود إخطار مسبق بالإضراب القانوني مسجل لدى مفتشية العمل قبل 15 يوماً من الاحتجاج.'
    ],
    whatUnderVerification: [
      'احتمال إحالة الملف لمحكمة الجنايات بدلاً من الجنح؛ يجري فحص قرار غرفة الاتهام.'
    ],
    verificationStage: 'initial_review',
    verificationProgress: 35,
    stats: {
      sourcesCount: 6,
      documentsCount: 4,
      updatesCount: 8,
      daysCount: 165,
      affectedCount: 1,
      testimoniesCount: 3,
      legalSourcesCount: 1,
    },
    legalAidStatus: 'مجموعة من 4 محامين تتولى الدفاع مجاناً.',
    leadResearcher: 'مروان البوعزيزي',
    riskAssessment: 'متوسط',
    timeline: [
      {
        id: 'tl-dza-1',
        date: '23 أبريل 2026',
        title: 'أمر إيداع رهن الحبس المؤقت',
        description: 'قاضي التحقيق يقرر إيداعه سجن الحراش/وهران رهن الحبس الاحتياطي.',
        verified: true,
      }
    ],
    evidence: []
  },
  {
    id: 'CASE-LBY-0011',
    name: 'عمر القذافي المحمودي',
    alias: 'عمر المحمودي',
    country: 'ليبيا',
    countryCode: 'LBY',
    city: 'طرابلس',
    detentionDays: 289,
    status: 'urgent',
    caseType: 'custody_death',
    incidentDate: '2025-12-20',
    createdDate: '2025-12-24',
    lastUpdated: 'منذ يوم',
    image: detainedImg,
    summary: 'احتجاز تعسفي في سجن عين زارة دون أوامر من النيابة العامة، مع تدهور الحالة الصحية ونقص الرعاية الطبية، مما يعرض حياته للخطر الشديد في ظل تعطل الزيارات العائلية منذ 5 أشهر.',
    whatWeKnow: [
      'محضر رسمي لدى مكتب المدعي العام يثبت احتجازه دون أمر حبس ساري المفعول.',
      'شهادة طبيب سجن سابق تؤكد إصابته بفشل كلوي متقدم وحاجته إلى غسيل كلوي مرتين أسبوعياً.'
    ],
    whatUnderVerification: [
      'تقارير تفيد بنقله إلى مصحة خاصة؛ لم يتم التحقق من صحتها من مصدر مستقل.'
    ],
    verificationStage: 'received',
    verificationProgress: 15,
    stats: {
      sourcesCount: 7,
      documentsCount: 3,
      updatesCount: 7,
      daysCount: 289,
      affectedCount: 1,
      testimoniesCount: 2,
      legalSourcesCount: 1,
    },
    urgentReason: 'حالة طبية حرجة للغاية وتوقف جلسات الغسيل الكلوي المنتظمة يهدد حياته خلال أيام معدودة.',
    leadResearcher: 'سارة الشامي',
    riskAssessment: 'حرج',
    timeline: [],
    evidence: []
  }
];

export const INITIAL_CAMPAIGNS: CampaignItem[] = [
  {
    id: 'CAMP-EGY-042',
    caseId: 'CASE-EGY-0042',
    caseCode: 'CASE-EGY-0042',
    caseName: 'محمد بن سالم',
    title: 'ضمان الوصول إلى محامٍ ومراجعة الوضع القانوني لمحمد بن سالم',
    demand: 'ضمان الوصول إلى محامٍ مستقل، وإدخال الأدوية القلبية العاجلة فوراً، ومراجعة الوضع القانوني للقضية وفق الإجراءات القانونية والمواثيق الدولية.',
    participantsCount: 18542,
    targetCount: 100000,
    sharesCount: 76230,
    country: 'مصر',
    image: detainedImg,
    active: true,
    updates: [
      'تم جمع أكثر من 18 ألف توقيع حتى الآن وإرسال عريضة أولى لنقابة المحامين.',
      'تحديث طبي: سمحت إدارة السجن بإدخال شريط دواء واحد بعد ضغط التضامن المجتمعي.'
    ]
  },
  {
    id: 'CAMP-TUN-014',
    caseId: 'CASE-TUN-0014',
    caseCode: 'CASE-TUN-0014',
    caseName: 'فاطمة الزهراء البوعزيزي',
    title: 'كشف مصير فاطمة الزهراء وإنهاء الاختفاء القسري',
    demand: 'إلزام النيابة العامة ووزارة الداخلية بالإفصاح الفوري عن مكان تواجد الباحثة فاطمة الزهراء وتفريغ تسجيلات كاميرات المراقبة المحيطة بمكان اختفائها.',
    participantsCount: 12390,
    targetCount: 50000,
    sharesCount: 34120,
    country: 'تونس',
    image: courthouseImg,
    active: true,
    updates: [
      'وقفة احتجاجية أمام نقابة الصحفيين التونسيين للمطالبة بفتح تحقيق مستقل.'
    ]
  },
  {
    id: 'CAMP-YEM-003',
    caseId: 'CASE-YEM-0003',
    caseCode: 'CASE-YEM-0003',
    caseName: 'ملف مراكز الاحتجاز السرية في عدن',
    title: 'إتاحة الرعاية الطبية الفورية والتفتيش القضائي لسجون عدن',
    demand: 'تمكين النيابة العامة واللجنة الوطنية للتحقيق في ادعاءات انتهاكات حقوق الإنسان من زيارة مراكز الاحتجاز السرية في عدن وتوفير العلاج المنقذ للحياة للمحتجزين.',
    participantsCount: 24110,
    targetCount: 50000,
    sharesCount: 88400,
    country: 'اليمن',
    image: deskImg,
    active: true,
    updates: [
      'تحرك رسمي من المدعي العام لإصدار مذكرات تفتيش لـ 3 منشآت مشتبه بها.'
    ]
  },
  {
    id: 'CAMP-SYR-031',
    caseId: 'CASE-SYR-0031',
    caseCode: 'CASE-SYR-0031',
    caseName: 'ملف مفقودي سجون النظام البائد في سوريا',
    title: 'تأمين المقابر الجماعية وحماية سجلات سجن صيدنايا والأفرع الأمنية المحررة',
    demand: 'توفير الحماية الدولية الفورية للأرشيف الورقي والإلكتروني المحرر، وإلزام لجان التحقيق بتطبيق معايير الطب الشرعي والـ DNA المستقل دون الاعتماد على بيانات النظام البائد الفاسدة.',
    participantsCount: 42100,
    targetCount: 100000,
    sharesCount: 114500,
    country: 'سوريا',
    image: deskImg,
    active: true,
    updates: [
      'إتمام مسح الرادار الأرضي للموقع الأول بالقرب من دمشق ومطابقة 120 سجلاً محرراً.'
    ]
  }
];

export const INITIAL_COUNTRIES: CountryPriority[] = [
  {
    code: 'EGY',
    nameAr: 'مصر',
    nameEn: 'Egypt',
    totalCases: 56,
    verifiedCases: 38,
    investigatingCases: 14,
    urgentCases: 4,
    lastUpdate: 'منذ ساعتين',
    priorityScore: 92,
    coordinates: { x: 580, y: 320 },
    statusNote: 'جلسات تجديد حبس جماعية ورصد حالات إهمال طبي حادة.'
  },
  {
    code: 'SYR',
    nameAr: 'سوريا (ملفات النظام البائد والعدالة الانتقالية)',
    nameEn: 'Syria (Transition & Archives)',
    totalCases: 64,
    verifiedCases: 48,
    investigatingCases: 12,
    urgentCases: 8,
    lastUpdate: 'منذ ساعة',
    priorityScore: 98,
    coordinates: { x: 630, y: 260 },
    statusNote: 'توثيق مقابر جماعية وسجلات صيدنايا المحررة واستبعاد وثائق النظام الاستبدادي البائد.'
  },
  {
    code: 'YEM',
    nameAr: 'اليمن',
    nameEn: 'Yemen',
    totalCases: 46,
    verifiedCases: 29,
    investigatingCases: 12,
    urgentCases: 5,
    lastUpdate: 'منذ 4 ساعات',
    priorityScore: 90,
    coordinates: { x: 690, y: 520 },
    statusNote: 'مراكز احتجاز سرية وتفشي أمراض وحرمان من العلاج.'
  },
  {
    code: 'SAU',
    nameAr: 'السعودية',
    nameEn: 'Saudi Arabia',
    totalCases: 72,
    verifiedCases: 45,
    investigatingCases: 21,
    urgentCases: 6,
    lastUpdate: 'منذ 5 ساعات',
    priorityScore: 88,
    coordinates: { x: 670, y: 390 },
    statusNote: 'تأجيل متكرر لجلسات المحكمة الجزائية المتخصصة.'
  },
  {
    code: 'TUN',
    nameAr: 'تونس',
    nameEn: 'Tunisia',
    totalCases: 48,
    verifiedCases: 31,
    investigatingCases: 13,
    urgentCases: 4,
    lastUpdate: 'منذ 3 ساعات',
    priorityScore: 82,
    coordinates: { x: 440, y: 220 },
    statusNote: 'ملاحقة نشطاء مدنيين وحالات اختفاء قسري حديثة.'
  },
  {
    code: 'LBY',
    nameAr: 'ليبيا',
    nameEn: 'Libya',
    totalCases: 28,
    verifiedCases: 18,
    investigatingCases: 7,
    urgentCases: 3,
    lastUpdate: 'منذ 8 ساعات',
    priorityScore: 80,
    coordinates: { x: 490, y: 310 },
    statusNote: 'احتجاز خارج نطاق القضاء وتدهور مرافق الاحتجاز.'
  },
  {
    code: 'MAR',
    nameAr: 'المغرب',
    nameEn: 'Morocco',
    totalCases: 36,
    verifiedCases: 26,
    investigatingCases: 8,
    urgentCases: 2,
    lastUpdate: 'منذ 6 ساعات',
    priorityScore: 76,
    coordinates: { x: 260, y: 240 },
    statusNote: 'متابعات قضائية لصحفيين ومدونين في قضايا الرأي.'
  },
  {
    code: 'DZA',
    nameAr: 'الجزائر',
    nameEn: 'Algeria',
    totalCases: 39,
    verifiedCases: 27,
    investigatingCases: 10,
    urgentCases: 2,
    lastUpdate: 'منذ 7 ساعات',
    priorityScore: 78,
    coordinates: { x: 360, y: 260 },
    statusNote: 'توقيفات نقابية ورفض متكرر لطلبات الإفراج المؤقت.'
  },
  {
    code: 'SDN',
    nameAr: 'السودان',
    nameEn: 'Sudan',
    totalCases: 41,
    verifiedCases: 24,
    investigatingCases: 13,
    urgentCases: 4,
    lastUpdate: 'منذ ساعتين',
    priorityScore: 89,
    coordinates: { x: 590, y: 460 },
    statusNote: 'استهداف غرف الطوارئ والمطابخ التكافلية والكوادر الإغاثية.'
  },
  {
    code: 'BHR',
    nameAr: 'البحرين',
    nameEn: 'Bahrain',
    totalCases: 19,
    verifiedCases: 12,
    investigatingCases: 5,
    urgentCases: 2,
    lastUpdate: 'منذ يوم',
    priorityScore: 71,
    coordinates: { x: 720, y: 375 },
    statusNote: 'محاكمات بتهم النشر الإلكتروني وغياب المحامي المستقل.'
  }
];

export const INITIAL_TEAM_MEMBERS: TeamMember[] = [
  {
    id: 'user-1',
    name: 'أحمد المنصوري',
    role: 'مدير المنصة',
    email: 'al-mansouri@mazloum.org',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&h=120&q=80',
    permissions: ['إدارة شاملة', 'اعتماد النشر النهائي', 'تعديل سياسات التوثيق', 'إدارة المستخدمين', 'تصدير التقارير'],
    activeCasesCount: 28,
    lastActive: 'الآن (نشط)',
    twoFactorEnabled: true,
  },
  {
    id: 'user-2',
    name: 'سارة الشامي',
    role: 'باحث أول',
    email: 'sara.shami@mazloum.org',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&h=120&q=80',
    permissions: ['إدارة ملفات الشام', 'فحص الأدلة الجنائية', 'تحرير التايملاين', 'إحالة القضايا العاجلة'],
    activeCasesCount: 19,
    lastActive: 'منذ 10 دقائق',
    twoFactorEnabled: true,
  },
  {
    id: 'user-3',
    name: 'طارق عبد الرؤوف',
    role: 'مسؤول قانوني',
    email: 'tarek.law@mazloum.org',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&h=120&q=80',
    permissions: ['التنسيق القضائي', 'اعتماد صفة المحامين', 'مذكرات الطعن', 'الشكاوى الأممية'],
    activeCasesCount: 14,
    lastActive: 'منذ 35 دقيقة',
    twoFactorEnabled: true,
  },
  {
    id: 'user-4',
    name: 'مروان البوعزيزي',
    role: 'محقق أدلة',
    email: 'marwan.evidence@mazloum.org',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&h=120&q=80',
    permissions: ['فحص الأختام الرسمية', 'التحقق مفتوح المصدر (OSINT)', 'كشف التناقضات', 'تشفير الوثائق'],
    activeCasesCount: 11,
    lastActive: 'منذ ساعتين',
    twoFactorEnabled: true,
  },
  {
    id: 'user-5',
    name: 'ياسمين حداد',
    role: 'محرر حقوقي',
    email: 'yasmeen.editorial@mazloum.org',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=120&h=120&q=80',
    permissions: ['تحرير الملخصات الإنسانية', 'إعداد بيانات المركز الإعلامي', 'إدارة التصحيحات'],
    activeCasesCount: 8,
    lastActive: 'منذ 3 ساعات',
    twoFactorEnabled: true,
  },
  {
    id: 'user-6',
    name: 'كمال الدوسري',
    role: 'مسؤول إعلامي',
    email: 'kamal.media@mazloum.org',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=120&h=120&q=80',
    permissions: ['إدارة Press Kits', 'التواصل مع المراسلين', 'إحصاءات النشر الخارجي'],
    activeCasesCount: 6,
    lastActive: 'منذ 5 ساعات',
    twoFactorEnabled: false,
  }
];

export const INITIAL_ACTIVITY_LOGS: ActivityLogItem[] = [
  {
    id: 'log-1',
    user: 'أحمد',
    role: 'الباحث',
    action: 'أضاف وثيقة رسمية جديدة (محضر نيابة أمن الدولة المصدق) لملف CASE-EGY-0042.',
    targetCaseId: 'CASE-EGY-0042',
    targetCaseName: 'محمد بن سالم',
    timeAgo: 'منذ 15 دقيقة',
    timestamp: '2026-10-05 06:40',
    category: 'document'
  },
  {
    id: 'log-2',
    user: 'سارة',
    role: 'فريق التحقق',
    action: 'غيرت حالة التوثيق من "قيد التحقق" إلى "موثقة" بعد مطابقة دفاتر الإيداع الأصلية.',
    targetCaseId: 'CASE-SYR-0031',
    targetCaseName: 'ملف مفقودي سجون النظام البائد في سوريا',
    timeAgo: 'منذ ساعتين',
    timestamp: '2026-10-05 04:55',
    category: 'status'
  },
  {
    id: 'log-3',
    user: 'محمد',
    role: 'المدير',
    action: 'عدل ملخص القضية الأساسي وأضاف بند فحص التعارض الزمني للتاريخ في ملف CASE-EGY-0042.',
    targetCaseId: 'CASE-EGY-0042',
    targetCaseName: 'محمد بن سالم',
    timeAgo: 'منذ 4 ساعات',
    timestamp: '2026-10-05 02:50',
    category: 'summary'
  },
  {
    id: 'log-4',
    user: 'طارق',
    role: 'مسؤول قانوني',
    action: 'أودع مذكرة استئناف عاجلة لدى محكمة الجنايات بالتعاون مع هيئة الدفاع المستقلة.',
    targetCaseId: 'CASE-MAR-0007',
    targetCaseName: 'علي العلوي',
    timeAgo: 'منذ 6 ساعات',
    timestamp: '2026-10-05 00:30',
    category: 'verification'
  },
  {
    id: 'log-5',
    user: 'مروان',
    role: 'محقق أدلة',
    action: 'أجرى فحصاً تقنياً لبصمة الختم الرقمي على الوثيقة رقم EV-42-01 وأكد أصالتها بنسبة 99%.',
    targetCaseId: 'CASE-EGY-0042',
    targetCaseName: 'محمد بن سالم',
    timeAgo: 'منذ يوم',
    timestamp: '2026-10-04 11:20',
    category: 'document'
  },
  {
    id: 'log-6',
    user: 'سارة',
    role: 'فريق التحقق',
    action: 'نقلت ملف CASE-YEM-0003 من مرحلة "طلب الأدلة" إلى مرحلة "التحقق النهائي".',
    targetCaseId: 'CASE-YEM-0003',
    targetCaseName: 'ملف مراكز الاحتجاز السرية في عدن',
    timeAgo: 'منذ يومين',
    timestamp: '2026-10-03 16:15',
    category: 'pipeline'
  }
];

export const INITIAL_CONTRADICTIONS: ContradictionItem[] = [
  {
    id: 'contra-1',
    caseId: 'CASE-EGY-0042',
    caseName: 'محمد بن سالم',
    title: 'اختلاف في تاريخ الاعتقال والتوقيف الفعلي',
    sourceA: 'المصدر A (شهادة الأسرة وكاميرات المراقبة): التوقيف تم فجر 14 مارس 2026.',
    sourceB: 'المصدر B (محضر قسم الشرطة والنيابة): مثبت بتاريخ 16 مارس 2026 (تأخير 48 ساعة دون إثبات).',
    status: 'needs_human_review',
    detectedDate: '2026-03-26',
    notes: 'يشير بقوة إلى واقعة احتجاز بمعزل عن العالم الخارجي لمدة يومين قبل تحرير المحضر الصوري.'
  },
  {
    id: 'contra-2',
    caseId: 'CASE-TUN-0014',
    caseName: 'فاطمة الزهراء',
    title: 'تضارب حول توقيت انقطاع إشارة الهاتف المحمول',
    sourceA: 'المصدر A (إفادة زميل العمل): غادرت المكتب عند الساعة 17:15.',
    sourceB: 'المصدر B (سجلات شركة الاتصالات): توقفت إشارة البرج عند 16:50 (فارق 25 دقيقة).',
    status: 'investigating',
    detectedDate: '2026-07-22',
    notes: 'جاري مطابقة التوقيت مع ساعة خادم كاميرات المراقبة بالشارع المحاذي.'
  },
  {
    id: 'contra-3',
    caseId: 'CASE-YEM-0003',
    caseName: 'ملف مراكز احتجاز عدن',
    title: 'تضارب في تسمية الوحدة الأمنية المسؤولة عن المداهمة',
    sourceA: 'شهود العيان: مركبات تابعة لقوات الحزام الأمني.',
    sourceB: 'المحضر الأولي: إسناد التوقيف لشرطة النجدة المحلية.',
    status: 'needs_human_review',
    detectedDate: '2025-11-12',
    notes: 'تحتاج مراجعة بشرية واستدعاء إفادة قائد الدورية الميدانية المحايد.'
  }
];

export const INBOUND_SUBMISSIONS: SubmissionReport[] = [
  {
    id: 'sub-1',
    trackingId: 'SUB-2026-00842',
    submissionDate: '2026-09-28',
    country: 'مصر',
    city: 'الإسكندرية',
    caseType: 'detention',
    affectedPerson: 'إبراهيم م. ك.',
    senderName: 'عائلة المعتقل (عبر Signal)',
    riskLevel: 'عالي',
    hasDocuments: true,
    documentsCount: 3,
    contactSecure: 'signal: +2010***',
    summary: 'توقيف من مقر عمله دون إذن نيابة، ومطالبة بكشف مكان احتجازه بعد مرور 10 أيام.',
    evidenceDetails: 'شهادات 3 زملاء عمل + صورة بطاقة الرقم القومي + برقية تلغراف للنائب العام.',
    status: 'under_review',
    statusTextAr: 'قيد المراجعة والتحقق الأولي',
    lastUpdateDate: '2026-10-04',
    adminNotes: 'تم الاتصال بالمحامي المحلي لمطابقة سجلات قسم الشرطة.',
    assignedResearcher: 'سارة الشامي'
  },
  {
    id: 'sub-2',
    trackingId: 'SUB-2026-00819',
    submissionDate: '2026-09-15',
    country: 'تونس',
    city: 'صفاقس',
    caseType: 'fair_trial',
    affectedPerson: 'مروان ب.',
    senderName: 'المحامي الموكل',
    riskLevel: 'متوسط',
    hasDocuments: true,
    documentsCount: 2,
    contactSecure: 'signal: +216-24-***',
    summary: 'حكم غيابي مشدد دون إعلان رسمي، واحتجاز عند تجديد جواز السفر.',
    evidenceDetails: 'نسخة الحكم الغيابي + شهادة السفر القانوني المؤرخة.',
    status: 'verified_in_pipeline',
    statusTextAr: 'تم التثبت وإدراج الملف في مسار النشر',
    lastUpdateDate: '2026-10-03',
    adminNotes: 'الملف مستوفٍ للأدلة، جاري تجهيز الصفحة التحريرية والتواصل مع هيئة الدفاع.',
    assignedResearcher: 'طارق عبد الرؤوف'
  },
  {
    id: 'sub-3',
    trackingId: 'SUB-2026-00855',
    submissionDate: '2026-10-04',
    country: 'سوريا',
    city: 'حمص',
    caseType: 'disappearance',
    affectedPerson: 'عائلة آل النجار (4 مفقودين)',
    senderName: 'رابطة عائلات قيصر (مشفر)',
    riskLevel: 'حرج',
    hasDocuments: true,
    documentsCount: 6,
    contactSecure: 'protonmail: family.najjar***@pm.me',
    summary: 'طلب مطابقة صور عينات DNA لرفات تم انتشاله حديثاً من مقبرة تل النصر بريف حمص مع سجلات سجن صيدنايا المحررة.',
    evidenceDetails: '6 تقارير طبية وصور شعاعية للأطراف وعينات دم مصدقة من مختبر محايد.',
    status: 'under_review',
    statusTextAr: 'محال إلى وحدة الطب الشرعي لمطابقة الـ DNA',
    lastUpdateDate: '2026-10-05',
    adminNotes: 'تمت إحالة البيانات لوحدة الشام لاستبعاد أي تضليل من قيود النظام البائد.',
    assignedResearcher: 'سارة الشامي'
  },
  {
    id: 'sub-4',
    trackingId: 'SUB-2026-00790',
    submissionDate: '2026-08-30',
    country: 'اليمن',
    city: 'تعز',
    caseType: 'disappearance',
    affectedPerson: 'خالد ع.',
    senderName: 'مواطن (مجهول الهوية)',
    riskLevel: 'متوسط',
    hasDocuments: false,
    documentsCount: 0,
    contactSecure: 'whatsapp: +967-77-***',
    summary: 'اختفاء بعد المرور بنقطة تفتيش أمنية في طريق الحوبان دون مستندات مرفقة.',
    evidenceDetails: 'رواية شفوية فقط.',
    status: 'evidence_requested',
    statusTextAr: 'بانتظار مستندات إضافية ومحضر رسمي',
    lastUpdateDate: '2026-09-22',
    adminNotes: 'طلبنا إفادة إضافية من شاهد النقطة وسجل هاتف المحتجز الأخير لإثبات الواقعة ماديّاً.',
    assignedResearcher: 'مروان البوعزيزي'
  },
  {
    id: 'sub-5',
    trackingId: 'SUB-2026-00712',
    submissionDate: '2026-08-12',
    country: 'الأردن',
    city: 'إربد',
    caseType: 'other',
    affectedPerson: 'نزاع عقاري خاص',
    senderName: 'مجهول',
    riskLevel: 'منخفض',
    hasDocuments: true,
    documentsCount: 1,
    contactSecure: 'none',
    summary: 'نزاع مدني تجاري بين أطراف خاصة لا ينطوي على انتهاك حقوقي أو احتجاز تعسفي.',
    evidenceDetails: 'عقد إيجار تجاري.',
    status: 'rejected',
    statusTextAr: 'مرفوض لخروجه عن نطاق اختصاص المنصة',
    lastUpdateDate: '2026-08-14',
    adminNotes: 'خارج اختصاص منصة صوت المظلوم (قضية نزاع مدني مالي بحت).',
    assignedResearcher: 'أحمد المنصوري'
  }
];

export const INITIAL_LEGAL_PARTNERS: LegalPartner[] = [
  {
    id: 'lp-1',
    name: 'أ. طارق عبد الرازق',
    role: 'محامٍ معتمد',
    roleEn: 'Accredited Lawyer',
    country: 'مصر',
    city: 'القاهرة',
    bio: 'محامٍ بالنقض متخصص في قضايا الحبس الاحتياطي، الحريات العامة، ومحكمة أمن الدولة العليا منذ 18 عاماً.',
    verifiedStatus: true,
    specializations: ['الحبس الاحتياطي', 'المحاكمات الجنائية', 'الطعون بالنقض', 'حقوق الدفاع'],
    contactMethod: 'عبر بوابة التنسيق القانوني الآمنة',
    activeCasesCount: 12,
  },
  {
    id: 'lp-2',
    name: 'أ. ليلى الشابي',
    role: 'محامٍ معتمد',
    roleEn: 'Accredited Lawyer',
    country: 'تونس',
    city: 'تونس العاصمة',
    bio: 'عضو الرابطة التونسية للدفاع عن حقوق الإنسان ومتخصصة في قضايا حرية التعبير والجمعيات ومناهضة التعذيب.',
    verifiedStatus: true,
    specializations: ['حرية الرأي والتعبير', 'قضايا الصحافة', 'الاختفاء القسري', 'المرافعة الدستورية'],
    contactMethod: 'signal: +216-98-XXX-XXX',
    activeCasesCount: 8,
  },
  {
    id: 'lp-3',
    name: 'د. يوسف الإدريسي',
    role: 'باحث حقوقي',
    roleEn: 'Human Rights Researcher',
    country: 'المغرب',
    city: 'الرباط',
    bio: 'أستاذ قانون جنائي مقارن وباحث استقصائي متخصص في معايير المحاكمة العادلة والآليات القضائية الإقليمية.',
    verifiedStatus: true,
    specializations: ['معايير المحاكمة العادلة', 'تدقيق المحاضر القضائية', 'التحليل القانوني'],
    contactMethod: 'pgp: keyid-7F3A29',
    activeCasesCount: 15,
  },
  {
    id: 'lp-4',
    name: 'منظمة عدالة للحقوق والحريات',
    role: 'منظمة حقوقية',
    roleEn: 'Human Rights Organization',
    country: 'اليمن',
    city: 'عدن',
    bio: 'منظمة مدنية مستقلة ترصد مراكز الاحتجاز وتوثق الانتهاكات في جنوب اليمن وتنسق مع الآليات الأممية.',
    verifiedStatus: true,
    specializations: ['التوثيق الميداني', 'مراكز الاحتجاز', 'حماية الشهود', 'الدعم الإنساني'],
    contactMethod: 'contact@adalah-rights.org',
    activeCasesCount: 22,
  }
];

export const INITIAL_SUBMISSIONS: SubmissionReport[] = INBOUND_SUBMISSIONS;

export const FUND_METRICS = {
  totalRaised: 142850,
  totalSpent: 118400,
  casesSupported: 84,
  breakdown: [
    { title: 'أتعاب ورسوم هيئات الدفاع القانوني', percentage: 45, amount: 53280, count: 58 },
    { title: 'ترجمة المحاضر والعرائض القضائية الدولية', percentage: 20, amount: 23680, count: 42 },
    { title: 'تكاليف استخراج الوثائق والتنقل القضائي الميداني', percentage: 15, amount: 17760, count: 36 },
    { title: 'رعاية صحية عاجلة ودعم غذائي طارئ للأسر', percentage: 15, amount: 17760, count: 28 },
    { title: 'مصاريف التدقيق المحاسبي ومراجعة الامتثال', percentage: 5, amount: 5920, count: 12 },
  ],
  audits: [
    { period: 'الربع الثالث 2026', firm: 'مكتب الرقابة المحاسبية المستقل - جنيف', status: 'معتمد وخالٍ من الملاحظات', date: '2026-09-30' },
    { period: 'الربع الثاني 2026', firm: 'مكتب الرقابة المحاسبية المستقل - جنيف', status: 'معتمد وخالٍ من الملاحظات', date: '2026-06-30' },
    { period: 'الربع الأول 2026', firm: 'مكتب الرقابة المحاسبية المستقل - جنيف', status: 'معتمد وخالٍ من الملاحظات', date: '2026-03-31' },
  ]
};

export const CHARTER_PRINCIPLES = [
  {
    number: '01',
    title: 'لا ننشر ما لا نستطيع التثبت منه',
    text: 'المعلومة غير المثبتة لا تُقدم كحقيقة مهما كانت متداولة، ونفصل بصرامة بين ما هو موثق بالأدلة المادية، وما هو مجرد ادعاء قيد التحقق والبحث.'
  },
  {
    number: '02',
    title: 'لا ندافع عن شخص لمجرد انتمائه',
    text: 'مرجعنا الأخلاقي الوحيد هو العدل، كرامة الإنسان، وحكم القانون. لا نميز في التوثيق بناءً على دين أو فكر أو عرق أو انتماء سياسي أو جغرافي.'
  },
  {
    number: '03',
    title: 'لا نتهم شخصاً أو جهة دون دليل صلب',
    text: 'نلتزم بالمهنية والإنصاف والتحري الصحفي والقانوني الدقيق، ولا نطلق اتهامات أو نتبنى سرديات انفعالية دون وثائق ومحاضر وقرائن مادية قابلة للفحص.'
  },
  {
    number: '04',
    title: 'لا ندعو إلى العنف أو الانتقام أو الكراهية',
    text: 'هدفنا سيادة القانون وإنصاف الضحايا عبر الوسائل السلمية، الحقوقية، والإعلامية، ونرفض رفضاً قاطعاً أي تحريض على العنف أو خطاب الكراهية أو الانتقام الشخصي.'
  },
  {
    number: '05',
    title: 'نحمي هوية الضحايا والشهود فوق كل اعتبار',
    text: 'سلامة الأرواح أقدس من السبق التوثيقي؛ نخفي البيانات الحساسة فوراً، ونشفر السجلات، ونمتنع عن نشر أي تفصيلة قد تعرض معتقلاً أو شاهداً أو أسرته للخطر.'
  },
  {
    number: '06',
    title: 'نصحح أخطاءنا علناً وبكل شجاعة وشفافية',
    text: 'إذا تبين لنا عدم دقة أي معلومة نشرناها، نعلن التصحيح بوضوح في سجل التعديلات العام المرتبط بملف القضية ونوضح سبب الخطأ دون مواربة.'
  }
];
